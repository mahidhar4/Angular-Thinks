﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OAS_App_Common
{
    public class LoginModel : BaseModel, IDisposable
    {

        public string loggeduserpassword { get; set; }

        public string loggeduseremailid { get; set; }

        public int UserType { get; set; }

        public string password_original { get; set; }

        public int UserID { get; set; }

        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                loggeduserpassword = string.Empty;
                loggeduseremailid = string.Empty;
            }
        }
        #endregion
    }
}
