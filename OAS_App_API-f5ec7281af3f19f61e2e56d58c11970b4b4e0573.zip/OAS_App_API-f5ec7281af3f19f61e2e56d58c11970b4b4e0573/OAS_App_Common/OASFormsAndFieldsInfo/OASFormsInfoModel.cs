﻿using Newtonsoft.Json;
using OAS_App_Common.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace OAS_App_Common.OASFormsAndFieldsInfo
{
    public class OASFormsInfoModel : BaseModel, IDisposable
    {
        public string OASFormNameInfoGUID { get; set; }

        public string OASFormName { get; set; }

        public Int64 OASFormNameTypeID { get; set; }

        public string OASFormNameKindName { get; set; }

        public OASFormsInfoModel oasformsinfomodel { get; set; }

        public List<OASFormsInfoModel> oasformsinfomodelList { get; set; }


        [JsonConverter(typeof(longIdToStringConverter))]
        public long FormID { get; set; }

        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                OASFormNameInfoGUID = string.Empty;
                OASFormName = string.Empty;
                OASFormNameTypeID = 0;
                OASFormNameKindName = string.Empty;
                FormID = 0;
            }
        }
        #endregion
    }
}
