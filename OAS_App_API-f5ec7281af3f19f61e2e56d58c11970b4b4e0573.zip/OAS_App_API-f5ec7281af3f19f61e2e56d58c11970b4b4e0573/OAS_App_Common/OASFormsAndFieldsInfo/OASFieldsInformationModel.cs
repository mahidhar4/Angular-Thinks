﻿using Newtonsoft.Json;
using OAS_App_Common.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace OAS_App_Common.OASFormsAndFieldsInfo
{
    public class OASFieldsInformationModel : BaseModel, IDisposable
    {

        public string OASFieldNameInfoGUID { get; set; }

        public string OASFiledName { get; set; }

        public int OASFiledsGroupID { get; set; }

        [JsonConverter(typeof(longIdToStringConverter))]
        public Int64 OASFiledTypeID { get; set; }

        public string OASFormName { get; set; }

        public string OASFormNameInfoID { get; set; }

        [JsonConverter(typeof(longIdToStringConverter))]
        public long FieldID { get; set; }

        [JsonConverter(typeof(longIdToStringConverter))]
        public long FormID { get; set; }

        public FieldDataType FieldType { get; set; }

        public string FieldTypeDesc { get; set; }

        public OASFieldsInformationModel oasfieldsinformationmodel { get; set; }

        public List<OASFieldsInformationModel> oasfieldsinformationmodelList { get; set; }

        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                OASFieldNameInfoGUID = string.Empty;
                OASFiledName = string.Empty;
                OASFiledsGroupID = 0;
                OASFiledTypeID = 0;
                OASFormNameInfoID = string.Empty;
                FieldID = 0;
                FormID = 0;
                FieldType = 0;
                FieldTypeDesc = string.Empty;
            }
        }
        #endregion
    }
}
