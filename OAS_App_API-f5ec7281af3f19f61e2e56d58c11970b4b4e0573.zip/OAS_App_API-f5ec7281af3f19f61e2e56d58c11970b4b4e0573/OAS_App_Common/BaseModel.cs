﻿using Newtonsoft.Json;
using OAS_App_Common.Common;
using System;

namespace OAS_App_Common
{
    public class BaseModel : IDisposable
    {

        /// <summary>
        //Maintain the value while executing the Sp.1--Already Exists,0--SuccessfullyInsert,-1--error.
        /// </summary>
        public int? RequestExecutionStatus { get; set; }

        /// <summary>
        //Maintain the errorID while executing the Sp.
        /// </summary>
        public int? ErrorID { get; set; }

        /// <summary>
        //Maintain error message while executing the Sp.
        /// </summary>
        public string ErrorMessage { get; set; }


        private Boolean _IsConfirmationRequired = true;
        public Boolean IsConfirmationRequired
        {
            get
            {
                return _IsConfirmationRequired;
            }
            set
            {
                _IsConfirmationRequired = value;
            }

        }

        public string inputObjectJSON { get; set; }

        public string exceptionJSON { get; set; }

        public string exceptionLog { get; set; }

        public string exceptionSystemName { get; set; }

        public string exceptionDateAndTime { get; set; }

        public string exceptionStackTrace { get; set; }

        public OrgModel orgmodel { get; set; }


        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {

            }
        }
        #endregion
    }

    public class clientSessionInfo : IDisposable
    {

        public string ClientExternalIPAddress { get; set; }

        public string ClientAspLocalIPAddress { get; set; }

        public string ClientLocalIPAddress { get; set; }

        [JsonConverter(typeof(longIdToStringConverter))]
        public long ClientSessionGDSUID { get; set; }

        [JsonConverter(typeof(longIdToStringConverter))]
        public long ClientSessionInfoID { get; set; }

        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                ClientExternalIPAddress = string.Empty;
                ClientLocalIPAddress = string.Empty;
                ClientSessionGDSUID = 0;
                ClientSessionInfoID = 0;
                ClientAspLocalIPAddress = string.Empty;
            }
        }
        #endregion
    }

    public class OrgModel : IDisposable
    {

        public int LoggedUserID { get; set; }

        public int LoggedUserType { get; set; }

        public string LoggedUserName { get; set; }

        public string LoggedUserEmailAddress { get; set; }

        public int OrganizationID { get; set; }

        public string loggedusergdsuid { get; set; }

        public string orggdsuid { get; set; }

        public string OrganizationName { get; set; }

        public clientSessionInfo clientsessioninfo { get; set; }

        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                LoggedUserID = 0;
                LoggedUserType = 0;
                LoggedUserName = string.Empty;
                LoggedUserEmailAddress = string.Empty;
                OrganizationID = 0;
                OrganizationName = string.Empty;

                if (clientsessioninfo != null)
                    clientsessioninfo.Dispose();
            }
        }
        #endregion
    }


    // An entity, such as a user, group, or message.
    public class LoginEmployeeInfo
    {
        public string usernameoremailid { get; set; }

        public string password { get; set; }

        public int organizationid { get; set; }

        public string organizationgdsuid { get; set; }

        public string employeegdsuid { get; set; }

        public int employeeid { get; set; }

        public bool inactive { get; set; }

        public int UserType { get; set; }

    }

}
