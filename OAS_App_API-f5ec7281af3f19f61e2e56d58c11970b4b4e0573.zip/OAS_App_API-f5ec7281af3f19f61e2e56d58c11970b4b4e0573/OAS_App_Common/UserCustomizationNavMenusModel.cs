﻿using System;
using Newtonsoft.Json;
using OAS_App_Common.Common;
using System.Collections.Generic;
using System.Text;

namespace OAS_App_Common
{
    public class UserCustomizationNavMenusModel:BaseModel,IDisposable
    {
        public int UserType { get; set; }

        public string UserTypeDesc { get; set; }

        public int LinkedCustNavMenuInfoID { get; set; }

        public string MenuInfoIDs { get; set; }

        public int MenuInfoID { get; set; }

        public string LinkedMenuName { get; set; }


        public int MenuParentInfoID { get; set; }

        public string MenuParentName { get; set; }

        public string MenuName { get; set; }

        public string MenuComponentName { get; set; }

        public int MenuPosition { get; set; }

        [JsonConverter(typeof(longIdToStringConverter))]
        public long FormID { get; set; }

        public string MenuPositionName { get; set; }

        public bool IsFromQuickAdd { get; set; }

        [JsonConverter(typeof(longIdToStringConverter))]
        public long MenuFormInfoID { get; set; }

        public string MenuFormName { get; set; }

        public List<UserCustomizationNavMenusModel> NavMenusSubModelsList { get; set; }

        public List<UserCustomizationNavMenusModel> NavMenusParentModelsList { get; set; }

        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                UserType = 0;
                LinkedCustNavMenuInfoID = 0;
                MenuInfoIDs = string.Empty;
                LinkedMenuName = string.Empty;
                UserTypeDesc = string.Empty;
            }
        }
        #endregion
    }
}
