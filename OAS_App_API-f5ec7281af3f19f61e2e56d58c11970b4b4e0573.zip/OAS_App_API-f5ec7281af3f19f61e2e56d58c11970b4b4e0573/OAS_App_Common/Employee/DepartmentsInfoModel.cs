﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OAS_App_Common.Employee
{
   public class DepartmentsInfoModel:BaseModel,IDisposable
    {
        public string departmentgdsuid { get; set; }

        public int departmentid { get; set; }

        public string departmentname { get; set; }

        public string departmentmailalias { get; set; }

        public string departmentlead { get; set; }

        public string departmentparentdept { get; set; }

        public bool isinactive { get; set; }

        public DepartmentsInfoModel departmentsinfomodel { get; set; }

        public List<DepartmentsInfoModel> departmentsinfomodellist { get; set; }

        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                departmentgdsuid = string.Empty;
                departmentid = 0;
                departmentname = string.Empty;
                departmentmailalias = string.Empty;
                departmentlead = string.Empty;
                departmentparentdept = string.Empty;
                isinactive = false;
            }
        }
        #endregion
    }
}
