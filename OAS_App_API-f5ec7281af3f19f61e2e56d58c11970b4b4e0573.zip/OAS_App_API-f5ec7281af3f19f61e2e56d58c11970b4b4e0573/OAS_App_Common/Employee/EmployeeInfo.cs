﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OAS_App_Common.Employee
{

    public enum UserTypes
    {
        Admin = 1,
        Employee = 2,
    }

    public class EmployeeInfo : BaseModel, IDisposable
    {

        public string empgdsuid { get; set; }

        public int userid { get; set; }

        public string emailaddress { get; set; }

        public string empname { get; set; }

        public string empLastname { get; set; }

        public string dob { get; set; }

        public int gender { get; set; }

        public string genderName { get; set; }

        public string employeephonenumber { get; set; }

        public bool isactive { get; set; }

        public int employeemaritalstatus { get; set; }

        public string employeeotheremailaddress { get; set; }


        public string employeetags { get; set; }

        public string employeeaddress { get; set; }


        //======================================================
        public int employeedepartment { get; set; }

        public int employeereportingto { get; set; }

        public int employeesourceofhire { get; set; }

        public int employeeLocation { get; set; }

        public int employeetype { get; set; }

        public int employeerole { get; set; }

        public int employeestatus { get; set; }

        public int employeedesignation { get; set; }


        public string employeeworknumber { get; set; }

        public string employeejobdescription { get; set; }

        public string dateofexit { get; set; }

        public string dateofjoining { get; set; }

        //======================================================

        public string prevcompanyname { get; set; }

        public string jobtitle { get; set; }

        public string fromdate { get; set; }

        public string todate { get; set; }

        public string jobdescription { get; set; }


        public EmployeeInfo employeeinfo { get; set; }

        public string password { get; set; }


        public List<EmployeeInfo> employeeinfolist { get; set; }

        public List<EmployeeWorkExperianceModel> employeeworkexperiancemodellist { get; set; }

        public List<EmployeeEducationInfoModel> employeeeducationinfomodellist { get; set; }

        public List<EmployeeDependentInfo> employeedependentinfolist { get; set; }

        public EmployeeWorkExperianceModel employeeworkexperiancemodel { get; set; }

        public EmployeeEducationInfoModel employeeeducationinfomodel { get; set; }

        public EmployeeDependentInfo employeedependentinfo { get; set; }

        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                empgdsuid = string.Empty;
                password = string.Empty;
            }
        }
        #endregion
    }

    public class EmployeeWorkExperianceModel : IDisposable
    {

        public string empgdsuid { get; set; }

        public int userid { get; set; }


        public int employeeworkexperianceid { get; set; }

        public string prevcompanyname { get; set; }

        public string jobtitle { get; set; }

        public string fromdate { get; set; }

        public string todate { get; set; }

        public string jobdescription { get; set; }

        public bool isinactive { get; set; }

        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                employeeworkexperianceid = 0;
                prevcompanyname = string.Empty;
                jobtitle = string.Empty;
                fromdate = string.Empty;
                todate = string.Empty;
                jobdescription = string.Empty;
            }
        }
        #endregion
    }

    public class EmployeeEducationInfoModel : IDisposable
    {

        public string empgdsuid { get; set; }

        public int userid { get; set; }

        public int employeeeducationinfoid { get; set; }

        public string Schoolorcollegename { get; set; }

        public string degreeordiploma { get; set; }

        public string fieldofstudy { get; set; }

        public string dateofcompletion { get; set; }

        public string additionalnotes { get; set; }

        public string interests { get; set; }

        public bool isinactive { get; set; }

        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                employeeeducationinfoid = 0;
                Schoolorcollegename = string.Empty;
                degreeordiploma = string.Empty;
                fieldofstudy = string.Empty;
                dateofcompletion = string.Empty;
                additionalnotes = string.Empty;
                interests = string.Empty;
            }
        }
        #endregion
    }

    public class EmployeeDependentInfo : IDisposable
    {

        public string empgdsuid { get; set; }

        public int userid { get; set; }

        public int employeeDependentinfoid { get; set; }

        public string dependentname { get; set; }

        public string dependentrelation { get; set; }

        public string dependentdateofbirth { get; set; }

        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                employeeDependentinfoid = 0;
                dependentname = string.Empty;
                dependentrelation = string.Empty;
                dependentdateofbirth = string.Empty;
            }
        }
        #endregion
    }
}
