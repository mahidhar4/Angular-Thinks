﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OAS_App_Common.Employee
{   

    public class DesignationsInfoModel : BaseModel, IDisposable
    {
        public string designationsgdsuid { get; set; }

        public int designationid { get; set; }

        public string designationname { get; set; }

        public string designationmailalias { get; set; }

        public bool isinactive { get; set; }

        public DesignationsInfoModel designationsinfomodel { get; set; }

        public List<DesignationsInfoModel> designationsinfomodellist { get; set; }

        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                designationsgdsuid = string.Empty;
                designationid = 0;
                designationname = string.Empty;
                designationmailalias = string.Empty;
                isinactive = false;
            }
        }
        #endregion
    }

}
