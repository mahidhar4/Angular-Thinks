﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OAS_App_Common.Common
{
   public class TimeIDsModel:BaseModel,IDisposable
    {

        public int TimeID { get; set; }

        public string Time { get; set; }

        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                TimeID = 0;
                Time = string.Empty;
            }
        }
        #endregion
    }
}
