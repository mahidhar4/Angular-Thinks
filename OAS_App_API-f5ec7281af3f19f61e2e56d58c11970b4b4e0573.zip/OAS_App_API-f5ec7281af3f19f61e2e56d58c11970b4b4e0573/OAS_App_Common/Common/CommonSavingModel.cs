﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using OAS_App_Common.Organization;
using System;
using System.Collections.Generic;
using System.Text;

namespace OAS_App_Common.Common
{

    public class longIdToStringConverter : JsonConverter
    {
        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
        {
            JToken jt = JValue.ReadFrom(reader);

            return jt.Value<long>();
        }

        public override bool CanConvert(Type objectType)
        {
            return typeof(System.Int64).Equals(objectType);
        }

        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            serializer.Serialize(writer, value.ToString());
        }
    }


    public class objectoStringConverter : JsonConverter
    {
        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
        {
            JToken jt = JValue.ReadFrom(reader);

            return jt.Value<object>();
        }

        public override bool CanConvert(Type objectType)
        {
            return typeof(System.Object).Equals(objectType);
        }

        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            serializer.Serialize(writer, value.ToString());
        }
    }

    public class CommonSavingModel : BaseModel, IDisposable
    {

        public string FormID { get; set; }

        [JsonConverter(typeof(longIdToStringConverter))]
        public long ReportID { get; set; }

        public List<CommonSavingFieldsModel> CommonSavingFieldsData { get; set; }

        public string columnsData { get; set; }

        public string gridData { get; set; }

        public CommonSavingFieldsModel CommonFilterFieldsData { get; set; }

        public List<CommonSavingFieldsModel> CommonSearchFilterFieldsData { get; set; }

        public CommonSavingRowsFieldsModel CommonSavingRowData { get; set; }

        public TaskListInfoModel tasklistinfomodel { get; set; }

        public int ResponseCnt { get; set; }

        [JsonConverter(typeof(longIdToStringConverter))]
        public long FieldID { get; set; }

        [JsonConverter(typeof(longIdToStringConverter))]
        public long RecordID { get; set; }

        public string FieldValue { get; set; }


        [JsonConverter(typeof(longIdToStringConverter))]
        public long formid { get; set; }

        public ShiftModel Shift { get; set; }

        public LeaveModel Leave { get; set; }

        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                ResponseCnt = 0;

                if (CommonSavingFieldsData != null && CommonSavingFieldsData.Count > 0)
                {
                    foreach (CommonSavingFieldsModel item in CommonSavingFieldsData)
                    {
                        item.Dispose();
                    }
                }

                if (CommonSearchFilterFieldsData != null && CommonSearchFilterFieldsData.Count > 0)
                {
                    foreach (CommonSavingFieldsModel item in CommonSearchFilterFieldsData)
                    {
                        item.Dispose();
                    }
                }

                if (CommonFilterFieldsData != null)
                    CommonFilterFieldsData.Dispose();

                columnsData = string.Empty;
                gridData = string.Empty;
                ReportID = 0;
                FieldID = 0;
                RecordID = 0;
                FieldValue = string.Empty;
                formid = 0;

            }
        }
        #endregion
    }




    public class CommonSavingRowsFieldsModel : IDisposable
    {
        [JsonConverter(typeof(longIdToStringConverter))]
        public long RecordID { get; set; }

        public string RecordGDSUID { get; set; }

        public List<CommonSavingFieldsModel> CommonSavingFieldsData { get; set; }

        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {

                RecordID = 0;
                RecordGDSUID = string.Empty;

                if (CommonSavingFieldsData != null && CommonSavingFieldsData.Count > 0)
                {
                    foreach (CommonSavingFieldsModel item in CommonSavingFieldsData)
                    {
                        item.Dispose();
                    }

                }
            }
        }
        #endregion
    }


    public enum FilterMode
    {
        EQUALS = 1,
        STARTSWITH = 2
    }

    public enum FieldDataType
    {
        STRING = 1,
        DATE = 2,
        DATETIME = 3,
        BOOLEAN = 4,
        INTEGER = 5,
        DOUBLE = 6,
        FLOAT = 7,
        LONG = 8,
        GOOGLECLOUDHTML = 9//need to send in base64 format
    }



    public class CommonSavingFieldsDBModel : IDisposable
    {

        public long fieldid { get; set; }

        [JsonConverter(typeof(objectoStringConverter))]
        public object filedValue { get; set; }

        //[JsonConverter(typeof(longIdToStringConverter))]
        public long recordid { get; set; }

        //[JsonConverter(typeof(longIdToStringConverter))]
        public long sequenceingroup { get; set; }

        //[JsonConverter(typeof(longIdToStringConverter))]
        public long groupid { get; set; }

        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                filedValue = null;
                sequenceingroup = 0;
                fieldid = 0;
                recordid = 0;
                groupid = 0;
            }
        }


        #endregion
    }


    public class CommonSavingFieldsModel : IDisposable
    {
        [JsonConverter(typeof(longIdToStringConverter))]
        public long FieldID { get; set; }

        public object FieldValue { get; set; }

        //for filters
        public object FieldValue2 { get; set; }

        [JsonConverter(typeof(longIdToStringConverter))]
        public long RecordID { get; set; }

        [JsonConverter(typeof(longIdToStringConverter))]
        public long RecordDataID { get; set; }

        [JsonConverter(typeof(longIdToStringConverter))]
        public long RowNumber { get; set; }

        [JsonConverter(typeof(longIdToStringConverter))]
        public long ColumnNumber { get; set; }

        public string RecordGDSUID { get; set; }

        [JsonConverter(typeof(longIdToStringConverter))]
        public long RecordKeyGDSUID { get; set; }

        [JsonConverter(typeof(longIdToStringConverter))]
        public long FieldGroupID { get; set; }

        [JsonConverter(typeof(longIdToStringConverter))]
        public long FieldSeqNumber { get; set; }

        public int FilterMode { get; set; }

        public FieldDataType FieldType { get; set; }

        public string FieldTypeDesc { get; set; }

        public List<CommonSavingFieldsModel> CommonSavingFieldsMultipleData { get; set; }

        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                FieldID = 0;
                FieldValue = null;
                FieldGroupID = 0;
                FieldSeqNumber = 0;
                RecordID = 0;
                RecordGDSUID = string.Empty;
                RecordKeyGDSUID = 0;
                ColumnNumber = 0;
                RowNumber = 0;
                FilterMode = 0;
                FieldType = 0;
                FieldValue2 = null;
                RecordDataID = 0;

                if (CommonSavingFieldsMultipleData != null && CommonSavingFieldsMultipleData.Count > 0)
                {
                    foreach (CommonSavingFieldsModel item in CommonSavingFieldsMultipleData)
                    {
                        item.Dispose();
                    }

                }

                FieldTypeDesc = string.Empty;
            }
        }


        #endregion
    }



    public enum ReportType
    {
        DIRECTLIST = 1,
        RELATIONALLIST = 2,
        VALIDATION = 3
    }

    public class ReportsModel : BaseModel, IDisposable
    {
        [JsonConverter(typeof(longIdToStringConverter))]
        public long FieldID { get; set; }

        public object FieldValue { get; set; }

        [JsonConverter(typeof(longIdToStringConverter))]
        public long RecordID { get; set; }

        [JsonConverter(typeof(longIdToStringConverter))]
        public long ReportID { get; set; }

        public string ReportName { get; set; }

        public string ReportPurpose { get; set; }

        public ReportType ReportType { get; set; }

        public string ReportQuerytoExec { get; set; }

        public string p_SelectQuery { get; set; }

        public string p_BodyQuery { get; set; }

        public string p_FilterQuery { get; set; }

        public string p_DropQuery { get; set; }


        public string p_CreateQuery { get; set; }


        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                FieldID = 0;
                FieldValue = null;
                RecordID = 0;
                ReportType = 0;
                ReportQuerytoExec = string.Empty;
            }
        }


        #endregion
    }


    public class ReportsFormsModel : BaseModel, IDisposable
    {
        [JsonConverter(typeof(longIdToStringConverter))]
        public long FormID { get; set; }

        public string FormName { get; set; }

        public string FieldName { get; set; }

        public int GroupID { get; set; }


        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                FormID = 0;
                FormName = string.Empty;
                FieldName = string.Empty;
                GroupID = 0;
            }
        }


        #endregion
    }



    public class ReportsSelectFields : ReportsFormsModel, IDisposable
    {
        [JsonConverter(typeof(longIdToStringConverter))]
        public long SelectFieldInfoID { get; set; }

        [JsonConverter(typeof(longIdToStringConverter))]
        public long FieldID { get; set; }

        public object DefaultFieldValue { get; set; }

        [JsonConverter(typeof(longIdToStringConverter))]
        public long ReportID { get; set; }

        public List<ReportsSelectFields> ReportsSelectFieldsList { get; set; }


        public string TableAliasName { get; set; }

        public string FieldNameWithAlias { get; set; }


        public string FormIDToTakeForDefaultField { get; set; }


        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                FieldID = 0;
                DefaultFieldValue = null;
                SelectFieldInfoID = 0;
                ReportID = 0;
                TableAliasName = string.Empty;
                FieldNameWithAlias = string.Empty;
                FormIDToTakeForDefaultField = string.Empty;
            }
        }


        #endregion
    }

    public enum ReportsConditionType
    {
        AND = 1,
        OR = 2
    }

    public enum ReportsConditionMode
    {
        IN = 1,
        NOTIN = 2,
        BETWEEN = 3,
        STARTSWITH = 4,
        CONTAINS = 5,
        ENDSWITH = 6,
        LESSTHAN = 7,
        GREATERTHAN = 8,
        LESSTHANEQUAL = 9,
        GREATERTHANEQUAL = 10,
        EQUALS = 11,
        NOTEQUALS = 12,
        NOTNULL = 13,
        ISNULL = 14
    }

    public enum SortOrder
    {
        ASCENDING = 1,
        DESCENDING = 2
    }

    public class ReportsFilterFields : ReportsFormsModel, IDisposable
    {
        [JsonConverter(typeof(longIdToStringConverter))]
        public long FilterFieldInfoID { get; set; }

        [JsonConverter(typeof(longIdToStringConverter))]
        public long FieldID { get; set; }

        public object DefaultFieldValue { get; set; }

        [JsonConverter(typeof(longIdToStringConverter))]
        public long ReportID { get; set; }

        public ReportsConditionType ConditionType { get; set; }

        public ReportsConditionMode ConditionMode { get; set; }

        public List<ReportsFilterFields> ReportsFilterFieldsList { get; set; }

        public int sequencenumber { get; set; }

        public SortOrder sortorder { get; set; }

        public FieldDataType FieldDataType { get; set; }


        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                FieldID = 0;
                DefaultFieldValue = null;
                FilterFieldInfoID = 0;
                ReportID = 0;
                ConditionMode = 0;
                ConditionType = 0;
                sequencenumber = 0;
                sortorder = 0;
                FieldDataType = 0;
            }
        }


        #endregion
    }

    public enum InvolvmentJoinType
    {
        INNERJOIN = 1,
        LEFTJOIN = 2,
        RIGHTJOIN = 3
    }

    public class ReportsFormTablesInvolved : BaseModel, IDisposable
    {
        [JsonConverter(typeof(longIdToStringConverter))]
        public long ReportsFormTablesInvolvedInfoID { get; set; }

        [JsonConverter(typeof(longIdToStringConverter))]
        public long? InvolvedTable1FormID { get; set; }

        [JsonConverter(typeof(longIdToStringConverter))]
        public long? InvolvedTable2FormID { get; set; }

        public InvolvmentJoinType? InvolvmentJoinType { get; set; }

        [JsonConverter(typeof(longIdToStringConverter))]
        public long ReportID { get; set; }

        [JsonConverter(typeof(longIdToStringConverter))]
        public long InvolvmentSequenceNumberTable { get; set; }

        public List<ReportsFormTablesInvolved> ReportsFormTablesInvolvedList { get; set; }


        [JsonConverter(typeof(longIdToStringConverter))]
        public long UniqueFormID { get; set; }

        public string TableAliasName { get; set; }

        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                UniqueFormID = 0;
                InvolvedTable1FormID = null;
                InvolvedTable2FormID = null;
                InvolvmentJoinType = null;
                ReportsFormTablesInvolvedInfoID = 0;
                ReportID = 0;
                InvolvmentSequenceNumberTable = 0;
                TableAliasName = string.Empty;
            }
        }


        #endregion
    }

    public class ReportsFormTableColumnsFieldsInvolved : ReportsFormTablesInvolved, IDisposable
    {


        [JsonConverter(typeof(longIdToStringConverter))]
        public long ReportsFormTableColumnsFieldsInvolvedInfoID { get; set; }

        [JsonConverter(typeof(longIdToStringConverter))]
        public long InvolvedTable1ColumnFieldID { get; set; }

        [JsonConverter(typeof(longIdToStringConverter))]
        public long InvolvedTable2ColumnFieldID { get; set; }


        public string InvolvedTable1ColumnFieldDefaultValue { get; set; }

        public string InvolvedTable2ColumnFieldDefaultValue { get; set; }

        [JsonConverter(typeof(longIdToStringConverter))]
        public long InvolvmentSequenceNumberField { get; set; }

        public ReportsConditionType ColumsInvoled_ConditionType { get; set; }

        public List<ReportsFormTableColumnsFieldsInvolved> ReportsFormTableColumnsFieldsInvolvedList { get; set; }

        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                ReportsFormTableColumnsFieldsInvolvedInfoID = 0;
                InvolvedTable1ColumnFieldID = 0;
                InvolvedTable2ColumnFieldID = 0;
                InvolvedTable1ColumnFieldDefaultValue = string.Empty;
                ReportsFormTablesInvolvedInfoID = 0;
                InvolvedTable2ColumnFieldDefaultValue = string.Empty;
                InvolvmentSequenceNumberTable = 0;
                ReportID = 0;
                ColumsInvoled_ConditionType = 0;
            }
        }


        #endregion
    }

    public class DataTypeModel : BaseModel
    {

        // the integer value of datatype
        public int DataType { get; set; }

        // the name of the datatype
        public string DataTyeDesc { get; set; }

        // list of datatypes
        public List<DataTypeModel> dataTypeModelList { get; set; }

        // active or not
        public int DataStatus { get; set; }

        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                DataType = 0;
                DataTyeDesc = string.Empty;
                DataStatus = 0;
            }
        }
        #endregion
    }

    public class ShiftModel: BaseModel
    {
        public string ShiftStartDate { get; set; }

        public string ShiftEndDate { get; set; }

        public long EmpWithShiftID { get; set; }

        public long RecordID { get; set; }

        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                ShiftStartDate = string.Empty;
                ShiftEndDate = string.Empty;
                EmpWithShiftID = 0;
                RecordID = 0;
            }
        }
        #endregion
    }

    public class LeaveModel: BaseModel
    {
        public string LeaveFromDate { get; set; }

        public string LeaveToDate { get; set; }

        public string LeaveApplyingEmployeeName { get; set; }

        public string LeaveStatus { get; set; }


        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                LeaveFromDate = string.Empty;
                LeaveToDate = string.Empty;
                LeaveApplyingEmployeeName = string.Empty;
                LeaveStatus = string.Empty;
            }
        }
        #endregion
    }

}
