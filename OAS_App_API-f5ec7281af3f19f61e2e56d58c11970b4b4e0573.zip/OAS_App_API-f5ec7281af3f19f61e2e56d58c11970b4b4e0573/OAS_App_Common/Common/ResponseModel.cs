﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OAS_App_Common.Common
{

    public class ResponseModel : BaseModel, IDisposable
    {

        public int ResponseID { get; set; }

        public string MultipleResponse { get; set; }

        /// <summary>
        /// THIS VARAIABLE IS USED FOR HOLDING THE INFORMATION OF CONFIRMATION MESSAGE THAT HAS TO BE RETURNING FROM THE SERVICE 
        ///// RETURNING FROM THE SERVICE
        /// </summary>
        public List<ConformationModel> confirmationModelList { get; set; }


        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                ResponseID = 0;
                MultipleResponse = string.Empty;

            }
        }
        #endregion
    }


    public class ConformationModel : IDisposable
    {
        /// <summary>
        /// THIS IS USED TO HOLD THE CONFIRMATION MESSAGE THAT HAS TO BE SHOWN TO THE USER
        /// </summary>
        public string ConformationMessage { get; set; }

        /// <summary>
        /// THIS IS USED TO HOLD THE TYPE OF THE CONFIRMATION ,DEPENDING ON THESE TYPE OF THE CONFIRMATION WE HAVE TO OPEN 
        /// THE ANOTHER POPUP WINDOW ACCORDING TO THE BUSINESS LOGIC AND FUNCTIONALITY
        /// </summary>
        public int ConfirmationType { get; set; }

        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "

        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                ConformationMessage = string.Empty;
                ConfirmationType = 0;
            }
        }
        #endregion

    }
}
