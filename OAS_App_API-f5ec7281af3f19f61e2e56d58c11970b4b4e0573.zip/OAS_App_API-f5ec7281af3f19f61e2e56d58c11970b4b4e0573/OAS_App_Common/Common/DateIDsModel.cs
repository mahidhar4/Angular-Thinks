﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OAS_App_Common.Common
{
   public class DateIDsModel:BaseModel,IDisposable
    {
        public Int32 Date_UTC_ID { get; set; }

        public string Date_UTC { get; set; }


        public DateIDsModel dateidsmodel { get; set; }

        public List<DateIDsModel> dateidsmodelList { get; set; }

        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                Date_UTC_ID = 0;
                Date_UTC = string.Empty;
            }
        }
        #endregion
    }
}
