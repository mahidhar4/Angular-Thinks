﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OAS_App_Common.Common
{
    public class OASCommonHelper : IDisposable
    {

        public string GetRandomNumber()
        {
            Random generator = new Random();
            String r = string.Empty;
            r = generator.Next(0, 99).ToString("D2");
            return r;
        }

        public long GetRandomNumber_DateUTC_Int()
        {
            string utcstr = DateTime.UtcNow.ToString("yyyyMMddhhmmssfff");

            return Convert.ToInt64(utcstr + GetRandomNumber());
        }

        public long GeDateUTC_Int()
        {
            string utcstr = DateTime.UtcNow.ToString("yyyyMMddhhmmssfff");

            return Convert.ToInt64(utcstr);
        }


        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {

            }
        }
        #endregion
    }
}
