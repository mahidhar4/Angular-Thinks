﻿using Newtonsoft.Json;
using OAS_App_Common.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace OAS_App_Common
{
    public class NavMenusModel : BaseModel, IDisposable
    {
        public int MenuInfoID { get; set; }

        public int MenuParentInfoID { get; set; }

        public string MenuParentName { get; set; }

        public string MenuName { get; set; }

        public string MenuComponentName { get; set; }

        public int MenuPosition { get; set; }

        [JsonConverter(typeof(longIdToStringConverter))]
        public long FormID { get; set; }

        public string MenuPositionName { get; set; }

        public bool IsFromQuickAdd { get; set; }

        [JsonConverter(typeof(longIdToStringConverter))]
        public long MenuFormInfoID { get; set; }

        public string MenuFormName { get; set; }

        public List<NavMenusModel> NavMenusSubModelsList { get; set; }

        public List<NavMenusModel> NavMenusParentModelsList { get; set; }

        public bool IsFromAddEditMenusInfo { get; set; }

        public bool IsFromCustomization { get; set; }

        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                MenuInfoID = 0;
                MenuParentInfoID = 0;
                MenuName = string.Empty;
                MenuComponentName = string.Empty;
                MenuPosition = 0;
                MenuFormInfoID = 0;
            }
        }
        #endregion
    }
}
