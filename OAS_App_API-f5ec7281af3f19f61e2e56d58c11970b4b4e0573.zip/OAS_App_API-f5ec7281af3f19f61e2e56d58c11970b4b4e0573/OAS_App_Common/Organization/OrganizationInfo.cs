﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OAS_App_Common.Organization
{
    public class OrganizationInfo : BaseModel, IDisposable
    {
        public string orggdsuid { get; set; }

        public int organizationid { get; set; }

        public string organizationname { get; set; }

        public string organizationaddress { get; set; }

        public bool isInactive { get; set; }

        public OrganizationInfo organizationinfo { get; set; }
        public List<OrganizationInfo> organizationinfolist { get; set; }


        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                orggdsuid = string.Empty;
                organizationid = 0;
                organizationname = string.Empty;
                organizationaddress = string.Empty;
                isInactive = false;
            }
        }
        #endregion
    }
}
