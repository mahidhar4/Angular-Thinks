﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OAS_App_Common.Organization
{
   public class ClientInformationModel: BaseModel, IDisposable
    {
        public string ProjectName { get; set; }

        public int ProjectID { get; set; }

        public string ProjectClientName { get; set; }

        public string ProjectClientAddress { get; set; }

        public string ProjectClientPhone { get; set; }

        public string ProjectClientEmail { get; set; }

        public string ClientContactPerson1Name { get; set; }

        public string ClientContactPerson1Phone { get; set; }

        public string ClientContactPerson1Email { get; set; }

        public string ClientContactPerson2Name { get; set; }

        public string ClientContactPerson2Phone { get; set; }

        public string ClientContactPerson2Email { get; set; }

        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                ProjectName = string.Empty;
                ProjectID = 0;
                ProjectClientName = string.Empty;
                ProjectClientAddress = string.Empty;
                ProjectClientPhone = string.Empty;
                ProjectClientEmail = string.Empty;
                ClientContactPerson1Name = string.Empty;
                ClientContactPerson1Phone = string.Empty;
                ClientContactPerson1Email = string.Empty;
                ClientContactPerson2Name = string.Empty;
                ClientContactPerson2Phone = string.Empty;
                ClientContactPerson2Email = string.Empty;
            }
        }
        #endregion
    }
}
