﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OAS_App_Common.Organization
{
   public class ProjectsStatusModel:BaseModel,IDisposable
    {
        public int ProjectStatusID { get; set; }

        public string ProjectStatus { get; set; }

        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                ProjectStatusID = 0;
                ProjectStatus = string.Empty;
            }
        }
        #endregion
    }
}
