﻿using MySql.Data.MySqlClient;
using OAS_App_Common;
using OAS_App_Common.Common;
using OAS_App_Common.OASFormsAndFieldsInfo;
using OAS_App_DataAccess.commonhelper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace OAS_App_DataAccess.formsandfields
{
    public class FormsAndFieldsDataAccess : IDisposable
    {

        /// <summary>
        /// 
        /// </summary>
        /// <param name="oasformsinfomodel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> SaveAndUpdateFormsInformation(OASFormsInfoModel oasformsinfomodel)
        {
            ResponseModel responseModel = null;

            try
            {
                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMasterDataBaseConnectionString(CommonHelper.DBToConnect.OASMATER)))
                    {

                        await con.OpenAsync();

                        //***********INPUT PARAMETERS BLOCK END*****************
                        MySqlCommand command = new MySqlCommand("usp_oas_master_form_insert", con);

                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        //***********INPUT PARAMETERS BLOCK END*****************

                        command.Parameters.Add(new MySqlParameter("p_formid", MySqlDbType.Int64));
                        commonHelper.SetSqlParameterInt64(command.Parameters["p_formid"], oasformsinfomodel.FormID);

                        command.Parameters.Add(new MySqlParameter("p_formname", MySqlDbType.VarChar, 1024));
                        commonHelper.SetSqlParameterValue(command.Parameters["p_formname"], oasformsinfomodel.OASFormName);

                        command.Parameters.Add(new MySqlParameter("p_organizationid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_organizationid"], oasformsinfomodel.orgmodel.OrganizationID);

                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], oasformsinfomodel.orgmodel.LoggedUserID);


                        //***********INPUT PARAMETERS BLOCK END*****************

                        //***********INPUT PARAMETERS BLOCK END*****************

                        //**********OUT PUT PARAMETERS BLOCK START***************
                        //**********REGULAR OUT PUT PARAMETERS BLOCK START***************

                        commonHelper.SetRegularOutputSqlParameters(command);

                        //**********REGULAR OUT PUT PARAMETERS BLOCK END***************
                        //**********OUT PUT PARAMETERS BLOCK END***************


                        await command.ExecuteNonQueryAsync();

                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();
                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********


                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 

                        //if sp is not executed successfully / the sp is executed with errors 
                        // ie RequestExecutionStatus with have negative value
                        if (responseModel == null)
                            responseModel = new ResponseModel();

                        //Calling Method to assign the data related to the OutPut Parameters of the Base Class.
                        commonHelper.GetOutParameterValuesWithResponseModel(command, responseModel);


                    }
                }
            }
            finally
            {

            }

            return responseModel;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="oasformsinfomodel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> DeleteFormInformation(OASFormsInfoModel oasformsinfomodel)
        {
            ResponseModel responseModel = null;

            try
            {
                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMasterDataBaseConnectionString(CommonHelper.DBToConnect.OASMATER)))
                    {

                        await con.OpenAsync();

                        //***********INPUT PARAMETERS BLOCK END*****************
                        MySqlCommand command = new MySqlCommand("usp_oas_master_form_delete", con);

                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        //***********INPUT PARAMETERS BLOCK END*****************

                        command.Parameters.Add(new MySqlParameter("p_formid", MySqlDbType.Int64));
                        //if (oasformsinfomodel.FormID <= 0)
                        //    oasformsinfomodel.FormID = 1234;

                        commonHelper.SetSqlParameterInt64(command.Parameters["p_formid"], oasformsinfomodel.FormID);

                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], oasformsinfomodel.orgmodel.LoggedUserID);


                        //***********INPUT PARAMETERS BLOCK END*****************

                        //***********INPUT PARAMETERS BLOCK END*****************

                        //**********OUT PUT PARAMETERS BLOCK START***************
                        //**********REGULAR OUT PUT PARAMETERS BLOCK START***************

                        commonHelper.SetRegularOutputSqlParameters(command);

                        //**********REGULAR OUT PUT PARAMETERS BLOCK END***************
                        //**********OUT PUT PARAMETERS BLOCK END***************


                        await command.ExecuteNonQueryAsync();

                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();
                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********


                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 

                        //if sp is not executed successfully / the sp is executed with errors 
                        // ie RequestExecutionStatus with have negative value
                        if (responseModel == null)
                            responseModel = new ResponseModel();

                        //Calling Method to assign the data related to the OutPut Parameters of the Base Class.
                        commonHelper.GetOutParameterValuesWithResponseModel(command, responseModel);


                    }
                }
            }
            finally
            {

            }

            return responseModel;
        }




        public async Task<OASFormsInfoModel> GetFormsInfoList(OASFormsInfoModel oasformsinfomodel)
        {
            OASFormsInfoModel responseModel = null;

            try
            {
                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMasterDataBaseConnectionString(CommonHelper.DBToConnect.OASMATER)))
                    {

                        await con.OpenAsync();

                        //***********INPUT PARAMETERS BLOCK END*****************
                        MySqlCommand command = new MySqlCommand("usp_oas_master_form_list", con);

                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        //***********INPUT PARAMETERS BLOCK END*****************

                        command.Parameters.Add(new MySqlParameter("p_formname", MySqlDbType.VarChar, 1024));
                        commonHelper.SetSqlParameterValue(command.Parameters["p_formname"], oasformsinfomodel.OASFormName);

                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], oasformsinfomodel.orgmodel.LoggedUserID);


                        //***********INPUT PARAMETERS BLOCK END*****************

                        //***********INPUT PARAMETERS BLOCK END*****************

                        //**********OUT PUT PARAMETERS BLOCK START***************
                        //**********REGULAR OUT PUT PARAMETERS BLOCK START***************

                        commonHelper.SetRegularOutputSqlParameters(command);

                        //**********REGULAR OUT PUT PARAMETERS BLOCK END***************
                        //**********OUT PUT PARAMETERS BLOCK END***************


                        using (IDataReader reader = await command.ExecuteReaderAsync())
                        {
                            responseModel = new OASFormsInfoModel();
                            responseModel.oasformsinfomodelList = new List<OASFormsInfoModel>();

                            while (reader.Read())
                            {
                                responseModel.oasformsinfomodelList.Add(new OASFormsInfoModel()
                                {
                                    OASFormName = commonHelper.GetReaderString(reader, "formname"),
                                    FormID = commonHelper.GetReaderInt64(reader, "formid"),
                                    OASFormNameInfoGUID = commonHelper.GetReaderInt64(reader, "formid").ToString()
                                });
                            }
                        }


                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();
                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********


                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 

                        //if sp is not executed successfully / the sp is executed with errors 
                        // ie RequestExecutionStatus with have negative value
                        if (responseModel == null)
                            responseModel = new OASFormsInfoModel();

                        //Calling Method to assign the data related to the OutPut Parameters of the Base Class.
                        commonHelper.GetOutParameterValuesWithResponseModel(command, responseModel);


                    }
                }
            }
            finally
            {

            }

            return responseModel;
        }

        public async Task<ResponseModel> SaveAndUpdateFieldsInformation(OASFieldsInformationModel oasfieldsinfomodel)
        {
            ResponseModel responseModel = null;

            try
            {
                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMasterDataBaseConnectionString(CommonHelper.DBToConnect.OASMATER)))
                    {
                        await con.OpenAsync();

                        MySqlCommand command = new MySqlCommand("usp_oas_master_field_insert", con);

                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        command.Parameters.Add(new MySqlParameter("p_fieldid", MySqlDbType.Int64));
                        commonHelper.SetSqlParameterInt64(command.Parameters["p_fieldid"], oasfieldsinfomodel.FieldID);

                        command.Parameters.Add(new MySqlParameter("p_groupid", MySqlDbType.Int64));
                        commonHelper.SetSqlParameterInt64(command.Parameters["p_groupid"], oasfieldsinfomodel.OASFiledsGroupID);

                        command.Parameters.Add(new MySqlParameter("p_formid", MySqlDbType.Int64));
                        commonHelper.SetSqlParameterInt64(command.Parameters["p_formid"], oasfieldsinfomodel.OASFormNameInfoID);


                        command.Parameters.Add(new MySqlParameter("p_fieldname", MySqlDbType.VarChar, 1024));
                        commonHelper.SetSqlParameterValue(command.Parameters["p_fieldname"], oasfieldsinfomodel.OASFiledName);



                        command.Parameters.Add(new MySqlParameter("p_fielddatatype", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_fielddatatype"], (int) oasfieldsinfomodel.FieldType);


                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], oasfieldsinfomodel.orgmodel.LoggedUserID);


                        commonHelper.SetRegularOutputSqlParameters(command);


                        await command.ExecuteNonQueryAsync();

                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();
                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********


                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 

                        //if sp is not executed successfully / the sp is executed with errors 
                        // ie RequestExecutionStatus with have negative value
                        if (responseModel == null)
                            responseModel = new ResponseModel();

                        //Calling Method to assign the data related to the OutPut Parameters of the Base Class.
                        commonHelper.GetOutParameterValuesWithResponseModel(command, responseModel);
                    }
                }
            }

            finally
            {

            }

            return responseModel;

        }

        public async Task<ResponseModel> DeleteFieldInformation(OASFieldsInformationModel oasfieldinfomodel)
        {
            ResponseModel responseModel = null;

            try
            {
                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMasterDataBaseConnectionString(CommonHelper.DBToConnect.OASMATER)))
                    {
                        await con.OpenAsync();

                        //***********INPUT PARAMETERS BLOCK END*****************
                        MySqlCommand command = new MySqlCommand("usp_oas_master_field_delete", con);
                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        //***********INPUT PARAMETERS BLOCK END*****************

                        command.Parameters.Add(new MySqlParameter("p_fieldid", MySqlDbType.Int64));

                        commonHelper.SetSqlParameterInt64(command.Parameters["p_fieldid"], oasfieldinfomodel.FieldID);

                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], oasfieldinfomodel.orgmodel.LoggedUserID);


                        commonHelper.SetRegularOutputSqlParameters(command);


                        await command.ExecuteNonQueryAsync();

                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();
                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********


                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 

                        //if sp is not executed successfully / the sp is executed with errors 
                        // ie RequestExecutionStatus with have negative value
                        if (responseModel == null)
                            responseModel = new ResponseModel();

                        //Calling Method to assign the data related to the OutPut Parameters of the Base Class.
                        commonHelper.GetOutParameterValuesWithResponseModel(command, responseModel);
                    }
                }
            }
            finally
            {

            }

            return responseModel;
        }


        public async Task<OASFieldsInformationModel> GetFieldsInfoList(OASFieldsInformationModel fieldsInformationModel)
        {
            OASFieldsInformationModel responseModel = null;

            try
            {
                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMasterDataBaseConnectionString(CommonHelper.DBToConnect.OASMATER)))
                    {
                        await con.OpenAsync();

                        MySqlCommand command = new MySqlCommand("usp_oas_master_fields_list", con);

                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        command.Parameters.Add(new MySqlParameter("p_fieldname", MySqlDbType.VarChar, 1024));
                        commonHelper.SetSqlParameterValue(command.Parameters["p_fieldname"], fieldsInformationModel.OASFiledName);

                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], fieldsInformationModel.orgmodel.LoggedUserID);


                        //***********INPUT PARAMETERS BLOCK END*****************

                        //***********INPUT PARAMETERS BLOCK END*****************

                        //**********OUT PUT PARAMETERS BLOCK START***************
                        //**********REGULAR OUT PUT PARAMETERS BLOCK START***************

                        commonHelper.SetRegularOutputSqlParameters(command);

                        //**********REGULAR OUT PUT PARAMETERS BLOCK END***************
                        //**********OUT PUT PARAMETERS BLOCK END***************


                        using (IDataReader reader = await command.ExecuteReaderAsync())
                        {
                            responseModel = new OASFieldsInformationModel();
                            responseModel.oasfieldsinformationmodelList = new List<OASFieldsInformationModel>();

                            while (reader.Read())
                            {
                                responseModel.oasfieldsinformationmodelList.Add(new OASFieldsInformationModel()
                                {
                                    OASFormName = commonHelper.GetReaderString(reader, "formname"),
                                    OASFormNameInfoID = commonHelper.GetReaderInt64(reader, "formid").ToString(),
                                    OASFieldNameInfoGUID = commonHelper.GetReaderInt64(reader, "fieldid").ToString(),
                                    OASFiledsGroupID = commonHelper.GetReaderInt32(reader, "groupid"),
                                    OASFiledName = commonHelper.GetReaderString(reader, "fieldname"),
                                    FieldID = commonHelper.GetReaderInt64(reader, "fieldid"),
                                    FieldType = (FieldDataType)commonHelper.GetReaderInt32(reader, "fielddatatype", 0),
                                    FieldTypeDesc = commonHelper.GetReaderString(reader, "datatypedesc"),
                                });
                            }
                        }


                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();
                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********


                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 

                        //if sp is not executed successfully / the sp is executed with errors 
                        // ie RequestExecutionStatus with have negative value
                        if (responseModel == null)
                            responseModel = new OASFieldsInformationModel();

                        //Calling Method to assign the data related to the OutPut Parameters of the Base Class.
                        commonHelper.GetOutParameterValuesWithResponseModel(command, responseModel);
                    }
                }
            }

            catch (Exception e)
            {
                throw e;
            }

            finally
            {

            }

            return responseModel;

        }


        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {

            }
        }
        #endregion
    }
}

