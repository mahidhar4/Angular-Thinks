﻿using MySql.Data.MySqlClient;
using OAS_App_Common;
using OAS_App_DataAccess.commonhelper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace OAS_App_DataAccess.common
{


    public class EmployeeAuthorization : IDisposable
    {

        #region   "    COMMON DATA BASE ACTIONS      "

        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING THE CURRENT LOGGING IN EMPLOYEE INFORMATION
        /// </summary>
        /// <param name="baseModel"></param>
        /// <returns></returns>
        public async Task<BaseModel> GetEmployeeInfoByUserId(LoginModel baseModel)
        {
            BaseModel responseModel = null;

            try
            {
                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMasterDataBaseConnectionString(CommonHelper.DBToConnect.OASMATER)))
                    {

                        await con.OpenAsync();

                        //***********INPUT PARAMETERS BLOCK END*****************
                        MySqlCommand command = new MySqlCommand("usp_oas_user_authentication_byuserid", con);

                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        //***********INPUT PARAMETERS BLOCK END*****************


                        //command.Parameters.Add("@loggedUserID", MySqlDbType.Int32);


                        command.Parameters.Add(new MySqlParameter("p_userid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterValue(command.Parameters["p_userid"], baseModel.UserID.ToString());

                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], baseModel.orgmodel.LoggedUserID);



                        //***********INPUT PARAMETERS BLOCK END*****************

                        //***********INPUT PARAMETERS BLOCK END*****************

                        //**********OUT PUT PARAMETERS BLOCK START***************
                        //**********REGULAR OUT PUT PARAMETERS BLOCK START***************

                        commonHelper.SetRegularOutputSqlParameters(command);

                        //**********REGULAR OUT PUT PARAMETERS BLOCK END***************
                        //**********OUT PUT PARAMETERS BLOCK END***************


                        using (IDataReader drReader = await command.ExecuteReaderAsync())
                        {
                            if (drReader.Read())
                            {
                                responseModel = new BaseModel()
                                {
                                    orgmodel = new OrgModel()
                                    {
                                        LoggedUserID = commonHelper.GetReaderInt32(drReader, "userid"),
                                        LoggedUserType = commonHelper.GetReaderInt32(drReader, "usertype"),
                                        LoggedUserName = commonHelper.GetReaderString(drReader, "username"),
                                        OrganizationID = commonHelper.GetReaderInt32(drReader, "organizationid"),
                                        OrganizationName = commonHelper.GetReaderString(drReader, "organizationame"),
                                    },
                                };

                            }
                        }


                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();
                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********


                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 

                        //if sp is not executed successfully / the sp is executed with errors 
                        // ie RequestExecutionStatus with have negative value
                        if (responseModel == null)
                            responseModel = new BaseModel();

                        //Calling Method to assign the data related to the OutPut Parameters of the Base Class.
                        commonHelper.GetOutParameterValuesWithResponseModel(command, responseModel);


                    }
                }
            }
            finally
            {

            }

            return responseModel;
        }

        #endregion


        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {

            }
        }
        #endregion
    }
}
