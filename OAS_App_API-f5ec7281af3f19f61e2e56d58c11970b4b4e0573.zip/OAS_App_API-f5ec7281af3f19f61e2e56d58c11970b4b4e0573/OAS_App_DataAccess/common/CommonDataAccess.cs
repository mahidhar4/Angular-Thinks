﻿using MySql.Data.MySqlClient;
using OAS_App_Common;
using OAS_App_Common.Common;
using OAS_App_Common.Organization;
using OAS_App_DataAccess.commonhelper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace OAS_App_DataAccess.common
{
    public class CommonDataAccess : IDisposable
    {
        public async Task<CommonSavingModel> ValidateEmployeeLeave(CommonSavingModel commonSavingModel)
        {
            CommonSavingModel responseModel = null;

            try
            {
                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMetaDataBaseConnectionString(CommonHelper.DBToConnect.OASMETA, commonSavingModel)))
                    {
                        await con.OpenAsync();

                        MySqlCommand command = new MySqlCommand("usp_oas_employees_apply_leave_validation", con);

                        command.CommandType = System.Data.CommandType.StoredProcedure;
                        //***********INPUT PARAMETERS BLOCK*****************

                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], commonSavingModel.orgmodel.LoggedUserID);

                        command.Parameters.Add(new MySqlParameter("p_userid", MySqlDbType.VarChar, 64));
                        commonHelper.SetSqlParameterValue(command.Parameters["p_userid"], commonSavingModel.orgmodel.loggedusergdsuid.ToString());

                        command.Parameters.Add(new MySqlParameter("p_fromdate", MySqlDbType.VarChar, 64));
                        commonHelper.SetSqlParameterValue(command.Parameters["p_fromdate"], commonSavingModel.Leave.LeaveFromDate);

                        command.Parameters.Add(new MySqlParameter("p_todate", MySqlDbType.VarChar, 64));
                        commonHelper.SetSqlParameterValue(command.Parameters["p_todate"], commonSavingModel.Leave.LeaveToDate);

                        //**********OUT PUT PARAMETERS BLOCK START***************
                        //**********REGULAR OUT PUT PARAMETERS BLOCK START***************

                        commonHelper.SetRegularOutputSqlParameters(command);

                        using (IDataReader reader = await command.ExecuteReaderAsync())
                        {
                            if (reader.Read())
                            {
                                responseModel = new CommonSavingModel()
                                {
                                    ResponseCnt = commonHelper.GetReaderInt32(reader, "p_return"),
                                };
                            }
                        }

                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();

                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********


                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 

                        //if sp is not executed successfully / the sp is executed with errors 
                        // ie RequestExecutionStatus with have negative value
                        if (responseModel == null)
                            responseModel = new CommonSavingModel();

                        //Calling Method to assign the data related to the OutPut Parameters of the Base Class.
                        commonHelper.GetOutParameterValuesWithResponseModel(command, responseModel);
                    }
                }
            }
            finally
            {

            }
            return responseModel;
        }

        public async Task<CommonSavingModel> ValidateShift(CommonSavingModel commonSavingModel)
        {
            CommonSavingModel responseModel = null;

            try
            {
                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMetaDataBaseConnectionString(CommonHelper.DBToConnect.OASMETA, commonSavingModel)))
                    {
                        await con.OpenAsync();

                        MySqlCommand command = new MySqlCommand("usp_oas_shifts_validation", con);
                        //***********INPUT PARAMETERS BLOCK*****************
                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], commonSavingModel.orgmodel.LoggedUserID);

                        command.Parameters.Add(new MySqlParameter("p_startdate", MySqlDbType.VarChar, 64));
                        commonHelper.SetSqlParameterValue(command.Parameters["p_startdate"], commonSavingModel.Shift.ShiftStartDate);

                        command.Parameters.Add(new MySqlParameter("p_enddate", MySqlDbType.VarChar, 64));
                        commonHelper.SetSqlParameterValue(command.Parameters["p_enddate"], commonSavingModel.Shift.ShiftEndDate);

                        command.Parameters.Add(new MySqlParameter("p_emprecordid", MySqlDbType.Int64));
                        commonHelper.SetSqlParameterInt64(command.Parameters["p_emprecordid"], commonSavingModel.Shift.EmpWithShiftID);

                        command.Parameters.Add(new MySqlParameter("p_recordid", MySqlDbType.Int64));
                        commonHelper.SetSqlParameterInt64(command.Parameters["p_recordid"], commonSavingModel.Shift.RecordID);

                        //**********OUT PUT PARAMETERS BLOCK START***************
                        //**********REGULAR OUT PUT PARAMETERS BLOCK START***************

                        commonHelper.SetRegularOutputSqlParameters(command);

                        using (IDataReader reader = await command.ExecuteReaderAsync())
                        {
                            if (reader.Read())
                            {
                                responseModel = new CommonSavingModel()
                                {
                                    ResponseCnt = commonHelper.GetReaderInt32(reader, "Cnt")
                                };
                            }
                        }

                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();

                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********


                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 

                        //if sp is not executed successfully / the sp is executed with errors 
                        // ie RequestExecutionStatus with have negative value
                        if (responseModel == null)
                            responseModel = new CommonSavingModel();

                        //Calling Method to assign the data related to the OutPut Parameters of the Base Class.
                        commonHelper.GetOutParameterValuesWithResponseModel(command, responseModel);
                    }
                }
            }
            finally
            {

            }
            return responseModel;
        }

        public async Task<DataTypeModel> GetDatatypesList(DataTypeModel datatypeModel)
        {
            DataTypeModel responseModel = null;

            try
            {
                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMasterDataBaseConnectionString(CommonHelper.DBToConnect.OASMATER)))
                    {

                        await con.OpenAsync();

                        MySqlCommand command = new MySqlCommand("usp_master_field_datatypes_list", con);

                        //***********INPUT PARAMETERS BLOCK*****************

                        command.CommandType = System.Data.CommandType.StoredProcedure;


                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], datatypeModel.orgmodel.LoggedUserID);



                        //**********OUT PUT PARAMETERS BLOCK START***************
                        //**********REGULAR OUT PUT PARAMETERS BLOCK START***************

                        commonHelper.SetRegularOutputSqlParameters(command);

                        //**********REGULAR OUT PUT PARAMETERS BLOCK END***************
                        //**********OUT PUT PARAMETERS BLOCK END***************
                        responseModel = new DataTypeModel();
                        responseModel.dataTypeModelList = new List<DataTypeModel>();
                        using (IDataReader drReader = await command.ExecuteReaderAsync())
                        {
                            while (drReader.Read())
                            {

                                responseModel.dataTypeModelList.Add(
                                    new DataTypeModel
                                    {
                                        DataTyeDesc = commonHelper.GetReaderString(drReader, "datatypedesc"),
                                        DataType = commonHelper.GetReaderInt32(drReader, "datatype"),
                                        DataStatus = commonHelper.GetReaderInt32(drReader, "datastatus"),
                                    }
                                );
                            }
                        }

                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();

                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********


                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 

                        //if sp is not executed successfully / the sp is executed with errors 
                        // ie RequestExecutionStatus with have negative value
                        if (responseModel == null)
                            responseModel = new DataTypeModel();

                        //Calling Method to assign the data related to the OutPut Parameters of the Base Class.
                        commonHelper.GetOutParameterValuesWithResponseModel(command, responseModel);


                    }
                }
            }

            finally
            {

            }

            return responseModel;
        }


        #region   "    COMMON DATA BASE ACTIONS      "

        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING THE CURRENT LOGGING IN EMPLOYEE INFORMATION
        /// </summary>
        /// <param name="baseModel"></param>
        /// <returns></returns>
        public async Task<BaseModel> GetEmployeeInfo(LoginModel baseModel)
        {
            BaseModel responseModel = null;

            try
            {
                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMasterDataBaseConnectionString(CommonHelper.DBToConnect.OASMATER)))
                    {

                        await con.OpenAsync();

                        //***********INPUT PARAMETERS BLOCK END*****************
                        MySqlCommand command = new MySqlCommand("usp_oas_user_authentication", con);

                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        //***********INPUT PARAMETERS BLOCK END*****************


                        //command.Parameters.Add("@loggedUserID", MySqlDbType.Int32);


                        command.Parameters.Add(new MySqlParameter("p_username", MySqlDbType.VarChar, 1024));
                        commonHelper.SetSqlParameterValue(command.Parameters["p_username"], baseModel.loggeduseremailid);

                        command.Parameters.Add(new MySqlParameter("p_userpassword", MySqlDbType.VarChar, 1024));
                        commonHelper.SetSqlParameterValue(command.Parameters["p_userpassword"], commonHelper.GetHashData(baseModel.loggeduserpassword));

                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], baseModel.orgmodel.LoggedUserID);





                        //***********INPUT PARAMETERS BLOCK END*****************

                        //***********INPUT PARAMETERS BLOCK END*****************

                        //**********OUT PUT PARAMETERS BLOCK START***************
                        //**********REGULAR OUT PUT PARAMETERS BLOCK START***************

                        commonHelper.SetRegularOutputSqlParameters(command);

                        //**********REGULAR OUT PUT PARAMETERS BLOCK END***************
                        //**********OUT PUT PARAMETERS BLOCK END***************


                        using (IDataReader drReader = await command.ExecuteReaderAsync())
                        {
                            if (drReader.Read())
                            {
                                responseModel = new BaseModel()
                                {
                                    orgmodel = new OrgModel()
                                    {
                                        LoggedUserID = commonHelper.GetReaderInt32(drReader, "userid"),
                                        LoggedUserType = commonHelper.GetReaderInt32(drReader, "usertype"),
                                        LoggedUserName = commonHelper.GetReaderString(drReader, "username"),
                                        OrganizationID = commonHelper.GetReaderInt32(drReader, "organizationid"),
                                        OrganizationName = commonHelper.GetReaderString(drReader, "organizationame"),
                                    },
                                };

                            }
                        }


                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();
                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********


                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 

                        //if sp is not executed successfully / the sp is executed with errors 
                        // ie RequestExecutionStatus with have negative value
                        if (responseModel == null)
                            responseModel = new BaseModel();

                        //Calling Method to assign the data related to the OutPut Parameters of the Base Class.
                        commonHelper.GetOutParameterValuesWithResponseModel(command, responseModel);


                    }
                }
            }
            finally
            {

            }

            return responseModel;
        }

        public async Task<CommonSavingModel> GetEmployeeLeaves(CommonSavingModel commonSavingModel)
        {
            CommonSavingModel responseModel = null;

            try
            {
                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMetaDataBaseConnectionString(CommonHelper.DBToConnect.OASMETA, commonSavingModel)))
                    {
                        await con.OpenAsync();

                        MySqlCommand command = new MySqlCommand("usp_leaves_list", con);

                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        MySqlParameter employeeNameParameter = new MySqlParameter("p_employeeName", MySqlDbType.VarChar, 64);
                        command.Parameters.Add(employeeNameParameter);

                        if (string.IsNullOrEmpty(commonSavingModel.Leave.LeaveApplyingEmployeeName.Trim()))
                            commonHelper.SetSqlParameterValue(command.Parameters["p_employeeName"], string.Empty);
                        else
                            commonHelper.SetSqlParameterValue(command.Parameters["p_employeeName"], commonSavingModel.Leave.LeaveApplyingEmployeeName);

                        MySqlParameter leaveStartingDateParameter = new MySqlParameter("p_leaveStartingDate", MySqlDbType.VarChar, 64);
                        command.Parameters.Add(leaveStartingDateParameter);
                        commonHelper.SetSqlParameterValue(command.Parameters["p_leaveStartingDate"], commonSavingModel.Leave.LeaveFromDate);

                        MySqlParameter leaveEndingDateParameter  = new MySqlParameter("p_leaveEndingDate", MySqlDbType.VarChar, 64);
                        command.Parameters.Add(leaveEndingDateParameter);
                        commonHelper.SetSqlParameterValue(command.Parameters["p_leaveEndingDate"], commonSavingModel.Leave.LeaveToDate);

                        MySqlParameter leaveStatusParameter = new MySqlParameter("p_leaveStatus", MySqlDbType.VarChar, 64);
                        command.Parameters.Add(leaveStatusParameter);
                        commonHelper.SetSqlParameterValue(command.Parameters["p_leaveStatus"], commonSavingModel.Leave.LeaveStatus);

                        //**********OUT PUT PARAMETERS BLOCK START***************
                        //**********REGULAR OUT PUT PARAMETERS BLOCK START***************

                        commonHelper.SetRegularOutputSqlParameters(command);



                        using (IDataReader reader = await command.ExecuteReaderAsync())
                        {
                            responseModel = new CommonSavingModel()
                            {
                                gridData = commonHelper.GetJSONArrayFromReader(reader)
                            };
                        }

                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();

                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********


                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 

                        //if sp is not executed successfully / the sp is executed with errors 
                        // ie RequestExecutionStatus with have negative value
                        if (responseModel == null)
                            responseModel = new CommonSavingModel();

                        //Calling Method to assign the data related to the OutPut Parameters of the Base Class.
                        commonHelper.GetOutParameterValuesWithResponseModel(command, responseModel);
                    }
                }
            }
            finally
            {

            }

            return responseModel;
        }


        /// <summary>
        /// THIS METHOD IS USED TO CHANGE THE EMPLOYEE PASSWORD
        /// </summary>
        /// ***** CREATED BY:   SANJAY IDPUGANTI *****
        /// ***** CREATED DATE: 4/30/2018        *****
        /// <param name="baseModel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> UpdateEmployeePassword(LoginModel baseModel)
        {
            ResponseModel responseModel = null;

            try
            {
                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMasterDataBaseConnectionString(CommonHelper.DBToConnect.OASMATER)))
                    {

                        await con.OpenAsync();

                        MySqlCommand command = new MySqlCommand("usp_oas_user_authentication_Update", con);

                        //***********INPUT PARAMETERS BLOCK*****************

                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        command.Parameters.Add(new MySqlParameter("p_userid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_userid"], baseModel.UserID);

                        command.Parameters.Add(new MySqlParameter("p_userpassword", MySqlDbType.VarChar, 1024));
                        commonHelper.SetSqlParameterValue(command.Parameters["p_userpassword"], commonHelper.GetHashData(baseModel.loggeduserpassword));

                        command.Parameters.Add(new MySqlParameter("p_userpassword_original", MySqlDbType.VarChar, 1024));
                        commonHelper.SetSqlParameterValue(command.Parameters["p_userpassword_original"], baseModel.loggeduserpassword);

                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], baseModel.orgmodel.LoggedUserID);

                        //**********OUT PUT PARAMETERS BLOCK START***************
                        //**********REGULAR OUT PUT PARAMETERS BLOCK START***************

                        commonHelper.SetRegularOutputSqlParameters(command);

                        //**********REGULAR OUT PUT PARAMETERS BLOCK END***************
                        //**********OUT PUT PARAMETERS BLOCK END***************

                        await command.ExecuteNonQueryAsync();

                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();

                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********


                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 

                        //if sp is not executed successfully / the sp is executed with errors 
                        // ie RequestExecutionStatus with have negative value
                        if (responseModel == null)
                            responseModel = new ResponseModel();

                        //Calling Method to assign the data related to the OutPut Parameters of the Base Class.
                        commonHelper.GetOutParameterValuesWithResponseModel(command, responseModel);
                    }
                }
            }
            finally
            {

            }

            return responseModel;
        }


        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING THE SAVING MODEL LIST TO SEND AS JSON TO THE DATA BASE
        /// </summary>
        /// <param name="commonsavingmodel"></param>
        /// <param name="recordID"></param>
        /// <returns></returns>
        public List<CommonSavingFieldsDBModel> GetFieldsSavingList(CommonSavingModel commonsavingmodel, long recordID)
        {
            List<CommonSavingFieldsDBModel> ListCommonSavingFieldsDBModel = null;

            try
            {

                ListCommonSavingFieldsDBModel = new List<CommonSavingFieldsDBModel>();

                foreach (CommonSavingFieldsModel item in commonsavingmodel.CommonSavingRowData.CommonSavingFieldsData)
                {
                    ListCommonSavingFieldsDBModel.Add(new CommonSavingFieldsDBModel()
                    {
                        fieldid = item.FieldID,
                        groupid = item.FieldGroupID,
                        sequenceingroup = item.FieldSeqNumber,
                        recordid = item.RecordID > 0 ? item.RecordID : recordID,
                        filedValue = item.FieldValue
                    });
                }
            }
            finally
            {

            }

            return ListCommonSavingFieldsDBModel;
        }


        /// <summary>
        /// THIS METHOD IS USEFUL IN SAVING/UPDATING THE COMMON META DATA
        /// </summary>
        /// <param name="commonsavingmodel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> SaveCommonMetaData(CommonSavingModel commonsavingmodel, long recordID)
        {
            ResponseModel responseModel = null;
            //long recordID = 0;

            try
            {

                //if (commonsavingmodel.CommonSavingRowData.CommonSavingFieldsData != null && commonsavingmodel.CommonSavingRowData.CommonSavingFieldsData[0].RecordID > 0)
                //    recordID = commonsavingmodel.CommonSavingRowData.CommonSavingFieldsData[0].RecordID;
                //else
                //{
                //    using (CommonHelper helperObj = new CommonHelper())
                //    {
                //        recordID = helperObj.GetRandomNumber_DateUTC_Int();
                //    }
                //}

                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMetaDataBaseConnectionString(CommonHelper.DBToConnect.OASMETA, commonsavingmodel)))
                    {

                        await con.OpenAsync();

                        //***********INPUT PARAMETERS BLOCK END*****************
                        MySqlCommand command = new MySqlCommand("usp_oas_savemetadata", con);//usp_oas_savemetadata_test

                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        //***********INPUT PARAMETERS BLOCK END*****************

                        command.Parameters.Add(new MySqlParameter("p_formid", MySqlDbType.Int64));
                        commonHelper.SetSqlParameterInt64(command.Parameters["p_formid"], commonsavingmodel.FormID);


                        command.Parameters.Add(new MySqlParameter("p_savingdata", MySqlDbType.JSON));
                        commonHelper.SetSqlParameterJSONData(command.Parameters["p_savingdata"], GetFieldsSavingList(commonsavingmodel, recordID));

                        command.Parameters.Add(new MySqlParameter("p_organizationid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_organizationid"], commonsavingmodel.orgmodel.OrganizationID);

                        command.Parameters.Add(new MySqlParameter("p_recordid", MySqlDbType.Int64));
                        commonHelper.SetSqlParameterInt64(command.Parameters["p_recordid"], recordID);

                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], commonsavingmodel.orgmodel.LoggedUserID);



                        //***********INPUT PARAMETERS BLOCK END*****************

                        //***********INPUT PARAMETERS BLOCK END*****************

                        //**********OUT PUT PARAMETERS BLOCK START***************
                        //**********REGULAR OUT PUT PARAMETERS BLOCK START***************

                        commonHelper.SetRegularOutputSqlParameters(command);

                        //**********REGULAR OUT PUT PARAMETERS BLOCK END***************
                        //**********OUT PUT PARAMETERS BLOCK END***************


                        await command.ExecuteNonQueryAsync();

                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();
                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********


                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 

                        //if sp is not executed successfully / the sp is executed with errors 
                        // ie RequestExecutionStatus with have negative value
                        if (responseModel == null)
                            responseModel = new ResponseModel();

                        //Calling Method to assign the data related to the OutPut Parameters of the Base Class.
                        commonHelper.GetOutParameterValuesWithResponseModel(command, responseModel);


                    }
                }
            }
            finally
            {

            }

            return responseModel;
        }



        /// <summary>
        /// THIS METHOD IS USEFUL IN DELETING THE COMMON META DETA 
        /// </summary>
        /// <param name="commonsavingmodel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> DeleteCommonMetaData(CommonSavingModel commonsavingmodel)
        {
            ResponseModel responseModel = null;

            try
            {


                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMetaDataBaseConnectionString(CommonHelper.DBToConnect.OASMETA, commonsavingmodel)))
                    {

                        await con.OpenAsync();

                        //***********INPUT PARAMETERS BLOCK END*****************
                        MySqlCommand command = new MySqlCommand("usp_oas_deletemetadata", con);

                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        //***********INPUT PARAMETERS BLOCK END*****************

                        command.Parameters.Add(new MySqlParameter("p_formid", MySqlDbType.Int64));
                        commonHelper.SetSqlParameterInt64(command.Parameters["p_formid"], commonsavingmodel.FormID);

                        command.Parameters.Add(new MySqlParameter("p_organizationid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_organizationid"], commonsavingmodel.orgmodel.OrganizationID);

                        command.Parameters.Add(new MySqlParameter("p_recordid", MySqlDbType.Int64));
                        commonHelper.SetSqlParameterInt64(command.Parameters["p_recordid"], commonsavingmodel.CommonSavingRowData.RecordID);

                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], commonsavingmodel.orgmodel.LoggedUserID);



                        //***********INPUT PARAMETERS BLOCK END*****************

                        //***********INPUT PARAMETERS BLOCK END*****************

                        //**********OUT PUT PARAMETERS BLOCK START***************
                        //**********REGULAR OUT PUT PARAMETERS BLOCK START***************

                        commonHelper.SetRegularOutputSqlParameters(command);

                        //**********REGULAR OUT PUT PARAMETERS BLOCK END***************
                        //**********OUT PUT PARAMETERS BLOCK END***************


                        await command.ExecuteNonQueryAsync();

                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();
                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********


                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 

                        //if sp is not executed successfully / the sp is executed with errors 
                        // ie RequestExecutionStatus with have negative value
                        if (responseModel == null)
                            responseModel = new ResponseModel();

                        //Calling Method to assign the data related to the OutPut Parameters of the Base Class.
                        commonHelper.GetOutParameterValuesWithResponseModel(command, responseModel);


                    }
                }
            }
            finally
            {

            }

            return responseModel;
        }


        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING THE STATE MAINTAIN EDIT MODE META DATA OF THE CURRENT RECORD
        /// </summary>
        /// <param name="commonsavingmodel"></param>
        /// <returns></returns>
        public async Task<CommonSavingModel> GetCommonMetaData_EditMode(CommonSavingModel commonsavingmodel)
        {
            CommonSavingModel responsemodel = null;

            try
            {


                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMetaDataBaseConnectionString(CommonHelper.DBToConnect.OASMETA, commonsavingmodel)))
                    {

                        await con.OpenAsync();

                        //***********INPUT PARAMETERS BLOCK END*****************
                        MySqlCommand command = new MySqlCommand("usp_oas_metadata_table_Get", con);

                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        //***********INPUT PARAMETERS BLOCK END*****************

                        command.Parameters.Add(new MySqlParameter("p_formid", MySqlDbType.Int64));
                        commonHelper.SetSqlParameterInt64(command.Parameters["p_formid"], commonsavingmodel.FormID);

                        command.Parameters.Add(new MySqlParameter("p_recordid", MySqlDbType.Int64));
                        commonHelper.SetSqlParameterInt64(command.Parameters["p_recordid"], commonsavingmodel.CommonSavingRowData.RecordID);

                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], commonsavingmodel.orgmodel.LoggedUserID);



                        //***********INPUT PARAMETERS BLOCK END*****************

                        //***********INPUT PARAMETERS BLOCK END*****************

                        //**********OUT PUT PARAMETERS BLOCK START***************
                        //**********REGULAR OUT PUT PARAMETERS BLOCK START***************

                        commonHelper.SetRegularOutputSqlParameters(command);

                        //**********REGULAR OUT PUT PARAMETERS BLOCK END***************
                        //**********OUT PUT PARAMETERS BLOCK END***************

                        responsemodel = new CommonSavingModel();
                        //responsemodel.CommonSavingFieldsData = new List<CommonSavingFieldsModel>();

                        responsemodel.CommonSavingRowData = new CommonSavingRowsFieldsModel();

                        responsemodel.CommonSavingRowData.CommonSavingFieldsData = new List<CommonSavingFieldsModel>();

                        using (IDataReader Entityitem = await command.ExecuteReaderAsync())
                        {
                            while (Entityitem.Read())
                            {
                                CommonSavingFieldsModel commonSavingFieldsModel = new CommonSavingFieldsModel();

                                commonSavingFieldsModel.FieldID = commonHelper.GetReaderInt64(Entityitem, "fieldid");
                                commonSavingFieldsModel.FieldValue = commonHelper.GetReaderString(Entityitem, "filedValue");
                                commonSavingFieldsModel.FieldGroupID = commonHelper.GetReaderInt64(Entityitem, "groupid");
                                commonSavingFieldsModel.FieldSeqNumber = commonHelper.GetReaderInt64(Entityitem, "sequenceingroup");
                                commonSavingFieldsModel.RecordID = commonHelper.GetReaderInt64(Entityitem, "RecordID");
                                commonSavingFieldsModel.RecordDataID = commonHelper.GetReaderInt64(Entityitem, "RecordDataID");
                                responsemodel.CommonSavingRowData.CommonSavingFieldsData.Add(commonSavingFieldsModel);
                            }
                        }



                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();
                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********


                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 

                        //if sp is not executed successfully / the sp is executed with errors 
                        // ie RequestExecutionStatus with have negative value
                        if (responsemodel == null)
                            responsemodel = new CommonSavingModel();

                        //Calling Method to assign the data related to the OutPut Parameters of the Base Class.
                        commonHelper.GetOutParameterValuesWithResponseModel(command, responsemodel);


                    }
                }
            }
            finally
            {

            }

            return responsemodel;
        }



        /// <summary>
        /// USEFUL IN GETTING THE CUSTOMIZED REPORT SELECT FIELDS LIST
        /// </summary>
        /// <param name="reportsSelectFields"></param>
        /// <returns></returns>
        public async Task<ReportsSelectFields> GetReportsSelectFieldsList(ReportsSelectFields reportsSelectFields)
        {
            ReportsSelectFields responseModel = null;
            try
            {
                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMasterDataBaseConnectionString(CommonHelper.DBToConnect.OASMATER)))
                    {
                        await con.OpenAsync();

                        MySqlCommand command = new MySqlCommand("usp_oas_reports_selectfields_list", con);//usp_oas_master_Reports_Involved_Select_List

                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        command.Parameters.Add(new MySqlParameter("p_ReportID", MySqlDbType.Int64));
                        commonHelper.SetSqlParameterInt64(command.Parameters["p_ReportID"], reportsSelectFields.ReportID);

                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], reportsSelectFields.orgmodel.LoggedUserID);

                        //***********INPUT PARAMETERS BLOCK END*****************

                        //***********INPUT PARAMETERS BLOCK END*****************

                        //**********OUT PUT PARAMETERS BLOCK START***************
                        //**********REGULAR OUT PUT PARAMETERS BLOCK START***************

                        commonHelper.SetRegularOutputSqlParameters(command);

                        //**********REGULAR OUT PUT PARAMETERS BLOCK END***************
                        //**********OUT PUT PARAMETERS BLOCK END***************                    

                        using (IDataReader reader = await command.ExecuteReaderAsync())
                        {
                            responseModel = new ReportsSelectFields();

                            responseModel.ReportsSelectFieldsList = new List<ReportsSelectFields>();

                            while (reader.Read())
                            {
                                responseModel.ReportsSelectFieldsList.Add(new ReportsSelectFields
                                {
                                    FormID = commonHelper.GetReaderInt64(reader, "formid"),
                                    FormName = commonHelper.GetReaderString(reader, "formname"),
                                    FieldName = commonHelper.GetReaderString(reader, "fieldname"),
                                    GroupID = commonHelper.GetReaderInt32(reader, "groupid"),
                                    FieldID = commonHelper.GetReaderInt64(reader, "fieldid"),
                                    ReportID = commonHelper.GetReaderInt64(reader, "ReportID"),
                                    FormIDToTakeForDefaultField = commonHelper.GetReaderString(reader, "FormIDToTakeForDefaultField")

                                    //TableAliasName = commonHelper.GetReaderString(reader, "AliasName"),
                                    //FieldNameWithAlias = commonHelper.GetReaderString(reader, "columnfieldname"),
                                });
                            }
                        }

                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();

                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********


                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 

                        //if sp is not executed successfully / the sp is executed with errors 
                        // ie RequestExecutionStatus with have negative value
                        if (responseModel == null)
                            responseModel = new ReportsSelectFields();

                        //Calling Method to assign the data related to the OutPut Parameters of the Base Class.
                        commonHelper.GetOutParameterValuesWithResponseModel(command, responseModel);
                    }
                }
            }

            finally
            {

            }

            return responseModel;
        }









        public async Task<ReportsSelectFields> GetReportsLinkedAllFormFieldsList(ReportsSelectFields reportsSelectFields)
        {
            ReportsSelectFields responseModel = null;
            try
            {
                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMasterDataBaseConnectionString(CommonHelper.DBToConnect.OASMATER)))
                    {
                        await con.OpenAsync();

                        MySqlCommand command = new MySqlCommand("usp_oas_master_Form_Report_Linked_Fields_list", con);//usp_oas_master_Reports_Involved_Select_List // fin : usp_oas_master_Form_Linked_Fields_list

                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        command.Parameters.Add(new MySqlParameter("p_ReportID", MySqlDbType.Int64));
                        commonHelper.SetSqlParameterInt64(command.Parameters["p_ReportID"], reportsSelectFields.ReportID);

                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], reportsSelectFields.orgmodel.LoggedUserID);

                        //***********INPUT PARAMETERS BLOCK END*****************

                        //***********INPUT PARAMETERS BLOCK END*****************

                        //**********OUT PUT PARAMETERS BLOCK START***************
                        //**********REGULAR OUT PUT PARAMETERS BLOCK START***************

                        commonHelper.SetRegularOutputSqlParameters(command);

                        //**********REGULAR OUT PUT PARAMETERS BLOCK END***************
                        //**********OUT PUT PARAMETERS BLOCK END***************                    

                        using (IDataReader reader = await command.ExecuteReaderAsync())
                        {
                            responseModel = new ReportsSelectFields();

                            responseModel.ReportsSelectFieldsList = new List<ReportsSelectFields>();

                            while (reader.Read())
                            {
                                responseModel.ReportsSelectFieldsList.Add(new ReportsSelectFields
                                {
                                    FormID = commonHelper.GetReaderInt64(reader, "formid"),
                                    FieldID = commonHelper.GetReaderInt64(reader, "fieldid"),
                                    FieldName = commonHelper.GetReaderString(reader, "fieldname"),
                                    FormIDToTakeForDefaultField = commonHelper.GetReaderString(reader, "FormIDToTakeForDefaultField")

                                    //GroupID = commonHelper.GetReaderInt32(reader, "groupid"),
                                    //ReportID = commonHelper.GetReaderInt64(reader, "ReportID"),
                                    //FormName = commonHelper.GetReaderString(reader, "formname"),

                                    ////TableAliasName = commonHelper.GetReaderString(reader, "AliasName"),
                                    ////FieldNameWithAlias = commonHelper.GetReaderString(reader, "columnfieldname"),
                                });
                            }
                        }

                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();

                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********


                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 

                        //if sp is not executed successfully / the sp is executed with errors 
                        // ie RequestExecutionStatus with have negative value
                        if (responseModel == null)
                            responseModel = new ReportsSelectFields();

                        //Calling Method to assign the data related to the OutPut Parameters of the Base Class.
                        commonHelper.GetOutParameterValuesWithResponseModel(command, responseModel);
                    }
                }
            }

            finally
            {

            }

            return responseModel;
        }


        /// <summary>
        ///  USEFUL IN GETTING THE CUSTOMIZED REPORT FILTER FIELDS LIST
        /// </summary>
        /// <param name="reportsFilterFields"></param>
        /// <returns></returns>
        public async Task<ReportsFilterFields> GetReportsFilterFieldsList(ReportsFilterFields reportsFilterFields)
        {
            ReportsFilterFields responseModel = null;

            try
            {
                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMasterDataBaseConnectionString(CommonHelper.DBToConnect.OASMATER)))
                    {
                        await con.OpenAsync();

                        MySqlCommand command = new MySqlCommand("usp_oas_reports_filterfields_list", con);

                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        command.Parameters.Add(new MySqlParameter("p_ReportID", MySqlDbType.Int64));
                        commonHelper.SetSqlParameterInt64(command.Parameters["p_ReportID"], reportsFilterFields.ReportID);

                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], reportsFilterFields.orgmodel.LoggedUserID);

                        //***********INPUT PARAMETERS BLOCK END*****************

                        //***********INPUT PARAMETERS BLOCK END*****************

                        //**********OUT PUT PARAMETERS BLOCK START***************
                        //**********REGULAR OUT PUT PARAMETERS BLOCK START***************

                        commonHelper.SetRegularOutputSqlParameters(command);

                        //**********REGULAR OUT PUT PARAMETERS BLOCK END***************
                        //**********OUT PUT PARAMETERS BLOCK END***************



                        using (IDataReader reader = await command.ExecuteReaderAsync())
                        {
                            responseModel = new ReportsFilterFields();

                            responseModel.ReportsFilterFieldsList = new List<ReportsFilterFields>();

                            while (reader.Read())
                            {
                                responseModel.ReportsFilterFieldsList.Add(new ReportsFilterFields
                                {
                                    ReportID = commonHelper.GetReaderInt64(reader, "ReportID"),
                                    FieldID = commonHelper.GetReaderInt64(reader, "fieldid"),
                                    FormID = commonHelper.GetReaderInt64(reader, "formid"),
                                    FormName = commonHelper.GetReaderString(reader, "formname"),
                                    GroupID = commonHelper.GetReaderInt32(reader, "groupid"),
                                    FieldName = commonHelper.GetReaderString(reader, "fieldname"),
                                    ConditionType = (ReportsConditionType)commonHelper.GetReaderInt32(reader, "Reports_Customization_Filter_Field_ConditionType"),
                                    FilterFieldInfoID = commonHelper.GetReaderInt64(reader, "Reports_Customization_Filter_FieldInfoId"),
                                    ConditionMode = (ReportsConditionMode)commonHelper.GetReaderInt32(reader, "Reports_Customization_Filter_Field_Condition"),
                                    DefaultFieldValue = commonHelper.GetReaderString(reader, "DefaultFieldValue"),
                                    FieldDataType = (FieldDataType)commonHelper.GetReaderInt32(reader, "fielddatatype"),
                                    sequencenumber = commonHelper.GetReaderInt32(reader, "sequencenumber")
                                });
                            }
                        }

                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();

                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********


                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 

                        //if sp is not executed successfully / the sp is executed with errors 
                        // ie RequestExecutionStatus with have negative value
                        if (responseModel == null)
                            responseModel = new ReportsFilterFields();

                        //Calling Method to assign the data related to the OutPut Parameters of the Base Class.
                        commonHelper.GetOutParameterValuesWithResponseModel(command, responseModel);

                    }
                }
            }

            finally { }

            return responseModel;
        }

        /// <summary>
        ///  USEFUL IN GETTING THE CUSTOMIZED REPORT TABLES/FORMS INVOLVED LIST
        /// </summary>
        /// <param name="reportsFormTablesInvolved"></param>
        /// <returns></returns>
        public async Task<ReportsFormTablesInvolved> GetReportsFormTablesInvolvedList(ReportsFormTablesInvolved reportsFormTablesInvolved)
        {
            ReportsFormTablesInvolved responceModel = null;

            try
            {
                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMasterDataBaseConnectionString(CommonHelper.DBToConnect.OASMATER)))
                    {
                        await con.OpenAsync();

                        MySqlCommand command = new MySqlCommand("usp_oas_reports_tablesinvolved_list", con);//

                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        command.Parameters.Add(new MySqlParameter("p_ReportID", MySqlDbType.Int64));
                        commonHelper.SetSqlParameterInt64(command.Parameters["p_ReportID"], reportsFormTablesInvolved.ReportID);

                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], reportsFormTablesInvolved.orgmodel.LoggedUserID);

                        //***********INPUT PARAMETERS BLOCK END*****************

                        //***********INPUT PARAMETERS BLOCK END*****************

                        //**********OUT PUT PARAMETERS BLOCK START***************
                        //**********REGULAR OUT PUT PARAMETERS BLOCK START***************

                        commonHelper.SetRegularOutputSqlParameters(command);

                        //**********REGULAR OUT PUT PARAMETERS BLOCK END***************
                        //**********OUT PUT PARAMETERS BLOCK END***************

                        responceModel = new ReportsFormTablesInvolved();

                        responceModel.ReportsFormTablesInvolvedList = new List<ReportsFormTablesInvolved>();

                        using (IDataReader reader = await command.ExecuteReaderAsync())
                        {
                            while (reader.Read())
                            {

                                ReportsFormTablesInvolved temp = new ReportsFormTablesInvolved()
                                {
                                    //ReportID = commonHelper.GetReaderInt64(reader, "ReportID"),
                                    InvolvedTable1FormID = commonHelper.GetReaderInt64(reader, "InvolvedTable1FormID"),
                                    InvolvedTable2FormID = commonHelper.GetReaderInt64Nullable(reader, "InvolvedTable2FormID"),
                                    InvolvmentSequenceNumberTable = commonHelper.GetReaderInt32(reader, "InvolmentSequenceNumber"),
                                    InvolvmentJoinType = (InvolvmentJoinType)commonHelper.GetReaderInt32(reader, "InvolmentJoinType", 0),
                                    ReportsFormTablesInvolvedInfoID = commonHelper.GetReaderInt32(reader, "Reports_Customization_TablesInvolvedInfoID"),
                                    //TableAliasName = commonHelper.GetReaderString(reader, "AliasName")
                                };

                                //int? test = commonHelper.GetReaderInt32Nullable(reader, "InvolmentJoinType");

                                //if (test != null)
                                //{
                                //    temp.InvolvmentJoinType = (InvolvmentJoinType)test;
                                //}

                                responceModel.ReportsFormTablesInvolvedList.Add(temp);
                            }
                        }

                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();

                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********


                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 

                        //if sp is not executed successfully / the sp is executed with errors 
                        // ie RequestExecutionStatus with have negative value
                        if (responceModel == null)
                            responceModel = new ReportsFormTablesInvolved();

                        //Calling Method to assign the data related to the OutPut Parameters of the Base Class.
                        commonHelper.GetOutParameterValuesWithResponseModel(command, responceModel);
                    }
                }
            }

            finally { }

            return responceModel;
        }


        public async Task<ReportsFormTablesInvolved> GetReportsFormTablesInvolvedUniqueList(ReportsFormTablesInvolved reportsFormTablesInvolved)
        {
            ReportsFormTablesInvolved responceModel = null;

            try
            {
                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMasterDataBaseConnectionString(CommonHelper.DBToConnect.OASMATER)))
                    {
                        await con.OpenAsync();

                        MySqlCommand command = new MySqlCommand("usp_oas_master_Reports_Involved_Unique_Tables_List", con);//usp_oas_reports_tablesinvolved_list

                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        command.Parameters.Add(new MySqlParameter("p_ReportID", MySqlDbType.Int64));
                        commonHelper.SetSqlParameterInt64(command.Parameters["p_ReportID"], reportsFormTablesInvolved.ReportID);

                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], reportsFormTablesInvolved.orgmodel.LoggedUserID);

                        //***********INPUT PARAMETERS BLOCK END*****************

                        //***********INPUT PARAMETERS BLOCK END*****************

                        //**********OUT PUT PARAMETERS BLOCK START***************
                        //**********REGULAR OUT PUT PARAMETERS BLOCK START***************

                        commonHelper.SetRegularOutputSqlParameters(command);

                        //**********REGULAR OUT PUT PARAMETERS BLOCK END***************
                        //**********OUT PUT PARAMETERS BLOCK END***************

                        responceModel = new ReportsFormTablesInvolved();

                        responceModel.ReportsFormTablesInvolvedList = new List<ReportsFormTablesInvolved>();

                        using (IDataReader reader = await command.ExecuteReaderAsync())
                        {
                            while (reader.Read())
                            {
                                ReportsFormTablesInvolved temp = new ReportsFormTablesInvolved()
                                {
                                    UniqueFormID = commonHelper.GetReaderInt64(reader, "FormID"),
                                };

                                if (temp.UniqueFormID > 0)
                                    responceModel.ReportsFormTablesInvolvedList.Add(temp);
                            }
                        }

                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();

                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********


                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 

                        //if sp is not executed successfully / the sp is executed with errors 
                        // ie RequestExecutionStatus with have negative value
                        if (responceModel == null)
                            responceModel = new ReportsFormTablesInvolved();

                        //Calling Method to assign the data related to the OutPut Parameters of the Base Class.
                        commonHelper.GetOutParameterValuesWithResponseModel(command, responceModel);
                    }
                }
            }

            finally { }

            return responceModel;
        }




        /// <summary>
        /// ADDED BY : MAHESH P
        /// ADDED ON : 05/02/2018
        /// THIS METHOD IS USEFUL IN GETTING THE REPORTS SORTING FIELDS LIST
        /// </summary>
        /// <param name="reportsFilterFields"></param>
        /// <returns></returns>
        public async Task<ReportsFilterFields> GetReportsSortFieldsList(ReportsFilterFields reportsFilterFields)
        {
            ReportsFilterFields responseModel = null;

            try
            {
                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMasterDataBaseConnectionString(CommonHelper.DBToConnect.OASMATER)))
                    {
                        await con.OpenAsync();

                        MySqlCommand command = new MySqlCommand("usp_oas_master_Reports_sorting_fields_list", con);

                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        command.Parameters.Add(new MySqlParameter("p_ReportID", MySqlDbType.Int64));
                        commonHelper.SetSqlParameterInt64(command.Parameters["p_ReportID"], reportsFilterFields.ReportID);

                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], reportsFilterFields.orgmodel.LoggedUserID);

                        //***********INPUT PARAMETERS BLOCK END*****************

                        //***********INPUT PARAMETERS BLOCK END*****************

                        //**********OUT PUT PARAMETERS BLOCK START***************
                        //**********REGULAR OUT PUT PARAMETERS BLOCK START***************

                        commonHelper.SetRegularOutputSqlParameters(command);

                        //**********REGULAR OUT PUT PARAMETERS BLOCK END***************
                        //**********OUT PUT PARAMETERS BLOCK END***************



                        using (IDataReader reader = await command.ExecuteReaderAsync())
                        {
                            responseModel = new ReportsFilterFields();

                            responseModel.ReportsFilterFieldsList = new List<ReportsFilterFields>();

                            while (reader.Read())
                            {
                                responseModel.ReportsFilterFieldsList.Add(new ReportsFilterFields
                                {
                                    ReportID = commonHelper.GetReaderInt64(reader, "ReportID"),
                                    FieldID = commonHelper.GetReaderInt64(reader, "fieldid"),
                                    FormID = commonHelper.GetReaderInt64(reader, "formid"),
                                    sortorder = (SortOrder)commonHelper.GetReaderInt32(reader, "sortorder", 0),
                                    sequencenumber = commonHelper.GetReaderInt32(reader, "SequenceNumber", 0),
                                    FieldDataType = (FieldDataType)commonHelper.GetReaderInt32(reader, "fielddatatype", 0),
                                });
                            }
                        }

                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();

                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********


                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 

                        //if sp is not executed successfully / the sp is executed with errors 
                        // ie RequestExecutionStatus with have negative value
                        if (responseModel == null)
                            responseModel = new ReportsFilterFields();

                        //Calling Method to assign the data related to the OutPut Parameters of the Base Class.
                        commonHelper.GetOutParameterValuesWithResponseModel(command, responseModel);

                    }
                }
            }

            finally { }

            return responseModel;
        }




        /// <summary>
        ///  USEFUL IN GETTING THE CUSTOMIZED REPORT TABLES/FORMS INVOLVED COLUMNS/FIELDS LIST
        /// </summary>
        /// <param name="tableColumnsFieldsInvolved"></param>
        /// <returns></returns>
        public async Task<ReportsFormTableColumnsFieldsInvolved> GetReportsFormTableInvolvedColumnsFieldsList(ReportsFormTableColumnsFieldsInvolved tableColumnsFieldsInvolved)
        {
            ReportsFormTableColumnsFieldsInvolved responceModel = null;

            try
            {
                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMasterDataBaseConnectionString(CommonHelper.DBToConnect.OASMATER)))
                    {
                        await con.OpenAsync();

                        // usp_oas_master_Reports_Involved_Tables_Join_Columns_List
                        MySqlCommand command = new MySqlCommand("usp_oas_reports_tablesinvolved_columnsfieldsinvolved_list", con);

                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        //command.Parameters.Add(new MySqlParameter("p_Reports_Customization_TablesInvolvedInfoID", MySqlDbType.Int64));
                        //commonHelper.SetSqlParameterInt64(command.Parameters["p_Reports_Customization_TablesInvolvedInfoID"], tableColumnsFieldsInvolved.ReportsFormTablesInvolvedInfoID);

                        command.Parameters.Add(new MySqlParameter("p_ReportID", MySqlDbType.Int64));
                        commonHelper.SetSqlParameterInt64(command.Parameters["p_ReportID"], tableColumnsFieldsInvolved.ReportID);


                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], tableColumnsFieldsInvolved.orgmodel.LoggedUserID);

                        //***********INPUT PARAMETERS BLOCK END*****************

                        //***********INPUT PARAMETERS BLOCK END*****************

                        //**********OUT PUT PARAMETERS BLOCK START***************
                        //**********REGULAR OUT PUT PARAMETERS BLOCK START***************

                        commonHelper.SetRegularOutputSqlParameters(command);

                        //**********REGULAR OUT PUT PARAMETERS BLOCK END***************
                        //**********OUT PUT PARAMETERS BLOCK END***************


                        using (IDataReader reader = await command.ExecuteReaderAsync())
                        {
                            responceModel = new ReportsFormTableColumnsFieldsInvolved();

                            responceModel.ReportsFormTableColumnsFieldsInvolvedList = new List<ReportsFormTableColumnsFieldsInvolved>();

                            while (reader.Read())
                            {

                                responceModel.ReportsFormTableColumnsFieldsInvolvedList.Add(new ReportsFormTableColumnsFieldsInvolved
                                {
                                    InvolvedTable1ColumnFieldID = commonHelper.GetReaderInt64(reader, "InvolvedTable1ColumnFieldID"),
                                    InvolvedTable2ColumnFieldID = commonHelper.GetReaderInt64(reader, "InvolvedTable2ColumnFieldID"),
                                    InvolvedTable1ColumnFieldDefaultValue = commonHelper.GetReaderString(reader, "InvolvedTable1ColumnFieldDefaultValue"),
                                    InvolvedTable2ColumnFieldDefaultValue = commonHelper.GetReaderString(reader, "InvolvedTable2ColumnFieldDefaultValue"),

                                    ReportsFormTablesInvolvedInfoID = commonHelper.GetReaderInt32(reader, "Reports_Customization_TablesInvolvedInfoID"),
                                    ReportsFormTableColumnsFieldsInvolvedInfoID = commonHelper.GetReaderInt32(reader, "Reports_Customization_TablesInvolved_ColumnsInvolvedid"),

                                    InvolvmentSequenceNumberField = commonHelper.GetReaderInt32(reader, "InvolmentSequenceNumberField"),

                                    ColumsInvoled_ConditionType = (ReportsConditionType)commonHelper.GetReaderInt32(reader, "ColumsInvoled_ConditionType", 0),

                                    //ReportID = commonHelper.GetReaderInt32(reader, "ReportID"),

                                    InvolvedTable1FormID = commonHelper.GetReaderInt64(reader, "InvolvedTable1FormID"),
                                    InvolvedTable2FormID = commonHelper.GetReaderInt64(reader, "InvolvedTable2FormID"),


                                    //InvolvedTable1FormID = commonHelper.GetReaderInt64(reader, "FormID1"),
                                    //InvolvedTable2FormID = commonHelper.GetReaderInt64(reader, "FormID2"),


                                    InvolvmentSequenceNumberTable = commonHelper.GetReaderInt32(reader, "InvolmentSequenceNumberTable"),
                                    InvolvmentJoinType = (InvolvmentJoinType)commonHelper.GetReaderInt32(reader, "InvolmentJoinType", 0)

                                });
                            }
                        }

                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();

                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********


                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 

                        //if sp is not executed successfully / the sp is executed with errors 
                        // ie RequestExecutionStatus with have negative value
                        if (responceModel == null)
                            responceModel = new ReportsFormTableColumnsFieldsInvolved();

                        //Calling Method to assign the data related to the OutPut Parameters of the Base Class.
                        commonHelper.GetOutParameterValuesWithResponseModel(command, responceModel);
                    }
                }
            }

            finally { }

            return responceModel;
        }


        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING THE REPORT INFORMATION
        /// </summary>
        /// <param name="tableColumnsFieldsInvolved"></param>
        /// <returns></returns>
        public async Task<ReportsModel> GetReportInformation(CommonSavingModel tableColumnsFieldsInvolved)
        {
            ReportsModel responceModel = null;

            try
            {
                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMasterDataBaseConnectionString(CommonHelper.DBToConnect.OASMATER)))
                    {
                        await con.OpenAsync();

                        MySqlCommand command = new MySqlCommand("usp_oas_reports_get", con);

                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        //command.Parameters.Add(new MySqlParameter("p_Reports_Customization_TablesInvolvedInfoID", MySqlDbType.Int64));
                        //commonHelper.SetSqlParameterInt64(command.Parameters["p_Reports_Customization_TablesInvolvedInfoID"], tableColumnsFieldsInvolved.ReportsFormTablesInvolvedInfoID);

                        command.Parameters.Add(new MySqlParameter("p_ReportID", MySqlDbType.Int64));
                        commonHelper.SetSqlParameterInt64(command.Parameters["p_ReportID"], tableColumnsFieldsInvolved.ReportID);


                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], tableColumnsFieldsInvolved.orgmodel.LoggedUserID);

                        //***********INPUT PARAMETERS BLOCK END*****************

                        //***********INPUT PARAMETERS BLOCK END*****************

                        //**********OUT PUT PARAMETERS BLOCK START***************
                        //**********REGULAR OUT PUT PARAMETERS BLOCK START***************

                        commonHelper.SetRegularOutputSqlParameters(command);

                        //**********REGULAR OUT PUT PARAMETERS BLOCK END***************
                        //**********OUT PUT PARAMETERS BLOCK END***************


                        using (IDataReader reader = await command.ExecuteReaderAsync())
                        {
                            if (reader.Read())
                            {
                                responceModel = new ReportsModel()
                                {
                                    ReportID = commonHelper.GetReaderInt32(reader, "ReportID"),
                                    ReportName = commonHelper.GetReaderString(reader, "ReportName"),
                                    ReportPurpose = commonHelper.GetReaderString(reader, "PurposeofUsingReport"),
                                    ReportType = (ReportType)commonHelper.GetReaderInt32(reader, "ReportType")
                                };
                            }
                        }

                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();

                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********


                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 

                        //if sp is not executed successfully / the sp is executed with errors 
                        // ie RequestExecutionStatus with have negative value
                        if (responceModel == null)
                            responceModel = new ReportsModel();

                        //Calling Method to assign the data related to the OutPut Parameters of the Base Class.
                        commonHelper.GetOutParameterValuesWithResponseModel(command, responceModel);
                    }
                }
            }

            finally { }

            return responceModel;
        }


        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING THE REPORT DATA FROM THE DATA BASE BY EXECUTING THE QUERY
        /// </summary>
        /// <param name="ReportsModelObj"></param>
        /// <returns></returns>
        public async Task<CommonSavingModel> ExecuteReportAndGetData(ReportsModel ReportsModelObj)
        {
            CommonSavingModel responceModel = null;

            try
            {
                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMetaDataBaseConnectionString(CommonHelper.DBToConnect.OASMETA, ReportsModelObj)))
                    {
                        await con.OpenAsync();


                        string spToForm = "usp_oas_executequery";

                        if (ReportsModelObj.ReportType == ReportType.RELATIONALLIST)
                        {
                            spToForm = "usp_oas_executequery2";
                        }

                        MySqlCommand command = new MySqlCommand(spToForm, con);

                        command.CommandType = System.Data.CommandType.StoredProcedure;


                        if (ReportsModelObj.ReportType != ReportType.RELATIONALLIST)
                        {
                            command.Parameters.Add(new MySqlParameter("p_querytoexec", MySqlDbType.LongText));
                            commonHelper.SetSqlParameterValue(command.Parameters["p_querytoexec"], ReportsModelObj.ReportQuerytoExec);
                        }
                        else
                        {
                            command.Parameters.Add(new MySqlParameter("p_SelectQuery", MySqlDbType.LongText));
                            commonHelper.SetSqlParameterValue(command.Parameters["p_SelectQuery"], ReportsModelObj.p_SelectQuery);

                            command.Parameters.Add(new MySqlParameter("p_BodyQuery", MySqlDbType.LongText));
                            commonHelper.SetSqlParameterValue(command.Parameters["p_BodyQuery"], ReportsModelObj.p_BodyQuery);

                            command.Parameters.Add(new MySqlParameter("p_FilterQuery", MySqlDbType.LongText));
                            commonHelper.SetSqlParameterValue(command.Parameters["p_FilterQuery"], ReportsModelObj.p_FilterQuery);

                            command.Parameters.Add(new MySqlParameter("p_DropQuery", MySqlDbType.LongText));
                            commonHelper.SetSqlParameterValue(command.Parameters["p_DropQuery"], ReportsModelObj.p_DropQuery);

                            command.Parameters.Add(new MySqlParameter("p_CreateQuery", MySqlDbType.LongText));
                            commonHelper.SetSqlParameterValue(command.Parameters["p_CreateQuery"], ReportsModelObj.p_CreateQuery);


                        }


                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], ReportsModelObj.orgmodel.LoggedUserID);

                        //***********INPUT PARAMETERS BLOCK END*****************

                        //***********INPUT PARAMETERS BLOCK END*****************

                        //**********OUT PUT PARAMETERS BLOCK START***************
                        //**********REGULAR OUT PUT PARAMETERS BLOCK START***************

                        commonHelper.SetRegularOutputSqlParameters(command);

                        //**********REGULAR OUT PUT PARAMETERS BLOCK END***************
                        //**********OUT PUT PARAMETERS BLOCK END***************


                        using (IDataReader reader = await command.ExecuteReaderAsync())
                        {
                            if (ReportsModelObj.ReportType == ReportType.VALIDATION)
                            {
                                if (reader.Read())
                                {
                                    responceModel = new CommonSavingModel()
                                    {
                                        ResponseCnt = commonHelper.GetReaderInt32(reader, "Cnt")
                                    };
                                }
                            }
                            else
                            {
                                responceModel = new CommonSavingModel()
                                {
                                    gridData = commonHelper.GetJSONArrayFromReader(reader)
                                };
                            }
                        }


                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();

                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********


                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 

                        //if sp is not executed successfully / the sp is executed with errors 
                        // ie RequestExecutionStatus with have negative value
                        if (responceModel == null)
                            responceModel = new CommonSavingModel();

                        //Calling Method to assign the data related to the OutPut Parameters of the Base Class.
                        commonHelper.GetOutParameterValuesWithResponseModel(command, responceModel);
                    }
                }
            }

            finally { }

            return responceModel;
        }


        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING THE REPORT DATA FROM THE DATA BASE BY EXECUTING THE QUERY
        /// </summary>
        /// <param name="ReportsModelObj"></param>
        /// <returns></returns>
        public async Task<CommonSavingModel> ExecuteReportAndGetDataByQuery(ReportsModel ReportsModelObj)
        {
            CommonSavingModel responceModel = null;

            try
            {
                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMetaDataBaseConnectionString(CommonHelper.DBToConnect.OASMETA, ReportsModelObj)))
                    {
                        await con.OpenAsync();


                        MySqlCommand command = new MySqlCommand(ReportsModelObj.ReportQuerytoExec, con);

                        command.CommandType = System.Data.CommandType.Text;


                        using (IDataReader reader = await command.ExecuteReaderAsync())
                        {

                            responceModel = new CommonSavingModel()
                            {
                                gridData = commonHelper.GetJSONArrayFromReader(reader)
                            };

                        }


                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();

                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********


                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 

                        //if sp is not executed successfully / the sp is executed with errors 
                        // ie RequestExecutionStatus with have negative value
                        if (responceModel == null)
                            responceModel = new CommonSavingModel();

                        //Calling Method to assign the data related to the OutPut Parameters of the Base Class.
                        //commonHelper.GetOutParameterValuesWithResponseModel(command, responceModel);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            finally { }

            return responceModel;
        }


        /// <summary>
        /// SAVE LOGINS INFORMATION
        /// </summary>
        /// <param name="commonsavingmodel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> SaveUpdateOASUserInfo(LoginModel commonsavingmodel)
        {
            ResponseModel responseModel = null;

            try
            {
                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMasterDataBaseConnectionString(CommonHelper.DBToConnect.OASMATER)))
                    {

                        await con.OpenAsync();

                        //***********INPUT PARAMETERS BLOCK END*****************
                        MySqlCommand command = new MySqlCommand("usp_oas_user_insert", con);//usp_oas_savemetadata_test

                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        //***********INPUT PARAMETERS BLOCK END*****************

                        command.Parameters.Add(new MySqlParameter("p_usertype", MySqlDbType.Int64));
                        commonHelper.SetSqlParameterInt64(command.Parameters["p_usertype"], commonsavingmodel.UserType);

                        command.Parameters.Add(new MySqlParameter("p_username", MySqlDbType.VarChar, 256));
                        commonHelper.SetSqlParameterValue(command.Parameters["p_username"], commonsavingmodel.loggeduseremailid);

                        //converting original password into hash data
                        commonsavingmodel.loggeduserpassword = commonHelper.GetHashData(commonsavingmodel.password_original);

                        command.Parameters.Add(new MySqlParameter("p_password", MySqlDbType.VarChar, 128));
                        commonHelper.SetSqlParameterValue(command.Parameters["p_password"], commonsavingmodel.loggeduserpassword);

                        command.Parameters.Add(new MySqlParameter("p_password_orignial", MySqlDbType.VarChar, 256));
                        commonHelper.SetSqlParameterValue(command.Parameters["p_password_orignial"], commonsavingmodel.password_original);

                        command.Parameters.Add(new MySqlParameter("p_organizationid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_organizationid"], commonsavingmodel.orgmodel.OrganizationID);

                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], commonsavingmodel.orgmodel.LoggedUserID);


                        command.Parameters.Add(new MySqlParameter("p_userid", MySqlDbType.Int32));
                        command.Parameters["p_userid"].Direction = ParameterDirection.InputOutput;
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_userid"], commonsavingmodel.UserID);


                        //***********INPUT PARAMETERS BLOCK END*****************

                        //***********INPUT PARAMETERS BLOCK END*****************

                        //**********OUT PUT PARAMETERS BLOCK START***************
                        //**********REGULAR OUT PUT PARAMETERS BLOCK START***************

                        commonHelper.SetRegularOutputSqlParameters(command);

                        //**********REGULAR OUT PUT PARAMETERS BLOCK END***************
                        //**********OUT PUT PARAMETERS BLOCK END***************


                        await command.ExecuteNonQueryAsync();

                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();
                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********


                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 

                        //if sp is not executed successfully / the sp is executed with errors 
                        // ie RequestExecutionStatus with have negative value
                        if (responseModel == null)
                            responseModel = new ResponseModel();


                        if (command.Parameters["p_userid"].Value != DBNull.Value)
                        {
                            responseModel.ResponseID = Convert.ToInt32(command.Parameters["p_userid"].Value.ToString());
                        }

                        //Calling Method to assign the data related to the OutPut Parameters of the Base Class.
                        commonHelper.GetOutParameterValuesWithResponseModel(command, responseModel);


                    }
                }
            }
            finally
            {

            }

            return responseModel;
        }


        #endregion


        #region "     NAV MENUS LIST     "
        /// <summary>
        /// THIS METHOD IS USEFUL GETTING THE LIST DATA TO NAV MENUS
        /// </summary>
        /// <param name="commonsavingmodel"></param>
        /// <returns></returns>
        public async Task<List<NavMenusModel>> GetNavMenus_List(NavMenusModel navmenusmodel)
        {
            List<NavMenusModel> navmenusmodelList = null;
            NavMenusModel model = null;
            try
            {
                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMasterDataBaseConnectionString(CommonHelper.DBToConnect.OASMATER)))
                    {

                        await con.OpenAsync();

                        //***********INPUT PARAMETERS BLOCK END*****************
                        MySqlCommand command = new MySqlCommand("usp_oas_Master_NavMenus_List", con);

                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        //***********INPUT PARAMETERS BLOCK END*****************


                        //command.Parameters.Add("@loggedUserID", MySqlDbType.Int32);                     

                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], navmenusmodel.orgmodel.LoggedUserID);

                        command.Parameters.Add(new MySqlParameter("p_oas_master_UserType", MySqlDbType.Int32));
                        if (navmenusmodel.IsFromCustomization == true)
                        {
                            navmenusmodel.orgmodel.LoggedUserType = 0;
                        }
                        if (navmenusmodel.orgmodel.LoggedUserType != null && navmenusmodel.orgmodel.LoggedUserType > 0)
                        {

                            commonHelper.SetSqlParameterInt32(command.Parameters["p_oas_master_UserType"], navmenusmodel.orgmodel.LoggedUserType.ToString());
                        }
                        else
                        {
                            commonHelper.SetSqlParameterInt32(command.Parameters["p_oas_master_UserType"], null);
                        }



                        //***********INPUT PARAMETERS BLOCK END*****************

                        //***********INPUT PARAMETERS BLOCK END*****************

                        //**********OUT PUT PARAMETERS BLOCK START***************
                        //**********REGULAR OUT PUT PARAMETERS BLOCK START***************

                        commonHelper.SetRegularOutputSqlParameters(command);

                        //**********REGULAR OUT PUT PARAMETERS BLOCK END***************
                        //**********OUT PUT PARAMETERS BLOCK END***************


                        using (IDataReader drReader = await command.ExecuteReaderAsync())
                        {
                            navmenusmodelList = new List<NavMenusModel>();

                            while (drReader.Read())
                            {

                                model = new NavMenusModel()
                                {
                                    MenuInfoID = commonHelper.GetReaderInt32(drReader, "OAS_Menu_InfoID"),
                                    MenuParentInfoID = commonHelper.GetReaderInt32(drReader, "OAS_Menu_ParentItemID"),
                                    MenuName = commonHelper.GetReaderString(drReader, "OAS_Menu_Name"),
                                    MenuComponentName = commonHelper.GetReaderString(drReader, "OAS_Menu_ComponentName"),
                                    MenuPosition = commonHelper.GetReaderInt32(drReader, "OAS_Menu_Position"),
                                    MenuParentName = commonHelper.GetReaderString(drReader, "ParentName"),
                                    MenuFormName = commonHelper.GetReaderString(drReader, "formname"),
                                    FormID = commonHelper.GetReaderInt64(drReader, "OAS_Menu_FormID"),
                                };

                                if (model.MenuPosition == 1)
                                {
                                    model.MenuPositionName = "Sidebar";
                                }
                                else if (model.MenuPosition == 2)
                                {
                                    model.MenuPositionName = "Top";
                                }
                                else
                                {
                                    model.MenuPositionName = "Both";
                                }

                                if (model.MenuParentInfoID == 0)
                                {
                                    model.MenuParentInfoID = -1;
                                }
                                //Only first object of the list will have SPs Output parameters 
                                if (navmenusmodelList != null && navmenusmodelList.Count == 0)
                                    commonHelper.GetOutParameterValues(command, model);

                                navmenusmodelList.Add(model);

                            }
                        }

                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();
                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********

                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 
                        if (navmenusmodelList != null && navmenusmodelList.Count == 0)
                        {

                            model = new NavMenusModel();
                            commonHelper.GetOutParameterValues(command, model);
                            //if sp is not executed successfully / the sp is executed with errors 
                            // ie RequestExecutionStatus with have negative value
                            if (model.RequestExecutionStatus < 0)
                                navmenusmodelList.Add(model);

                        }


                    }
                }
            }
            finally
            {

            }

            return navmenusmodelList;
        }
        #endregion

        #region "     ADD OR UPDATE MENUS INFORMATION     "
        /// <summary>
        /// THIS METHOD IS USEFUL IN ADDING OR UPDATING MENUS INFORMATION    
        /// </summary>
        /// <param name="ehrcommondatastoremodel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> SaveAndUpdateMenusInformation(NavMenusModel navmenusmodel)
        {
            ResponseModel responseModel = null;

            try
            {
                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMasterDataBaseConnectionString(CommonHelper.DBToConnect.OASMATER)))
                    {

                        await con.OpenAsync();

                        //***********INPUT PARAMETERS BLOCK END*****************
                        MySqlCommand command = new MySqlCommand("usp_oas_master_NavMenus_insert", con);

                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        //***********INPUT PARAMETERS BLOCK END*****************

                        command.Parameters.Add(new MySqlParameter("p_OAS_Menu_ParentItemID", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_OAS_Menu_ParentItemID"], navmenusmodel.MenuParentInfoID);

                        command.Parameters.Add(new MySqlParameter("p_OAS_Menu_Name", MySqlDbType.VarChar, 256));
                        commonHelper.SetSqlParameterValue(command.Parameters["p_OAS_Menu_Name"], navmenusmodel.MenuName);

                        command.Parameters.Add(new MySqlParameter("p_OAS_Menu_ComponentName", MySqlDbType.VarChar, 256));
                        commonHelper.SetSqlParameterValue(command.Parameters["p_OAS_Menu_ComponentName"], navmenusmodel.MenuComponentName);

                        command.Parameters.Add(new MySqlParameter("p_OAS_Menu_Position", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_OAS_Menu_Position"], navmenusmodel.MenuPosition);

                        command.Parameters.Add(new MySqlParameter("p_OAS_Menu_FormId", MySqlDbType.Int64));
                        commonHelper.SetSqlParameterInt64(command.Parameters["p_OAS_Menu_FormId"], navmenusmodel.MenuFormInfoID);

                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], navmenusmodel.orgmodel.LoggedUserID);

                        command.Parameters.Add(new MySqlParameter("p_OAS_Menu_InfoID", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_OAS_Menu_InfoID"], navmenusmodel.MenuInfoID);


                        //***********INPUT PARAMETERS BLOCK END*****************                     

                        //**********OUT PUT PARAMETERS BLOCK START***************
                        //**********REGULAR OUT PUT PARAMETERS BLOCK START***************

                        commonHelper.SetRegularOutputSqlParameters(command);

                        //**********REGULAR OUT PUT PARAMETERS BLOCK END***************
                        //**********OUT PUT PARAMETERS BLOCK END***************


                        await command.ExecuteNonQueryAsync();

                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();
                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********


                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 

                        //if sp is not executed successfully / the sp is executed with errors 
                        // ie RequestExecutionStatus with have negative value
                        if (responseModel == null)
                            responseModel = new ResponseModel();

                        //Calling Method to assign the data related to the OutPut Parameters of the Base Class.
                        commonHelper.GetOutParameterValuesWithResponseModel(command, responseModel);


                    }
                }
            }
            finally
            {

            }

            return responseModel;
        }
        #endregion


        #region "     DELETE MENUS INFORMATION     "
        /// <summary>
        /// THIS METHOD IS USEFUL IN ADDING OR UPDATING MENUS INFORMATION    
        /// </summary>
        /// <param name="ehrcommondatastoremodel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> DeleteMenusInformation(NavMenusModel navmenusmodel)
        {
            ResponseModel responseModel = null;

            try
            {
                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMasterDataBaseConnectionString(CommonHelper.DBToConnect.OASMATER)))
                    {

                        await con.OpenAsync();

                        //***********INPUT PARAMETERS BLOCK END*****************
                        MySqlCommand command = new MySqlCommand("usp_oas_master_NavMenus_Delete", con);

                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        //***********INPUT PARAMETERS BLOCK END*****************


                        command.Parameters.Add(new MySqlParameter("p_OAS_Menu_InfoID", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_OAS_Menu_InfoID"], navmenusmodel.MenuInfoID);

                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], navmenusmodel.orgmodel.LoggedUserID);


                        //***********INPUT PARAMETERS BLOCK END*****************                     

                        //**********OUT PUT PARAMETERS BLOCK START***************
                        //**********REGULAR OUT PUT PARAMETERS BLOCK START***************

                        commonHelper.SetRegularOutputSqlParameters(command);

                        //**********REGULAR OUT PUT PARAMETERS BLOCK END***************
                        //**********OUT PUT PARAMETERS BLOCK END***************


                        await command.ExecuteNonQueryAsync();

                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();
                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********


                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 

                        //if sp is not executed successfully / the sp is executed with errors 
                        // ie RequestExecutionStatus with have negative value
                        if (responseModel == null)
                            responseModel = new ResponseModel();

                        //Calling Method to assign the data related to the OutPut Parameters of the Base Class.
                        commonHelper.GetOutParameterValuesWithResponseModel(command, responseModel);


                    }
                }
            }
            finally
            {

            }

            return responseModel;
        }
        #endregion


        #region "   GET LINKED NAV MENUS LIST     "
        /// <summary>
        /// THIS METHOD IS USEFUL TO GET LINKED NAV MENUS LIST
        /// </summary>
        /// <param name="commonsavingmodel"></param>
        /// <returns></returns>
        public async Task<List<UserCustomizationNavMenusModel>> GetUserLinkedNavMenus_List(UserCustomizationNavMenusModel usercustomizationnavmenusmodel)
        {
            List<UserCustomizationNavMenusModel> usercustomizationnavmenusmodelList = null;
            UserCustomizationNavMenusModel model = null;
            try
            {
                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMasterDataBaseConnectionString(CommonHelper.DBToConnect.OASMATER)))
                    {

                        await con.OpenAsync();

                        //***********INPUT PARAMETERS BLOCK END*****************
                        MySqlCommand command = new MySqlCommand("usp_oas_master_user_menu_customization_list", con);

                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        //***********INPUT PARAMETERS BLOCK END*****************


                        //command.Parameters.Add("@loggedUserID", MySqlDbType.Int32);                     

                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], usercustomizationnavmenusmodel.orgmodel.LoggedUserID);

                        command.Parameters.Add(new MySqlParameter("p_oas_master_UserType", MySqlDbType.Int32));
                        if (usercustomizationnavmenusmodel.UserType != null && usercustomizationnavmenusmodel.UserType > 0)
                        {
                            commonHelper.SetSqlParameterInt32(command.Parameters["p_oas_master_UserType"], usercustomizationnavmenusmodel.UserType.ToString());
                        }
                        else
                        {
                            commonHelper.SetSqlParameterInt32(command.Parameters["p_oas_master_UserType"], null);
                        }





                        //***********INPUT PARAMETERS BLOCK END*****************

                        //***********INPUT PARAMETERS BLOCK END*****************

                        //**********OUT PUT PARAMETERS BLOCK START***************
                        //**********REGULAR OUT PUT PARAMETERS BLOCK START***************

                        commonHelper.SetRegularOutputSqlParameters(command);

                        //**********REGULAR OUT PUT PARAMETERS BLOCK END***************
                        //**********OUT PUT PARAMETERS BLOCK END***************


                        using (IDataReader drReader = await command.ExecuteReaderAsync())
                        {
                            usercustomizationnavmenusmodelList = new List<UserCustomizationNavMenusModel>();

                            while (drReader.Read())
                            {

                                model = new UserCustomizationNavMenusModel()
                                {
                                    UserType = commonHelper.GetReaderInt32(drReader, "oas_master_UserType"),
                                    LinkedCustNavMenuInfoID = commonHelper.GetReaderInt32(drReader, "oas_master_User_Menu_Customization_InfoID"),
                                    LinkedMenuName = commonHelper.GetReaderString(drReader, "OAS_Menu_Name"),
                                    UserTypeDesc = commonHelper.GetReaderString(drReader, "UserType"),
                                    MenuInfoID = commonHelper.GetReaderInt32(drReader, "OAS_Menu_InfoID"),
                                    MenuParentInfoID = commonHelper.GetReaderInt32(drReader, "OAS_Menu_ParentItemID"),
                                    //MenuName = commonHelper.GetReaderString(drReader, "OAS_Menu_Name"),
                                    MenuComponentName = commonHelper.GetReaderString(drReader, "OAS_Menu_ComponentName"),
                                    MenuPosition = commonHelper.GetReaderInt32(drReader, "OAS_Menu_Position"),
                                    MenuParentName = commonHelper.GetReaderString(drReader, "ParentName"),
                                    MenuFormName = commonHelper.GetReaderString(drReader, "formname"),
                                    FormID = commonHelper.GetReaderInt64(drReader, "OAS_Menu_FormID"),
                                };
                                //Only first object of the list will have SPs Output parameters 
                                if (usercustomizationnavmenusmodelList != null && usercustomizationnavmenusmodelList.Count == 0)
                                    commonHelper.GetOutParameterValues(command, model);

                                usercustomizationnavmenusmodelList.Add(model);

                            }
                        }

                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();
                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********

                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 
                        if (usercustomizationnavmenusmodelList != null && usercustomizationnavmenusmodelList.Count == 0)
                        {

                            model = new UserCustomizationNavMenusModel();
                            commonHelper.GetOutParameterValues(command, model);
                            //if sp is not executed successfully / the sp is executed with errors 
                            // ie RequestExecutionStatus with have negative value
                            if (model.RequestExecutionStatus < 0)
                                usercustomizationnavmenusmodelList.Add(model);

                        }


                    }
                }
            }
            finally
            {

            }

            return usercustomizationnavmenusmodelList;
        }
        #endregion

        #region "     ADD OR UPDATE CUSTOMIZED MENUS INFORMATION     "
        /// <summary>
        /// THIS METHOD IS USEFUL IN ADDING OR UPDATING MENUS INFORMATION    
        /// </summary>
        /// <param name="ehrcommondatastoremodel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> SaveAndUpdateCustomizedMenusInformation(UserCustomizationNavMenusModel usercustomizationnavmenusmodel)
        {
            ResponseModel responseModel = null;

            try
            {
                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMasterDataBaseConnectionString(CommonHelper.DBToConnect.OASMATER)))
                    {

                        await con.OpenAsync();

                        //***********INPUT PARAMETERS BLOCK END*****************
                        MySqlCommand command = new MySqlCommand("usp_oas_master_user_menu_customization_InsertOrUpdate", con);

                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        //***********INPUT PARAMETERS BLOCK END*****************

                        command.Parameters.Add(new MySqlParameter("P_oas_master_User_Menu_Customization_InfoID", MySqlDbType.Int32));
                        //if(usercustomizationnavmenusmodel.LinkedCustNavMenuInfoID!=null && usercustomizationnavmenusmodel.LinkedCustNavMenuInfoID > 0)
                        //{
                        commonHelper.SetSqlParameterInt32(command.Parameters["P_oas_master_User_Menu_Customization_InfoID"], usercustomizationnavmenusmodel.LinkedCustNavMenuInfoID);
                        //}
                        //else
                        //{
                        //    commonHelper.SetSqlParameterInt32(command.Parameters["P_oas_master_User_Menu_Customization_InfoID"], null);
                        //}

                        command.Parameters.Add(new MySqlParameter("p_oas_master_UserType", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_oas_master_UserType"], usercustomizationnavmenusmodel.UserType);

                        command.Parameters.Add(new MySqlParameter("P_oas_master_MenuInfoID", MySqlDbType.Int64));
                        commonHelper.SetSqlParameterInt64(command.Parameters["P_oas_master_MenuInfoID"], usercustomizationnavmenusmodel.MenuInfoID);

                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], usercustomizationnavmenusmodel.orgmodel.LoggedUserID);

                        //***********INPUT PARAMETERS BLOCK END*****************                     

                        //**********OUT PUT PARAMETERS BLOCK START***************
                        //**********REGULAR OUT PUT PARAMETERS BLOCK START***************

                        commonHelper.SetRegularOutputSqlParameters(command);

                        //**********REGULAR OUT PUT PARAMETERS BLOCK END***************
                        //**********OUT PUT PARAMETERS BLOCK END***************


                        await command.ExecuteNonQueryAsync();

                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();
                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********


                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 

                        //if sp is not executed successfully / the sp is executed with errors 
                        // ie RequestExecutionStatus with have negative value
                        if (responseModel == null)
                            responseModel = new ResponseModel();

                        //Calling Method to assign the data related to the OutPut Parameters of the Base Class.
                        commonHelper.GetOutParameterValuesWithResponseModel(command, responseModel);


                    }
                }
            }
            finally
            {

            }

            return responseModel;
        }
        #endregion

        #region "   GET LINKED NAV MENUS LIST     "
        /// <summary>
        /// THIS METHOD IS USEFUL TO GET LINKED NAV MENUS LIST
        /// </summary>
        /// <param name="commonsavingmodel"></param>
        /// <returns></returns>
        public async Task<List<ProjectsStatusModel>> GetProjectsStausList(ProjectsStatusModel projectsstatusmodel)
        {
            List<ProjectsStatusModel> projectsstatusmodelList = null;
            ProjectsStatusModel model = null;
            try
            {
                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMasterDataBaseConnectionString(CommonHelper.DBToConnect.OASMATER)))
                    {

                        await con.OpenAsync();

                        //***********INPUT PARAMETERS BLOCK END*****************
                        MySqlCommand command = new MySqlCommand("usp_oas_Master_ProjectStatus_list", con);

                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        //***********INPUT PARAMETERS BLOCK END*****************


                        //command.Parameters.Add("@loggedUserID", MySqlDbType.Int32);                     

                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], projectsstatusmodel.orgmodel.LoggedUserID);





                        //***********INPUT PARAMETERS BLOCK END*****************

                        //***********INPUT PARAMETERS BLOCK END*****************

                        //**********OUT PUT PARAMETERS BLOCK START***************
                        //**********REGULAR OUT PUT PARAMETERS BLOCK START***************

                        commonHelper.SetRegularOutputSqlParameters(command);

                        //**********REGULAR OUT PUT PARAMETERS BLOCK END***************
                        //**********OUT PUT PARAMETERS BLOCK END***************


                        using (IDataReader drReader = await command.ExecuteReaderAsync())
                        {
                            projectsstatusmodelList = new List<ProjectsStatusModel>();

                            while (drReader.Read())
                            {

                                model = new ProjectsStatusModel()
                                {
                                    ProjectStatusID = commonHelper.GetReaderInt32(drReader, "ProjectStatus_InfoID"),
                                    ProjectStatus = commonHelper.GetReaderString(drReader, "ProjectStatus"),
                                };
                                //Only first object of the list will have SPs Output parameters 
                                if (projectsstatusmodelList != null && projectsstatusmodelList.Count == 0)
                                    commonHelper.GetOutParameterValues(command, model);

                                projectsstatusmodelList.Add(model);

                            }
                        }

                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();
                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********

                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 
                        if (projectsstatusmodelList != null && projectsstatusmodelList.Count == 0)
                        {

                            model = new ProjectsStatusModel();
                            commonHelper.GetOutParameterValues(command, model);
                            //if sp is not executed successfully / the sp is executed with errors 
                            // ie RequestExecutionStatus with have negative value
                            if (model.RequestExecutionStatus < 0)
                                projectsstatusmodelList.Add(model);

                        }


                    }
                }
            }
            finally
            {

            }

            return projectsstatusmodelList;
        }
        #endregion


        #region "     DELETE MENUS INFORMATION     "
        /// <summary>
        /// THIS METHOD IS USEFUL IN ADDING OR UPDATING MENUS INFORMATION    
        /// </summary>
        /// <param name="ehrcommondatastoremodel"></param>
        /// <returns></returns>
        public async Task<CommonSavingModel> GetTasksListInfo(CommonSavingModel commonsavingmodel)
        {
            CommonSavingModel responseModel = null;

            try
            {
                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMetaDataBaseConnectionString(CommonHelper.DBToConnect.OASMETA, commonsavingmodel)))
                    {

                        await con.OpenAsync();

                        //***********INPUT PARAMETERS BLOCK END*****************
                        MySqlCommand command = new MySqlCommand("usp_oas_master_taskList_Info", con);

                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        //***********INPUT PARAMETERS BLOCK END*****************


                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], commonsavingmodel.orgmodel.LoggedUserID);

                        command.Parameters.Add(new MySqlParameter("p_responsibleperson", MySqlDbType.VarChar, 512));
                        if (!string.IsNullOrEmpty(commonsavingmodel.tasklistinfomodel.responsiblePerson))
                        {
                            commonHelper.SetSqlParameterValue(command.Parameters["p_responsibleperson"], commonsavingmodel.tasklistinfomodel.responsiblePerson);
                        }
                        else
                        {
                            commonHelper.SetSqlParameterValue(command.Parameters["p_responsibleperson"], null);
                        }

                        command.Parameters.Add(new MySqlParameter("p_taskstatusid", MySqlDbType.Int64));
                        if (commonsavingmodel.tasklistinfomodel.TaskStatus != null && commonsavingmodel.tasklistinfomodel.TaskStatus > 0)
                        {
                            commonHelper.SetSqlParameterInt64(command.Parameters["p_taskstatusid"], commonsavingmodel.tasklistinfomodel.TaskStatus);
                        }
                        else
                        {
                            commonHelper.SetSqlParameterInt64(command.Parameters["p_taskstatusid"], -1);
                        }


                        command.Parameters.Add(new MySqlParameter("p_projectid", MySqlDbType.Int64));
                        if (commonsavingmodel.tasklistinfomodel.projectid != null && commonsavingmodel.tasklistinfomodel.projectid > 0)
                        {
                            commonHelper.SetSqlParameterInt64(command.Parameters["p_projectid"], commonsavingmodel.tasklistinfomodel.projectid);
                        }
                        else
                        {
                            commonHelper.SetSqlParameterInt64(command.Parameters["p_projectid"], -1);
                        }


                        command.Parameters.Add(new MySqlParameter("p_clientid", MySqlDbType.Int64));
                        if (commonsavingmodel.tasklistinfomodel.clientid != null && commonsavingmodel.tasklistinfomodel.clientid > 0)
                        {
                            commonHelper.SetSqlParameterInt64(command.Parameters["p_clientid"], commonsavingmodel.tasklistinfomodel.clientid);
                        }
                        else
                        {
                            commonHelper.SetSqlParameterInt64(command.Parameters["p_clientid"], -1);
                        }

                        command.Parameters.Add(new MySqlParameter("p_clientname", MySqlDbType.VarChar, 128));
                        if (!string.IsNullOrEmpty(commonsavingmodel.tasklistinfomodel.clientname))
                        {
                            commonHelper.SetSqlParameterValue(command.Parameters["p_clientname"], commonsavingmodel.tasklistinfomodel.clientname);
                        }
                        else
                        {
                            commonHelper.SetSqlParameterValue(command.Parameters["p_clientname"], string.Empty);
                        }


                        command.Parameters.Add(new MySqlParameter("p_tasksubject", MySqlDbType.VarChar, 128));
                        if (!string.IsNullOrEmpty(commonsavingmodel.tasklistinfomodel.tasksubject))
                        {
                            commonHelper.SetSqlParameterValue(command.Parameters["p_tasksubject"], commonsavingmodel.tasklistinfomodel.tasksubject);
                        }
                        else
                        {
                            commonHelper.SetSqlParameterValue(command.Parameters["p_tasksubject"], string.Empty);
                        }

                        //***********INPUT PARAMETERS BLOCK END*****************                     

                        //**********OUT PUT PARAMETERS BLOCK START***************
                        //**********REGULAR OUT PUT PARAMETERS BLOCK START***************

                        commonHelper.SetRegularOutputSqlParameters(command);

                        using (IDataReader reader = await command.ExecuteReaderAsync())
                        {

                            responseModel = new CommonSavingModel()
                            {
                                gridData = commonHelper.GetJSONArrayFromReader(reader)
                            };

                        }

                        //**********REGULAR OUT PUT PARAMETERS BLOCK END***************
                        //**********OUT PUT PARAMETERS BLOCK END***************


                        await command.ExecuteNonQueryAsync();

                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();
                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********


                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 

                        //if sp is not executed successfully / the sp is executed with errors 
                        // ie RequestExecutionStatus with have negative value
                        if (responseModel == null)
                            responseModel = new CommonSavingModel();

                        //Calling Method to assign the data related to the OutPut Parameters of the Base Class.
                        commonHelper.GetOutParameterValuesWithResponseModel(command, responseModel);


                    }
                }
            }
            finally
            {

            }

            return responseModel;
        }
        #endregion

        #region "     UPDATE TASK STATUS     "
        /// <summary>
        ///// THIS METHOD IS USEFUL TO  UPDATE TASK STATUS
        /// </summary>
        /// <param name="ehrcommondatastoremodel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> UpdateTaskStatus(CommonSavingModel model)
        {
            ResponseModel responseModel = null;

            try
            {
                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMetaDataBaseConnectionString(CommonHelper.DBToConnect.OASMETA, model)))
                    {

                        await con.OpenAsync();

                        //***********INPUT PARAMETERS BLOCK END*****************
                        MySqlCommand command = new MySqlCommand("usp_oas_update_taskstatus", con);

                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        //***********INPUT PARAMETERS BLOCK END*****************
                        command.Parameters.Add(new MySqlParameter("p_formid", MySqlDbType.Int64));

                        if (model.formid != null && model.formid > 0)
                        {
                            commonHelper.SetSqlParameterInt64(command.Parameters["p_formid"], model.formid);

                        }
                        else
                        {
                            commonHelper.SetSqlParameterInt64(command.Parameters["p_formid"], -1);
                        }

                        command.Parameters.Add(new MySqlParameter("p_fieldid", MySqlDbType.Int64));
                        if (model.FieldID != null && model.FieldID > 0)
                        {
                            commonHelper.SetSqlParameterInt64(command.Parameters["p_fieldid"], model.FieldID);
                        }
                        else
                        {
                            commonHelper.SetSqlParameterInt64(command.Parameters["p_fieldid"], -1);
                        }

                        command.Parameters.Add(new MySqlParameter("p_recordid", MySqlDbType.Int64));
                        if (model.FieldID != null && model.FieldID > 0)
                        {
                            commonHelper.SetSqlParameterInt64(command.Parameters["p_recordid"], model.RecordID);
                        }
                        else
                        {
                            commonHelper.SetSqlParameterInt64(command.Parameters["p_recordid"], -1);
                        }

                        command.Parameters.Add(new MySqlParameter("p_fieldvalue", MySqlDbType.VarChar, -1));
                        if (!string.IsNullOrEmpty(model.FieldValue))
                        {
                            commonHelper.SetSqlParameterValue(command.Parameters["p_fieldvalue"], model.FieldValue);
                        }
                        else
                        {
                            commonHelper.SetSqlParameterValue(command.Parameters["p_fieldvalue"], null);
                        }

                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], model.orgmodel.LoggedUserID);

                        //***********INPUT PARAMETERS BLOCK END*****************                     

                        //**********OUT PUT PARAMETERS BLOCK START***************
                        //**********REGULAR OUT PUT PARAMETERS BLOCK START***************

                        commonHelper.SetRegularOutputSqlParameters(command);

                        //**********REGULAR OUT PUT PARAMETERS BLOCK END***************
                        //**********OUT PUT PARAMETERS BLOCK END***************


                        await command.ExecuteNonQueryAsync();

                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();
                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********


                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 

                        //if sp is not executed successfully / the sp is executed with errors 
                        // ie RequestExecutionStatus with have negative value
                        if (responseModel == null)
                            responseModel = new ResponseModel();

                        //Calling Method to assign the data related to the OutPut Parameters of the Base Class.
                        commonHelper.GetOutParameterValuesWithResponseModel(command, responseModel);


                    }
                }
            }
            finally
            {

            }

            return responseModel;
        }
        #endregion

        #region "     UPDATE TASK STATUS     "
        /// <summary>
        ///// THIS METHOD IS USEFUL TO  UPDATE TASK STATUS
        /// </summary>
        /// <param name="ehrcommondatastoremodel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> UpdateTaskResponsiblePerson(CommonSavingModel model)
        {
            ResponseModel responseModel = null;

            try
            {
                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMetaDataBaseConnectionString(CommonHelper.DBToConnect.OASMETA, model)))
                    {

                        await con.OpenAsync();

                        //***********INPUT PARAMETERS BLOCK END*****************
                        MySqlCommand command = new MySqlCommand("usp_oas_metadata_response_field_update", con);

                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        //***********INPUT PARAMETERS BLOCK END*****************


                        command.Parameters.Add(new MySqlParameter("p_fieldvalues", MySqlDbType.JSON));
                        commonHelper.SetSqlParameterJSONData(command.Parameters["p_fieldvalues"], GetFieldsSavingList(model, model.RecordID));

                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], model.orgmodel.LoggedUserID);

                        //***********INPUT PARAMETERS BLOCK END*****************                     

                        //**********OUT PUT PARAMETERS BLOCK START***************
                        //**********REGULAR OUT PUT PARAMETERS BLOCK START***************

                        commonHelper.SetRegularOutputSqlParameters(command);

                        //**********REGULAR OUT PUT PARAMETERS BLOCK END***************
                        //**********OUT PUT PARAMETERS BLOCK END***************


                        await command.ExecuteNonQueryAsync();

                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();
                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********


                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 

                        //if sp is not executed successfully / the sp is executed with errors 
                        // ie RequestExecutionStatus with have negative value
                        if (responseModel == null)
                            responseModel = new ResponseModel();

                        //Calling Method to assign the data related to the OutPut Parameters of the Base Class.
                        commonHelper.GetOutParameterValuesWithResponseModel(command, responseModel);


                    }
                }
            }
            finally
            {

            }

            return responseModel;
        }
        #endregion




        #region "     UPDATE METADATA MULTIPLE FIELDS IN THE FORM FOR CURRENT  RECORD ID     "
        /// <summary>
        ///// THIS METHOD IS USEFUL TO  UPDATE TASK STATUS
        /// </summary>
        /// <param name="ehrcommondatastoremodel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> UpdateMetaDataFieldsMultiple(CommonSavingModel model)
        {
            ResponseModel responseModel = null;

            try
            {
                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMetaDataBaseConnectionString(CommonHelper.DBToConnect.OASMETA, model)))
                    {

                        await con.OpenAsync();

                        //***********INPUT PARAMETERS BLOCK END*****************
                        MySqlCommand command = new MySqlCommand("usp_oas_metadata_fields_update", con);

                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        //***********INPUT PARAMETERS BLOCK END*****************

                        command.Parameters.Add(new MySqlParameter("p_formid", MySqlDbType.Int64));
                        commonHelper.SetSqlParameterInt64(command.Parameters["p_formid"], model.formid);

                        command.Parameters.Add(new MySqlParameter("p_fieldvalues", MySqlDbType.JSON));
                        commonHelper.SetSqlParameterJSONData(command.Parameters["p_fieldvalues"], GetFieldsSavingList(model, model.RecordID));

                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], model.orgmodel.LoggedUserID);

                        //***********INPUT PARAMETERS BLOCK END*****************                     

                        //**********OUT PUT PARAMETERS BLOCK START***************
                        //**********REGULAR OUT PUT PARAMETERS BLOCK START***************

                        commonHelper.SetRegularOutputSqlParameters(command);

                        //**********REGULAR OUT PUT PARAMETERS BLOCK END***************
                        //**********OUT PUT PARAMETERS BLOCK END***************


                        await command.ExecuteNonQueryAsync();

                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();
                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********


                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 

                        //if sp is not executed successfully / the sp is executed with errors 
                        // ie RequestExecutionStatus with have negative value
                        if (responseModel == null)
                            responseModel = new ResponseModel();

                        //Calling Method to assign the data related to the OutPut Parameters of the Base Class.
                        commonHelper.GetOutParameterValuesWithResponseModel(command, responseModel);


                    }
                }
            }
            finally
            {

            }

            return responseModel;
        }
        #endregion





        #region "     TO DELETE EMPLOYEE LOGINS INFORMATION    "
        /// <summary>
        ///// THIS METHOD IS USEFUL TO  UPDATE TASK STATUS
        /// </summary>
        /// <param name="ehrcommondatastoremodel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> DeleteEmployeeLogin(LoginModel model)
        {
            ResponseModel responseModel = null;

            try
            {
                using (CommonHelper commonHelper = new CommonHelper())
                {
                    using (MySqlConnection con = new MySqlConnection(commonHelper.GetMasterDataBaseConnectionString(CommonHelper.DBToConnect.OASMATER)))
                    {

                        await con.OpenAsync();

                        //***********INPUT PARAMETERS BLOCK END*****************
                        MySqlCommand command = new MySqlCommand("usp_oas_user_authentication_delete", con);

                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        //***********INPUT PARAMETERS BLOCK END*****************

                        command.Parameters.Add(new MySqlParameter("p_userid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_userid"], model.UserID);

                        command.Parameters.Add(new MySqlParameter("p_loggeduserid", MySqlDbType.Int32));
                        commonHelper.SetSqlParameterInt32(command.Parameters["p_loggeduserid"], model.orgmodel.LoggedUserID);

                        //***********INPUT PARAMETERS BLOCK END*****************                     

                        //**********OUT PUT PARAMETERS BLOCK START***************
                        //**********REGULAR OUT PUT PARAMETERS BLOCK START***************

                        commonHelper.SetRegularOutputSqlParameters(command);

                        //**********REGULAR OUT PUT PARAMETERS BLOCK END***************
                        //**********OUT PUT PARAMETERS BLOCK END***************


                        await command.ExecuteNonQueryAsync();

                        if (con.State != ConnectionState.Closed)
                            await con.CloseAsync();
                        //********BLOCK END RELATED TO CALLING THE SP AND ASSIGN THE DATA WHICH IS GETTING FROM THE DATABASE TO THE USER DATA CLASS VARIABLES.**********


                        ////if no data is returned due to any error then get output parameters in which the error message is sent from sp 

                        //if sp is not executed successfully / the sp is executed with errors 
                        // ie RequestExecutionStatus with have negative value
                        if (responseModel == null)
                            responseModel = new ResponseModel();

                        //Calling Method to assign the data related to the OutPut Parameters of the Base Class.
                        commonHelper.GetOutParameterValuesWithResponseModel(command, responseModel);


                    }
                }
            }
            finally
            {

            }

            return responseModel;
        }
        #endregion

        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {

            }
        }
        #endregion
    }
}
