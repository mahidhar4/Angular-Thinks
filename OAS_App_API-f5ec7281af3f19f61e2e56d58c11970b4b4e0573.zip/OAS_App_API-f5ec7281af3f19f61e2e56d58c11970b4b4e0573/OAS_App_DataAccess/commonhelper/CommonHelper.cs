﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
//using Microsoft.AspNetCore.Hosting;


//Add MySql Library
using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using OAS_App_Common;
using OAS_App_Common.Common;

namespace OAS_App_DataAccess.commonhelper
{
    public class CommonHelper : IDisposable
    {
        //###VARIABLE TO LOG SPS CALLING BLOCK START################
        static StringBuilder strAccessLog;
        Stopwatch stopwatch = null;
        string spName;
        public int CommandTimeOut = 1000; //Used to store command time out information

        // int intApplicationEnvironment = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["Environment"]); // 1- DEVELOPMENT ; 2 - QA ; 3- PRODUCTION ENVIRONMENT

        private int ApplicationEnvironment = 0; // 1- DEVELOPMENT ; 2 - QA ; 3- PRODUCTION ENVIRONMENT

        //public int ApplicationEnvironment
        //{
        //    get
        //    {
        //        setAppEnvironmentIfNotExists();

        //        return ApplicationEnvironment;

        //    }
        //    set
        //    {
        //        ApplicationEnvironment = value;
        //    }
        //}

        public int intApplicationEnvironment
        {
            get
            {
                setAppEnvironmentIfNotExists();

                return ApplicationEnvironment;

            }
            set
            {
                ApplicationEnvironment = value;
            }
        }



        private void setAppEnvironmentIfNotExists()
        {

            if (ApplicationEnvironment <= 0)
            {
                string drirectory = AppContext.BaseDirectory + "\\appsettings.json";

                //if debug mode
                if (drirectory.Contains("bin"))
                    drirectory = drirectory.Substring(0, drirectory.IndexOf("bin"));


                drirectory = drirectory + "appsettings.json";

                if (System.IO.File.Exists(drirectory))
                {
                    string readData = System.IO.File.ReadAllText(drirectory);

                    JObject jObject = JsonConvert.DeserializeObject<JObject>(readData);

                    ApplicationEnvironment = Convert.ToInt32(jObject["Environment"].ToString());
                }

            }
        }




        #region "        DATA BASE TO CONNECT ENUM        "

        /// <summary>
        /// This enumurator is for Database connection strings
        /// </summary>
        /// <remarks></remarks>
        public enum DBToConnect
        {
            OASMATER = 1,
            OASMETA = 2
        }

        public enum EMRConnectionAttempt
        {
            FIRST = 1,
            SECOND = 2,
            THIRD = 3,
        }

        #endregion

        #region "          CLASS LEVEL VARIABLES          "


        #endregion




        #region "          GET EMRAPPLICATION CONNECTION STRING          "

        /// <summary>
        /// This function is for getting the connection string
        /// </summary>
        /// <param name="dbconn"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        public string GetEMRApplicationDBConnectionString(DBToConnect dbType, EMRConnectionAttempt connectionAttempt)
        {
            string strConn = "";
            string EMRDBServerName = "";
            string SQLDBUSERNAMEANDPWD = "";
            string EMREmergencyDBServerName = string.Empty;
            try
            {
                //Starting stopwatch to measure performance of the stored procedure
                stopwatch = Stopwatch.StartNew();

                switch (connectionAttempt)
                {
                    case EMRConnectionAttempt.FIRST:
                        EMRDBServerName = System.Configuration.ConfigurationManager.AppSettings["DBServersName"];
                        break;
                    case EMRConnectionAttempt.SECOND:
                        EMRDBServerName = System.Configuration.ConfigurationManager.AppSettings["DBServersName2"];
                        break;
                    case EMRConnectionAttempt.THIRD:
                        EMRDBServerName = System.Configuration.ConfigurationManager.AppSettings["DBServersName3"];
                        break;
                    default:
                        EMRDBServerName = System.Configuration.ConfigurationManager.AppSettings["DBServersName"];
                        break;
                }

                SQLDBUSERNAMEANDPWD = ";User Id=xpert;pwd=xpert; ";

                //switch (dbType)
                //{
                //    case DBToConnect.EMRAPPLICATION:
                //        strConn = "Server=" + EMRDBServerName + SQLDBUSERNAMEANDPWD + "database=EMRApplication;Connect Timeout= 2";//+ MaxPoolSize;                        
                //        break;
                //}


                return strConn;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion


        #region                   "     GET CONNECTION STRING      "

        public string GetMasterDataBaseConnectionString(DBToConnect dbType)
        {

            string strConn = "";
            string server = "";
            string database = "";
            string userid = "";
            string password = "";
            try
            {

                //int intApplicationEnvironmentMe = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["Environment"]);


                //object intApplicationEnvironmentMeObj = AppContext.GetData("Environment");

                //var test = new Microsoft.AspNetCore.Hosting.Internal.HostingEnvironment();

                //if (test.EnvironmentName == "Development")
                //{

                //}

                switch (dbType)
                {
                    case DBToConnect.OASMATER:
                        server = "192.168.0.205";
                        database = "oas_master";
                        userid = "oasmainuser";
                        password = "oasmainuser";



                        if (intApplicationEnvironment == 3)
                            database = database + "_production";

                        strConn = "SERVER=" + server + ";" + "Port=3306;" + "DATABASE=" + database + ";" + "UID=" + userid + ";" + "PASSWORD=" + password + ";";
                        break;
                    default:
                        break;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return strConn;

        }


        public string GetMetaDataBaseConnectionString(DBToConnect dbType, BaseModel baseModel)
        {

            string strConn = "";
            string server = "";
            string database = "";
            string userid = "";
            string password = "";
            try
            {
                switch (dbType)
                {
                    case DBToConnect.OASMETA:
                        server = "192.168.0.205";
                        database = baseModel.orgmodel.OrganizationID + "_oas_metadata";
                        userid = "oasuser" + baseModel.orgmodel.OrganizationID;
                        password = "oasuser" + baseModel.orgmodel.OrganizationID;



                        //if (intApplicationEnvironment == 3)
                        //    database = database + "_production";

                        strConn = "SERVER=" + server + ";" + "Port=3306;" + "DATABASE=" + database + ";" + "UID=" + userid + ";" + "PASSWORD=" + password + ";";
                        break;
                    default:
                        break;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return strConn;

        }

        #endregion




        #region "         SQL PARAMETERS GET/SET FUNCTIONS         "

        #region "       SET SP PARAMETER VALUES        "
        /// <summary>
        /// This method is used to set Regular SPs out put parameter to grab sp execution status 
        /// </summary>
        /// <param name="command"></param>
        public void SetRegularOutputSqlParameters(MySqlCommand command)
        {

            //GET SP NAME TO LOG 
            spName = command.CommandText;

            // List<string> strlisttest = strlist;

            command.Parameters.Add(new MySqlParameter("p_return", MySqlDbType.Int32));
            command.Parameters["p_return"].Direction = ParameterDirection.Output;

            command.Parameters.Add(new MySqlParameter("p_errorid", MySqlDbType.Int32));
            command.Parameters["p_errorid"].Direction = ParameterDirection.Output;

            command.Parameters.Add(new MySqlParameter("p_errormessage", MySqlDbType.VarChar, 2048));
            command.Parameters["p_errormessage"].Direction = ParameterDirection.Output;

        }


        #region"                METHOD TO CONVERT STRING PWD TO HASH DATA        "


        /// <summary>
        /// CONVERTING STRING TO HASH DATA
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        internal string GetHashData(string data)
        {
            StringBuilder hashRet = null;
            byte[] msgBytes = null;
            byte b = 0;
            byte[] hashBytes = null;
            try
            {
                // Convert the string to a unicode array of bytes.
                msgBytes = Encoding.Unicode.GetBytes(data);

                // Calculate a hash on the data.
                using (SHA1Managed sha1 = new SHA1Managed())
                {
                    hashBytes = sha1.ComputeHash(msgBytes);

                    // Use the string builder for increased speed.
                    hashRet = new StringBuilder("");

                    // Loop and convert each digit in the hash.

                    foreach (byte b_loopVariable in hashBytes)
                    {
                        b = b_loopVariable;
                        hashRet.AppendFormat("{0:X}", b);
                    }

                }

            }
            finally
            {
                msgBytes = null;
                b = 0;
                hashBytes = null;

            }
            // Return the hash.
            return hashRet.ToString();
        }

        #endregion


        public void SetSqlParameterInt32(MySqlParameter param, string input)
        {
            int value;
            if (int.TryParse(input, out value))
            {
                param.Value = value;
            }
            else
            {
                param.Value = DBNull.Value;
            }
        }

        public void SetSqlParameterInt32(MySqlParameter param, int input)
        {
            if (input != null)
            {
                param.Value = input;
            }
            else
            {
                param.Value = DBNull.Value;
            }
        }

        public void SetSqlParameterInt64(MySqlParameter param, Int64 input)
        {
            if (input != null)
            {
                param.Value = input;
            }
            else
            {
                param.Value = -1;
            }
        }


        public void SetSqlParameterInt64(MySqlParameter param, string input)
        {
            Int64 value;

            if (Int64.TryParse(input, out value))
            {
                param.Value = value;
            }
            else
            {
                param.Value = DBNull.Value;
            }
        }

        public void SetSqlParameterJSONData(MySqlParameter param, object input)
        {
            if (input != null)
            {
                param.Value = JsonConvert.SerializeObject(input);
            }
            else
            {
                param.Value = DBNull.Value;
            }
        }

        //public void SetSqlParameterLong(MySqlParameter param, string input)
        //{
        //    long value;
        //    if (long.TryParse(input, out value))
        //    {
        //        param.Value = value;
        //    }
        //    else
        //    {
        //        param.Value = DBNull.Value;
        //    }
        //}


        public void SetSqlParameterInt32Nullable(MySqlParameter param, int? input)
        {
            if (input.HasValue)
            {
                param.Value = input.Value;
            }
            else
            {
                param.Value = DBNull.Value;
            }
        }

        public void SetSqlParameterInt64Nullable(MySqlParameter param, string input)
        {
            Int64 value;

            if (Int64.TryParse(input, out value))
            {
                param.Value = value;
            }
            else
            {
                param.Value = DBNull.Value;
            }
        }

        public void SetSqlParameterDecimal(MySqlParameter param, string input)
        {
            Decimal value;
            if (Decimal.TryParse(input, out value))
            {
                param.Value = value;
            }
            else
            {
                param.Value = DBNull.Value;
            }
        }

        public void SetSqlParameterDeciamlNullable(MySqlParameter param, decimal? input)
        {
            if (input.HasValue)
            {
                param.Value = input.Value;
            }
            else
            {
                param.Value = DBNull.Value;
            }
        }

        //public void SetSqlParameterDateTimeNullable(MySqlParameter param, DateTime? input)
        //{
        //    if (input.HasValue)
        //    {
        //        param.Value = input.Value;
        //    }
        //    else
        //    {
        //        param.Value = DBNull.Value;
        //    }
        //}


        public void SetSqlParameterDateTime(MySqlParameter param, string input)
        {

            // --------------- OLD CODE BFORE API CONVERSION BLOCK START ----------
            DateTime value;
            if (DateTime.TryParse(input, out value))
            {
                param.Value = value;
            }
            else
            {
                param.Value = DBNull.Value;
            }
            // --------------- OLD CODE BFORE API CONVERSION BLOCK END   ----------


            //string formattext = string.Empty;

            //// value =  DateTime.ParseExact(input.ToString(), "MM/DD/yyyy HH:mm tt", CultureInfo.CurrentCulture);
            //if (input.ToString().Trim().Length == 16)
            //{
            //    formattext = "MM/dd/yyyy HH:mm";
            //}
            //else if (input.ToString().Trim().Length > 16)
            //{
            //    formattext = "MM/dd/yyyy hh:mm tt";
            //}
            //else
            //{
            //    formattext = "MM/dd/yyyy";
            //}

            //try
            //{
            //    param.Value = DateTime.ParseExact(input, formattext, System.Globalization.CultureInfo.InvariantCulture);
            //}
            //catch (Exception)
            //{

            //    param.Value =DBNull.Value;

            //}

        }

        public void SetSqlParameterValue(MySqlParameter param, string input)
        {
            string strHtmlformation = string.Empty;

            if (String.IsNullOrEmpty(input))
            {
                param.Value = DBNull.Value;
            }
            else
            {
                param.Value = input;
            }
        }

        public void SetSqlParameterValueWithSingleQuotes(MySqlParameter param, string input)
        {
            if (String.IsNullOrEmpty(input))
            {
                param.Value = DBNull.Value;
            }
            else
            {
                param.Value = input.Replace("'", "''");
            }
        }

        public void SetSqlParameterValueAllowEmpty(MySqlParameter param, string input)
        {
            if (input == null)
            {
                param.Value = DBNull.Value;
            }
            else
            {
                param.Value = input;
            }
        }

        public void SetSqlParameterBit(MySqlParameter param, bool input)
        {
            if (input)
            {
                param.Value = 1;
            }
            else
            {
                param.Value = 0;
            }
        }

        public void SetSqlParameterBitNullable(MySqlParameter param, bool? input)
        {
            if (input == null)
            {
                param.Value = DBNull.Value;
            }
            else if (input == true)
            {
                param.Value = 1;
            }
            else
            {
                param.Value = 0;
            }
        }

        public void SetSQLParameterByteArray(MySqlParameter param, Byte[] input)
        {
            param.Value = input;

        }

        public void SetSQLParameterByteArrayNullable(MySqlParameter param, byte?[] input)
        {
            param.Value = input;

        }

        public void SetSQLParameterStructureType(MySqlParameter param, object input)
        {
            param.Value = input;
        }

        #endregion

        #region "       GET SP PARAMETER VALUES        "

        public int GetReaderInt32(IDataReader reader, string columnName)
        {
            return GetReaderInt32(reader, columnName, -1);
        }

        public int GetReaderInt32(IDataReader reader, string columnName, int defaultIfDBNull)
        {
            int ordinal = reader.GetOrdinal(columnName);
            return reader.IsDBNull(ordinal) ? defaultIfDBNull : (int)reader.GetInt32(ordinal);
        }

        public int GetReaderTinyInt(IDataReader reader, string columnName)
        {
            return GetReaderTinyInt(reader, columnName, -1);
        }

        public int GetReaderTinyInt(IDataReader reader, string columnName, int defaultIfDBNull)
        {
            Byte ordinal = (Byte)reader.GetOrdinal(columnName);
            return reader.IsDBNull(ordinal) ? defaultIfDBNull : reader.GetByte(ordinal);
        }

        public int? GetReaderInt32Nullable(IDataReader reader, string columnName)
        {
            int ordinal = reader.GetOrdinal(columnName);
            return reader.IsDBNull(ordinal) ? null : (int?)reader.GetInt32(ordinal);
        }

        public Int64 GetReaderInt64(IDataReader reader, string columnName)
        {
            return GetReaderInt64(reader, columnName, -1);
        }

        public Int64 GetReaderInt64(IDataReader reader, string columnName, int defaultIfDBNull)
        {
            int ordinal = reader.GetOrdinal(columnName);
            return reader.IsDBNull(ordinal) ? defaultIfDBNull : (Int64)reader.GetInt64(ordinal);
        }

        //public long GetReaderLong(IDataReader reader, string columnName)
        //{
        //    return GetReaderLong(reader, columnName, -1);
        //}
        //public long GetReaderLong(IDataReader reader, string columnName, int defaultIfDBNull)
        //{
        //    int ordinal = reader.GetOrdinal(columnName);
        //    return reader.IsDBNull(ordinal) ? defaultIfDBNull : (long)reader.GetInt64(ordinal);
        //}

        public Int64? GetReaderInt64Nullable(IDataReader reader, string columnName)
        {
            int ordinal = reader.GetOrdinal(columnName);
            return reader.IsDBNull(ordinal) ? null : (Int64?)reader.GetInt64(ordinal);
        }

        public byte GetReaderByte(IDataReader reader, string columnName)
        {
            return GetReaderByte(reader, columnName, 0);
        }

        public byte GetReaderByte(IDataReader reader, string columnName, byte defaultIfDBNull)
        {
            int ordinal = reader.GetOrdinal(columnName);
            return reader.IsDBNull(ordinal) ? defaultIfDBNull : (byte)reader.GetByte(ordinal);
        }

        public byte? GetReaderByteNullable(IDataReader reader, string columnName)
        {
            int ordinal = reader.GetOrdinal(columnName);
            return reader.IsDBNull(ordinal) ? null : (byte?)reader.GetByte(ordinal);
        }

        public decimal? GetReaderDecimal(IDataReader reader, string columnName)
        {
            int ordinal = reader.GetOrdinal(columnName);
            return reader.IsDBNull(ordinal) ? null : (decimal?)reader.GetDecimal(ordinal);
        }


        //public float? GetReaderFloatNullable(IDataReader reader, string columnName)
        //{
        //    int ordinal = reader.GetOrdinal(columnName);
        //    return reader.IsDBNull(ordinal) ? null : (float?)reader.GetFloat(ordinal);
        //}

        //public float GetReaderFloat(IDataReader reader, string columnName)
        //{
        //    int ordinal = reader.GetOrdinal(columnName);
        //    return reader.IsDBNull(ordinal) ? 0 : (float)reader.GetFloat(ordinal);
        //}

        public float? GetReaderFloatNullable(IDataReader reader, string columnName)
        {
            int ordinal = reader.GetOrdinal(columnName);
            return reader.IsDBNull(ordinal) ? null : (float?)reader.GetDouble(ordinal);
        }

        public float GetReaderFloat(IDataReader reader, string columnName)
        {
            int ordinal = reader.GetOrdinal(columnName);
            return reader.IsDBNull(ordinal) ? 0 : (float)reader.GetDouble(ordinal);
        }


        //public DateTime? GetReaderDateTimeNullable(IDataReader reader, string columnName)
        //{
        //    int ordinal = reader.GetOrdinal(columnName);
        //    return reader.IsDBNull(ordinal) ? null : (DateTime?)reader.GetDateTime(ordinal);
        //}
        //public DateTime GetReaderDateTime(IDataReader reader, string columnName)
        //{
        //    int ordinal = reader.GetOrdinal(columnName);
        //    return reader.IsDBNull(ordinal) ? DateTime.MinValue : (DateTime)reader.GetDateTime(ordinal);
        //}

        public string GetReaderString(IDataReader reader, string columnName)
        {
            int ordinal = reader.GetOrdinal(columnName);
            return reader.IsDBNull(ordinal) ? string.Empty : reader[ordinal].ToString();
        }

        public string GetReaderDateString(IDataReader reader, string columnName)
        {
            int ordinal = reader.GetOrdinal(columnName);
            return reader.IsDBNull(ordinal) ? string.Empty : (Convert.ToDateTime(reader[ordinal])).ToString("MM/dd/yyyy");
            //return reader.IsDBNull(ordinal) ? string.Empty : ((DateTime)reader.GetDateTime(ordinal)).ToString("MM/dd/yyyy");
        }

        public string GetReaderDateTime12HrString(IDataReader reader, string columnName)
        {
            int ordinal = reader.GetOrdinal(columnName);
            return reader.IsDBNull(ordinal) ? string.Empty : (Convert.ToDateTime(reader[ordinal])).ToString("MM/dd/yyyy hh:mm tt");
        }


        public string GetReaderDateTime24HrString(IDataReader reader, string columnName)
        {
            int ordinal = reader.GetOrdinal(columnName);
            return reader.IsDBNull(ordinal) ? string.Empty : (Convert.ToDateTime(reader[ordinal])).ToString("MM/dd/yyyy HH:mm");
        }


        public string GetReaderDateTimeISOString(IDataReader reader, string columnName)
        {
            int ordinal = reader.GetOrdinal(columnName);
            return reader.IsDBNull(ordinal) ? string.Empty : (Convert.ToDateTime(reader[ordinal])).ToString("yyyy-MM-ddTHH:mm:ss zzz");
        }

        public string GetReaderOnlyTimeString(IDataReader reader, string columnName)
        {
            int ordinal = reader.GetOrdinal(columnName);
            return reader.IsDBNull(ordinal) ? string.Empty : (Convert.ToDateTime(reader[ordinal])).ToString("HH:mm tt");
        }


        public bool GetReaderBoolean(IDataReader reader, string columnName)
        {
            int ordinal = reader.GetOrdinal(columnName);
            return reader.IsDBNull(ordinal) ? false : (bool)reader.GetBoolean(ordinal);
        }

        public bool GetReaderBooleanFromInt(IDataReader reader, string columnName)
        {
            int ordinal = reader.GetOrdinal(columnName);
            return reader.IsDBNull(ordinal) ? false : Convert.ToBoolean(reader.GetInt32(ordinal));
        }

        public int GetReaderIntFromBoolean(IDataReader reader, string columnName)
        {
            int ordinal = reader.GetOrdinal(columnName);
            return reader.IsDBNull(ordinal) ? 0 : Convert.ToInt32(reader.GetBoolean(ordinal));
        }

        public byte[] GetReaderBytes(IDataReader reader, string columnName)
        {
            byte[] buffer = null;
            int ordinal = reader.GetOrdinal(columnName);
            long length = 0;
            if (!reader.IsDBNull(ordinal))
            {
                length = reader.GetBytes(ordinal, 0L, null, 0, 0);
                buffer = new byte[length];
                reader.GetBytes(ordinal, 0L, buffer, 0, buffer.Length);
            }
            //else
            //{
            //    buffer = new byte[length];
            //}            
            return buffer;
        }
        /// <summary>
        /// Get int[] by splitting reader value
        /// </summary>
        /// <param name="reader">IDataReader</param>
        /// <param name="columnName">Name of the column in reader</param>
        /// <param name="_splitBy">character to split; Default comma</param>
        /// <returns>type of int[]</returns>
        public int[] GetReaderIntArrayBySplittingString(IDataReader reader, string columnName, char _splitBy = ',')
        {
            int ordinal = reader.GetOrdinal(columnName);
            string readerValue = "";
            int[] returnValue = null;

            if (!reader.IsDBNull(ordinal))
            {
                readerValue = reader[ordinal].ToString();

                if (!string.IsNullOrEmpty(readerValue))
                    returnValue = readerValue.Split(_splitBy).Select(x => Convert.ToInt32(x)).ToArray();
                readerValue = string.Empty;
            }
            return returnValue;
        }

        #endregion

        #endregion

        #region "                GET OUT PARAMETER VALUES                "
        /// <summary>
        /// To get output parameters which are returned from stored procedure
        /// </summary>
        /// <param name="dbCmd"></param>
        /// <param name="data"></param>
        public void GetOutParameterValues(MySqlCommand dbCmd, BaseModel data)
        {
            //Checking Database Command and Data objects is having data or not.
            if (dbCmd != null && data != null)
            {
                //Checking the database command Return Value is dbnull or not.
                //If it is not dbnull then assign the return value to the base data object.
                if (dbCmd.Parameters["p_Return"].Value != null && dbCmd.Parameters["p_Return"].Value != DBNull.Value)
                {
                    data.RequestExecutionStatus = (int)dbCmd.Parameters["p_Return"].Value;
                }
                //Checking the database command ErrorID Value is dbnull or not.
                //If it is not dbnull then assign the ErrorID value to the base data object.
                if (dbCmd.Parameters["p_ErrorID"].Value != null && dbCmd.Parameters["p_ErrorID"].Value != DBNull.Value)
                {
                    data.ErrorID = (int)dbCmd.Parameters["p_ErrorID"].Value;
                }
                //Checking the database command ErrorMessage Value is dbnull or not.
                //If it is not dbnull then assign the ErrorMessage value to the base data object.
                if (dbCmd.Parameters["p_ErrorMessage"].Value != null && dbCmd.Parameters["p_ErrorMessage"].Value != DBNull.Value)
                {
                    data.ErrorMessage = dbCmd.Parameters["p_ErrorMessage"].Value.ToString();
                }
            }
        }

        #endregion

        #region "                GET OUT PARAMETER VALUES FOR RESPONSE MODEL                "
        /// <summary>
        /// To get output parameters which are returned from stored procedure
        /// </summary>
        /// <param name="dbCmd"></param>
        /// <param name="data"></param>
        public void GetOutParameterValuesWithResponseModel(MySqlCommand dbCmd, ResponseModel data)
        {
            //Checking Database Command and Data objects is having data or not.
            if (dbCmd != null && data != null)
            {
                //Checking the database command Return Value is dbnull or not.
                //If it is not dbnull then assign the return value to the base data object.
                if (dbCmd.Parameters["p_return"].Value != null && dbCmd.Parameters["p_return"].Value != DBNull.Value)
                {
                    data.RequestExecutionStatus = (int)dbCmd.Parameters["p_return"].Value;
                }
                //Checking the database command ErrorID Value is dbnull or not.
                //If it is not dbnull then assign the ErrorID value to the base data object.
                if (dbCmd.Parameters["p_errorid"].Value != null && dbCmd.Parameters["p_errorid"].Value != DBNull.Value)
                {
                    data.ErrorID = (int)dbCmd.Parameters["p_errorid"].Value;
                }
                //Checking the database command ErrorMessage Value is dbnull or not.
                //If it is not dbnull then assign the ErrorMessage value to the base data object.
                if (dbCmd.Parameters["p_errormessage"].Value != null && dbCmd.Parameters["p_errormessage"].Value != DBNull.Value)
                {
                    data.ErrorMessage = dbCmd.Parameters["p_errormessage"].Value.ToString();
                }
            }
        }


        public void GetOutParameterValuesWithResponseModel(MySqlCommand dbCmd, BaseModel data)
        {
            //Checking Database Command and Data objects is having data or not.
            if (dbCmd != null && data != null)
            {
                //Checking the database command Return Value is dbnull or not.
                //If it is not dbnull then assign the return value to the base data object.
                if (dbCmd.Parameters["p_return"].Value != null && dbCmd.Parameters["p_return"].Value != DBNull.Value)
                {
                    data.RequestExecutionStatus = (int)dbCmd.Parameters["p_return"].Value;
                }
                //Checking the database command ErrorID Value is dbnull or not.
                //If it is not dbnull then assign the ErrorID value to the base data object.
                if (dbCmd.Parameters["p_errorid"].Value != null && dbCmd.Parameters["p_errorid"].Value != DBNull.Value)
                {
                    data.ErrorID = (int)dbCmd.Parameters["p_errorid"].Value;
                }
                //Checking the database command ErrorMessage Value is dbnull or not.
                //If it is not dbnull then assign the ErrorMessage value to the base data object.
                if (dbCmd.Parameters["p_errormessage"].Value != null && dbCmd.Parameters["p_errormessage"].Value != DBNull.Value)
                {
                    data.ErrorMessage = dbCmd.Parameters["p_errormessage"].Value.ToString();
                }
            }
        }

        #endregion

        #region "       CONVERT ARGB TO RGBA       "

        /// <summary>
        /// *******PURPOSE: THIS METHOD IS USED TO CONVERT THE COLOR FORMAT OF THE ARGB TO RGBA WHICH SUPPORTS IN THE FRONT END WEB 
        /// *******CREATED BY: SIVA PRASAD
        /// *******CREATED DATE: 10/10/2014
        /// *******MODIFIED DEVELOPER: DATE - NAME - WHAT IS MODIFIED; *************************
        /// </summary>
        /// <param name="strinputstatusColor"></param>
        /// <param name="emrwebexceptiontracelogmodel"></param>
        /// <returns></returns>

        public string ConvertARGBToRGBA(string strinputstatusColor)
        {
            string strFormattedColor = string.Empty;
            string[] strstatuscolorarry = null;
            try
            {
                if (!string.IsNullOrEmpty(strinputstatusColor))
                {
                    // return "rgba(" + strinputstatusColor + ");";

                    strstatuscolorarry = strinputstatusColor.Split(',');


                    if (strstatuscolorarry != null)
                    {

                        if (strstatuscolorarry.Length > 1)
                        {
                            strFormattedColor = "rgba(" + strstatuscolorarry[1] + ",";//r
                        }
                        if (strstatuscolorarry.Length > 2)
                        {
                            strFormattedColor = strFormattedColor + strstatuscolorarry[2] + ",";//g
                        }
                        if (strstatuscolorarry.Length > 3)
                        {
                            strFormattedColor = strFormattedColor + strstatuscolorarry[3] + ","; // +")";b
                            strFormattedColor = strFormattedColor + strstatuscolorarry[0] + ")";//a
                        }
                    }




                }

            }
            finally
            {

            }
            return strFormattedColor;
        }

        #endregion

        #region "       CONVERTING DATA TABLE TO JSON STRING            "


        /// <summary>
        /// *******PURPOSE: THIS METHOD IS USED TO CONVERT THE DATA TABLE TO JSON STRING FORMAT, IN THE SCENARIO OF WHERE THE COLUMNS NAMES WILL COME DYNAMICAALY
        /// *******CREATED BY: SIVA PRASAD
        /// *******CREATED DATE: 10/27/2014
        /// *******MODIFIED DEVELOPER: DATE - NAME - WHAT IS MODIFIED; ************************* 
        /// </summary>
        /// <param name="dtResult"></param>
        /// <returns></returns>

        public string GetJsonStingWriteEnd(DataTable dtResult)
        {
            StringBuilder sb = null;
            StringWriter sw = null;
            string strByteData = "";
            try
            {
                sb = new StringBuilder();
                //sb.Append("{");
                sw = new StringWriter(sb);

                using (JsonWriter jsonWriter = new JsonTextWriter(sw))
                {
                    jsonWriter.WriteStartArray();
                    for (int intRowCount = 0; intRowCount < dtResult.Rows.Count; intRowCount++)
                    {
                        jsonWriter.WriteStartObject();
                        for (int intCoumnCount = 0; intCoumnCount < dtResult.Columns.Count; intCoumnCount++)
                        {
                            //jsonWriter.WritePropertyName(dtResult.Columns[intCoumnCount].ColumnName);
                            jsonWriter.WritePropertyName("_" + dtResult.Columns[intCoumnCount].ColumnName.Replace("-", "_").Replace("/", "_").Replace(" ", "_").Replace("@", "_").Replace("&", "_").Replace("$", "_"));

                            if (dtResult.Columns[intCoumnCount].DataType.FullName == "System.Byte[]")
                            {
                                strByteData = Convert.ToBase64String((byte[])dtResult.Rows[intRowCount][intCoumnCount]);

                                jsonWriter.WriteValue(strByteData);
                            }
                            else if (dtResult.Columns[intCoumnCount].DataType.FullName == "System.Int32")
                            {
                                jsonWriter.WriteValue("" + dtResult.Rows[intRowCount][intCoumnCount]);
                            }
                            else
                            {
                                jsonWriter.WriteValue(dtResult.Rows[intRowCount][intCoumnCount]);
                            }



                        }
                        jsonWriter.WriteEndObject();

                    }
                    jsonWriter.WriteEndArray();
                }

                //sb.Append("}");
                return sb.ToString();
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                if (dtResult != null)
                {
                    dtResult.Dispose();
                    dtResult = null;
                }
                sb = null;
                sw = null;
            }
        }


        public string GetDataTableColumnJsonStingWriteEnd(DataTable dtResult)
        {
            StringBuilder sb = null;
            StringWriter sw = null;

            try
            {
                sb = new StringBuilder();
                //sb.Append("{");
                sw = new StringWriter(sb);

                using (JsonWriter jsonWriter = new JsonTextWriter(sw))
                {
                    jsonWriter.WriteStartArray();
                    //for (int intRowCount = 0; intRowCount < dtResult.Rows.Count; intRowCount++)
                    //{

                    for (int intCoumnCount = 0; intCoumnCount < dtResult.Columns.Count; intCoumnCount++)
                    {
                        if (dtResult.Columns[intCoumnCount].ColumnName == "VitalPatient_DOS")
                        {
                            continue;
                        }
                        jsonWriter.WriteStartObject();
                        //jsonWriter.WritePropertyName(dtResult.Columns[intCoumnCount].ColumnName);
                        jsonWriter.WritePropertyName("field");
                        jsonWriter.WriteValue("_" + dtResult.Columns[intCoumnCount].ColumnName.Replace("-", "_").Replace("/", "_").Replace(" ", "_").Replace("@", "_").Replace("&", "_").Replace("$", "_").Replace("(", "_").Replace(")", "_"));

                        jsonWriter.WritePropertyName("title");
                        if (dtResult.Columns[intCoumnCount].ColumnName == "StartTime")
                        {
                            jsonWriter.WriteValue("Measured Time");
                        }
                        else if (dtResult.Columns[intCoumnCount].ColumnName == "DocumentedBy")
                        {
                            jsonWriter.WriteValue("Documented By");
                        }
                        else if (dtResult.Columns[intCoumnCount].ColumnName == "VitalPatient_ModifiedOn")
                        {
                            jsonWriter.WriteValue("Modified On (ISO Date)");
                        }
                        else
                        {
                            jsonWriter.WriteValue(dtResult.Columns[intCoumnCount].ColumnName);
                        }

                        jsonWriter.WriteEndObject();
                    }


                    // }
                    jsonWriter.WriteEndArray();
                }


                return sb.ToString();
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                if (dtResult != null)
                {
                    dtResult.Dispose();
                    dtResult = null;
                }
                sb = null;
                sw = null;
            }
        }


        public string GetJsonStingWriteEndForInActiveVitals(DataTable dtResult)
        {
            StringBuilder sb = null;
            StringWriter sw = null;
            string strByteData = "";
            try
            {
                sb = new StringBuilder();
                //sb.Append("{");
                sw = new StringWriter(sb);

                using (JsonWriter jsonWriter = new JsonTextWriter(sw))
                {
                    jsonWriter.WriteStartArray();
                    for (int intRowCount = 0; intRowCount < dtResult.Rows.Count; intRowCount++)
                    {
                        jsonWriter.WriteStartObject();
                        for (int intCoumnCount = 0; intCoumnCount < dtResult.Columns.Count; intCoumnCount++)
                        {
                            //jsonWriter.WritePropertyName(dtResult.Columns[intCoumnCount].ColumnName);
                            jsonWriter.WritePropertyName("_" + dtResult.Columns[intCoumnCount].ColumnName.Replace("-", "_").Replace("/", "_").Replace(" ", "_").Replace("@", "_").Replace("&", "_").Replace("$", "_"));

                            if (dtResult.Columns[intCoumnCount].DataType.FullName == "System.Byte[]")
                            {
                                strByteData = Convert.ToBase64String((byte[])dtResult.Rows[intRowCount][intCoumnCount]);

                                jsonWriter.WriteValue(strByteData);
                            }
                            else if (dtResult.Columns[intCoumnCount].DataType.FullName == "System.Int32")
                            {
                                jsonWriter.WriteValue("" + dtResult.Rows[intRowCount][intCoumnCount]);
                            }
                            else if (dtResult.Columns[intCoumnCount].ColumnName == "VitalPatient_ModifiedOn")
                            {
                                if (!object.ReferenceEquals(dtResult.Rows[intRowCount][intCoumnCount], DBNull.Value))
                                {
                                    jsonWriter.WriteValue(DateConvertion(Convert.ToDateTime(dtResult.Rows[intRowCount][intCoumnCount])));
                                }

                            }
                            else
                            {
                                jsonWriter.WriteValue(dtResult.Rows[intRowCount][intCoumnCount]);
                            }



                        }
                        jsonWriter.WriteEndObject();

                    }
                    jsonWriter.WriteEndArray();
                }

                //sb.Append("}");
                return sb.ToString();
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                if (dtResult != null)
                {
                    dtResult.Dispose();
                    dtResult = null;
                }
                sb = null;
                sw = null;
            }
        }


        public string GetDataTableColumnJsonStingWriteEndForVitalsForInActive(DataTable dtResult)
        {
            StringBuilder sb = null;
            StringWriter sw = null;

            try
            {
                sb = new StringBuilder();
                //sb.Append("{");
                sw = new StringWriter(sb);

                using (JsonWriter jsonWriter = new JsonTextWriter(sw))
                {
                    jsonWriter.WriteStartArray();
                    //for (int intRowCount = 0; intRowCount < dtResult.Rows.Count; intRowCount++)
                    //{

                    for (int intCoumnCount = 0; intCoumnCount < dtResult.Columns.Count; intCoumnCount++)
                    {

                        jsonWriter.WriteStartObject();
                        //jsonWriter.WritePropertyName(dtResult.Columns[intCoumnCount].ColumnName);
                        jsonWriter.WritePropertyName("field");
                        jsonWriter.WriteValue("_" + dtResult.Columns[intCoumnCount].ColumnName.Replace("-", "_").Replace("/", "_").Replace(" ", "_").Replace("@", "_").Replace("&", "_").Replace("$", "_").Replace("(", "_").Replace(")", "_"));

                        jsonWriter.WritePropertyName("title");
                        if (dtResult.Columns[intCoumnCount].ColumnName == "StartTime")
                        {
                            jsonWriter.WriteValue("Appt Date-Time");
                        }
                        else if (dtResult.Columns[intCoumnCount].ColumnName == "DocumentedBy")
                        {
                            jsonWriter.WriteValue("Documented By");
                        }
                        else if (dtResult.Columns[intCoumnCount].ColumnName == "VitalPatient_ModifiedOn")
                        {
                            jsonWriter.WriteValue("Modified On (ISO Date)");
                        }
                        else if (dtResult.Columns[intCoumnCount].ColumnName == "VitalPatient_DOS")
                        {
                            jsonWriter.WriteValue("Measured Time");
                        }
                        else
                        {
                            jsonWriter.WriteValue(dtResult.Columns[intCoumnCount].ColumnName);
                        }

                        jsonWriter.WriteEndObject();
                    }


                    // }
                    jsonWriter.WriteEndArray();
                }


                return sb.ToString();
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                if (dtResult != null)
                {
                    dtResult.Dispose();
                    dtResult = null;
                }
                sb = null;
                sw = null;
            }
        }


        /// <summary>
        /// CONVERTING THE MODIFIED ON TO ISO
        /// </summary>
        /// <param name="dtDate"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        private string DateConvertion(System.DateTime dtDate)
        {
            int Years = dtDate.Year;
            int Months = dtDate.Month;
            int Day = dtDate.Day;
            int Hours = dtDate.Hour;
            int Minutes = dtDate.Minute;
            int Seconds = dtDate.Second;
            int MilliSeconds = dtDate.Millisecond;
            string strConvertedDate = "";
            DateTime dtRequiredDate = new DateTime(Years, Months, Day, Hours, Minutes, Seconds, MilliSeconds);
            try
            {
                strConvertedDate = string.Format("{0:yyyy-MM-ddTHH:mm:ss zzz}", dtRequiredDate);
            }
            finally
            {

            }
            return strConvertedDate;
        }


        #endregion



        #region "       SERIALIZE THE IDATA READER DATA TO JSON LIST          "



        /// <summary>
        /// 
        /// </summary>
        /// <param name="rdr"></param>
        /// <returns></returns>

        public List<string> GetDataReaderColumnNames(IDataReader rdr)
        {
            var columnNames = new List<string>();
            for (int i = 0; i < rdr.FieldCount; i++)
                columnNames.Add(rdr.GetName(i));
            return columnNames;
        }


        public string GetJSONArrayFromReader(IDataReader reader)
        {


            StringBuilder sb = null;
            StringWriter sw = null;
            object jsonValTemp = string.Empty;
            string JSON = string.Empty;
            string columnDataType = string.Empty;
            int rowCount = 0;

            //creating the string builder for the json strig formation
            sb = new StringBuilder();
            //creating the string writer for the strig formation
            sw = new StringWriter(sb);

            //getting all the columns
            List<string> allColumns = GetDataReaderColumnNames(reader);

            using (JsonWriter jsonWriter = new JsonTextWriter(sw))
            {

                using (CommonHelper commonhelper = new CommonHelper())
                {

                    //reading the each row
                    while (reader.Read())
                    {

                        //checking for the start arrray 
                        if (rowCount == 0)
                        {
                            rowCount++;
                            jsonWriter.WriteStartArray();
                        }

                        //start one row object
                        jsonWriter.WriteStartObject();

                        foreach (string itemColumn in allColumns)
                        {

                            //getting the current column field data type
                            columnDataType = reader.GetFieldType(reader.GetOrdinal(itemColumn)).FullName;

                            //start the property
                            if (itemColumn == "recordid")
                                jsonWriter.WritePropertyName("RecordID");
                            else if (itemColumn == "formid")
                                jsonWriter.WritePropertyName("FormID");
                            else if (itemColumn == "fieldid")
                                jsonWriter.WritePropertyName("FieldID");
                            else if (itemColumn == "recorddataid")
                                jsonWriter.WritePropertyName("RecordDataID");
                            else
                                jsonWriter.WritePropertyName(itemColumn);

                            //case for reading the column based on the type of the column
                            switch (columnDataType.ToLower())
                            {

                                case "system.int32":
                                    jsonWriter.WriteValue(commonhelper.GetReaderInt32Nullable(reader, itemColumn));
                                    break;
                                case "system.string":
                                    jsonWriter.WriteValue(commonhelper.GetReaderString(reader, itemColumn));
                                    break;
                                case "system.datetime":
                                    jsonWriter.WriteValue(commonhelper.GetReaderString(reader, itemColumn));
                                    break;
                                case "system.decimal":
                                    jsonWriter.WriteValue(commonhelper.GetReaderDecimal(reader, itemColumn));
                                    break;

                                default:
                                    jsonWriter.WriteValue("" + reader.GetValue(reader.GetOrdinal(itemColumn)));
                                    break;
                            }
                        }

                        //end one row object
                        jsonWriter.WriteEndObject();
                    }

                }

                //when data exists then only 
                if (rowCount > 0)
                    jsonWriter.WriteEndArray();
            }

            //returning the json string
            return sw.ToString();
        }


        #endregion

        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {

            }
        }
        #endregion

    }
}
