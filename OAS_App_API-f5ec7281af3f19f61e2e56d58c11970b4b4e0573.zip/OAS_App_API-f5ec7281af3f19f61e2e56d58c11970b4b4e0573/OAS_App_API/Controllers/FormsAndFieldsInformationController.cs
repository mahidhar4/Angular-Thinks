﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OAS_App_API.ExceptionTracking;
using OAS_App_BusinessFaccade.Employee;
using OAS_App_BusinessFaccade.Organization;
using OAS_App_Common;
using OAS_App_Common.Organization;
using Microsoft.AspNetCore.Cors;
using System;
using System.Threading.Tasks;
using OAS_App_Common.OASFormsAndFieldsInfo;
using OAS_App_BusinessFaccade.FormsAndFieldsInformation;

namespace OAS_App_API.Controllers
{

    [Consumes("application/json")]
    [Produces("application/json")]
    [Route("api/FormsAndFieldsInfo")]
    [EnableCors("AllowSpecificOrigin")]
    public class FormsAndFieldsInformationController : Controller
    {
        #region "     ADD OR UPDATE FORMS INFORMATION     "
        /// <summary>
        /// THIS METHOD IS USEFUL IN ADDING OR UPDATING ORGANIZATION DETAILS LIST      
        /// </summary>
        /// <param name="ehrcommondatastoremodel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("SaveAndUpdateFormsInformation")]
        public async Task<IActionResult> SaveAndUpdateFormsInformation_Main([FromBody] OASFormsInfoModel oasformsinfomodel)
        {
            BaseModel baseModel = null;

            try
            {
                if (oasformsinfomodel == null)
                    return BadRequest("Provide Valid Data.");

                //using (FormsAndFieldsInfoBusinesAcess formsandfieldsinfobusinesacess = new FormsAndFieldsInfoBusinesAcess())
                //{
                //    baseModel = await formsandfieldsinfobusinesacess.SaveAndUpdateFormsInformation(oasformsinfomodel);
                //}

                using (FormsAndFieldsMySqlBusinessAccess formsandfieldsinfobusinesacess = new FormsAndFieldsMySqlBusinessAccess())
                {
                    baseModel = await formsandfieldsinfobusinesacess.SaveAndUpdateFormsInformation(oasformsinfomodel);
                }

                return Ok(baseModel);
            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }

        }


        #endregion


        #region "     DELETE ORGANIZATION DETAILS       "
        [HttpPost]
        [Route("DeleteFormsInfoDetails")]
        public async Task<IActionResult> DeleteFormsInfoDetails_Main([FromBody] OASFormsInfoModel oasformsinfomodel)
        {
            BaseModel baseModel = null;

            try
            {
                if (oasformsinfomodel == null)
                    return BadRequest("Provide Valid Data.");

                //using (FormsAndFieldsInfoBusinesAcess formsandfieldsinfobusinesacess = new FormsAndFieldsInfoBusinesAcess())
                //{
                //    baseModel = await formsandfieldsinfobusinesacess.DeleteFormsInfoDetails(oasformsinfomodel);
                //}

                using (FormsAndFieldsMySqlBusinessAccess formsandfieldsinfobusinesacess = new FormsAndFieldsMySqlBusinessAccess())
                {
                    baseModel = await formsandfieldsinfobusinesacess.DeleteFormInformation(oasformsinfomodel);
                }

                return Ok(baseModel);
            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }

        }
        #endregion


        #region "     ORGANZATION DETAILS LIST          "
        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING ORGANZATION DETAILS LIST      
        /// </summary>
        /// <param name="ehrcommondatastoremodel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("GetFormsInfoList")]
        public async Task<IActionResult> GetFormsInfoList_Main([FromBody]  OASFormsInfoModel oasformsinfomodel)
        {
            OASFormsInfoModel responsemodel = null;
            try
            {
                //responsemodel.emrwebexceptiontracelogmodel.AddToExecutionLog("EHRGoogleDataStore.Controllers", "DataStoreController", "AppServersList", "AppServersList Start", ExecutionLogType.Detail);


                if (oasformsinfomodel == null)
                {
                    return BadRequest("Invalid Request Data");
                }

                //using (FormsAndFieldsInfoBusinesAcess formsandfieldsinfobusinesacess = new FormsAndFieldsInfoBusinesAcess())
                //{
                //    responsemodel = await formsandfieldsinfobusinesacess.GetFormsInfoList(oasformsinfomodel);
                //}

                using (FormsAndFieldsMySqlBusinessAccess formsandfieldsinfobusinesacess = new FormsAndFieldsMySqlBusinessAccess())
                {
                    responsemodel = await formsandfieldsinfobusinesacess.GetFormsInfoList(oasformsinfomodel);
                }

                //ehrcommondatastoremodel.emrwebexceptiontracelogmodel.AddToExecutionLog("EHRGoogleDataStore.Controllers", "DataStoreController", "AppServersList", "AppServersList End", ExecutionLogType.Detail);

            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }
            finally
            {

            }

            return Ok(responsemodel);

        }

        #endregion



        #region "     ADD OR UPDATE FORMS INFORMATION     "
        /// <summary>
        /// THIS METHOD IS USEFUL IN ADDING OR UPDATING ORGANIZATION DETAILS LIST      
        /// </summary>
        /// <param name="ehrcommondatastoremodel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("SaveAndUpdateFieldsInformation")]
        public async Task<IActionResult> SaveAndUpdateFieldsInformation_Main([FromBody] OASFieldsInformationModel oasfieldsinformationmodel)
        {
            BaseModel baseModel = null;

            try
            {
                if (oasfieldsinformationmodel == null)
                    return BadRequest("Provide Valid Data.");

                //using (FormsAndFieldsInfoBusinesAcess formsandfieldsinfobusinesacess = new FormsAndFieldsInfoBusinesAcess())
                //{
                //    baseModel = await formsandfieldsinfobusinesacess.SaveAndUpdateFieldsInformation(oasfieldsinformationmodel);
                //}

                using (FormsAndFieldsMySqlBusinessAccess formsandfieldsinfobusinesacess = new FormsAndFieldsMySqlBusinessAccess())
                {
                    baseModel = await formsandfieldsinfobusinesacess.SaveAndUpdateFieldsInformation(oasfieldsinformationmodel);
                }

                return Ok(baseModel);
            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }

        }


        #endregion


        #region "     DELETE ORGANIZATION DETAILS       "
        [HttpPost]
        [Route("DeleteFieldsInfoDetails")]
        public async Task<IActionResult> DeleteFieldsInfoDetails_Main([FromBody] OASFieldsInformationModel oasfieldsinformationmodel)
        {
            BaseModel baseModel = null;

            try
            {
                if (oasfieldsinformationmodel == null)
                    return BadRequest("Provide Valid Data.");

                //using (FormsAndFieldsInfoBusinesAcess formsandfieldsinfobusinesacess = new FormsAndFieldsInfoBusinesAcess())
                //{
                //    baseModel = await formsandfieldsinfobusinesacess.DeleteFieldsInfoDetails(oasfieldsinformationmodel);
                //}
                using (FormsAndFieldsMySqlBusinessAccess formsandfieldsinfobusinesacess = new FormsAndFieldsMySqlBusinessAccess())
                {
                    baseModel = await formsandfieldsinfobusinesacess.DeleteFieldInformation(oasfieldsinformationmodel);
                }

                return Ok(baseModel);
            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }

        }
        #endregion


        #region "     ORGANZATION DETAILS LIST          "
        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING ORGANZATION DETAILS LIST      
        /// </summary>
        /// <param name="ehrcommondatastoremodel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("GetFieldsInfoList")]
        public async Task<IActionResult> GetFieldsInfoList_Main([FromBody]  OASFieldsInformationModel oasfieldsinformationmodel)
        {
            OASFieldsInformationModel responsemodel = null;
            try
            {
                //responsemodel.emrwebexceptiontracelogmodel.AddToExecutionLog("EHRGoogleDataStore.Controllers", "DataStoreController", "AppServersList", "AppServersList Start", ExecutionLogType.Detail);


                if (oasfieldsinformationmodel == null)
                {
                    return BadRequest("Invalid Request Data");
                }

                //using (FormsAndFieldsInfoBusinesAcess formsandfieldsinfobusinesacess = new FormsAndFieldsInfoBusinesAcess())
                //{
                //    responsemodel = await formsandfieldsinfobusinesacess.GetFieldsInfoList(oasfieldsinformationmodel);
                //}


                using (FormsAndFieldsMySqlBusinessAccess formsandfieldsinfobusinesacess = new FormsAndFieldsMySqlBusinessAccess())
                {
                    responsemodel = await formsandfieldsinfobusinesacess.GetFieldsInfoList(oasfieldsinformationmodel);
                }

                //ehrcommondatastoremodel.emrwebexceptiontracelogmodel.AddToExecutionLog("EHRGoogleDataStore.Controllers", "DataStoreController", "AppServersList", "AppServersList End", ExecutionLogType.Detail);

            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }
            finally
            {

            }

            return Ok(responsemodel);

        }

        #endregion
    }
}
