﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OAS_App_API.ExceptionTracking;
using OAS_App_BusinessFaccade.Employee;
using OAS_App_BusinessFaccade.Organization;
using OAS_App_Common;
using OAS_App_Common.Organization;
using Microsoft.AspNetCore.Cors;

namespace OAS_App_API.Controllers
{
    [Consumes("application/json")]
    [Produces("application/json")]
    [Route("api/Organization")]
    [EnableCors("AllowSpecificOrigin")]
    public class OrganizationController : Controller
    {




        #region "     ADD OR UPDATE ORGANIZATION DETAILS       "
        /// <summary>
        /// THIS METHOD IS USEFUL IN ADDING OR UPDATING ORGANIZATION DETAILS LIST      
        /// </summary>
        /// <param name="ehrcommondatastoremodel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("SaveAndUpdateOrganizationInfo")]
        public async Task<IActionResult> SaveAndUpdateOrganizationInfo_Main([FromBody] OrganizationInfo organizationModel)
        {
            BaseModel baseModel = null;

            try
            {
                if (organizationModel == null)
                    return BadRequest("Provide Valid Data.");

                using (OrganizationBusinessAccess oasauthenticationObj = new OrganizationBusinessAccess())
                {
                    baseModel = await oasauthenticationObj.SaveAndUpdateOrganizationInfo(organizationModel);
                }

                return Ok(baseModel);
            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }

        }


        #endregion


        #region "     DELETE ORGANIZATION DETAILS       "
        [HttpPost]
        [Route("DeleteOrganizationDetails")]
        public async Task<IActionResult> DeleteOrganizationDetails_Main([FromBody] OrganizationInfo organizationModel)
        {
            BaseModel baseModel = null;

            try
            {
                if (organizationModel == null)
                    return BadRequest("Provide Valid Data.");

                using (OrganizationBusinessAccess oasauthenticationObj = new OrganizationBusinessAccess())
                {
                    baseModel = await oasauthenticationObj.DeleteOrganizationDetails(organizationModel);
                }

                return Ok(baseModel);
            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }

        }
        #endregion


        #region "     ORGANZATION DETAILS LIST          "
        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING ORGANZATION DETAILS LIST      
        /// </summary>
        /// <param name="ehrcommondatastoremodel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("OASOrganizationList")]
        public async Task<IActionResult> OASOrganizationList_Main([FromBody]  OrganizationInfo organizationModel)
        {
            OrganizationInfo responsemodel = null;
            try
            {
                //responsemodel.emrwebexceptiontracelogmodel.AddToExecutionLog("EHRGoogleDataStore.Controllers", "DataStoreController", "AppServersList", "AppServersList Start", ExecutionLogType.Detail);


                if (organizationModel == null)
                {
                    return BadRequest("Invalid Request Data");
                }

                using (OrganizationBusinessAccess oasauthenticationObj = new OrganizationBusinessAccess())
                {
                    responsemodel = await oasauthenticationObj.OASOrganizationList(organizationModel);
                }

                //ehrcommondatastoremodel.emrwebexceptiontracelogmodel.AddToExecutionLog("EHRGoogleDataStore.Controllers", "DataStoreController", "AppServersList", "AppServersList End", ExecutionLogType.Detail);

            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }
            finally
            {

            }

            return Ok(responsemodel);

        }

        #endregion


    }
}