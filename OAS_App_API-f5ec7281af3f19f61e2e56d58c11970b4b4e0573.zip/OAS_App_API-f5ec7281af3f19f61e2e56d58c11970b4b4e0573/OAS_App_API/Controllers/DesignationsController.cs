﻿using OAS_App_Common;
using System;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OAS_App_Common;
using OAS_App_BusinessFaccade.Employee;
using OAS_App_API.ExceptionTracking;
using OAS_App_Common.Employee;
using Microsoft.AspNetCore.Cors;
using OAS_App_BusinessFaccade.Designations;

namespace OAS_App_API.Controllers
{
    [Consumes("application/json")]
    [Produces("application/json")]
    [Route("api/Designations")]
    [EnableCors("AllowSpecificOrigin")]

    public class DesignationsController:Controller
    {
        [HttpPost]
        [Route("AddEditDesignations")]
        public async Task<IActionResult> AddEditDesignations_Main([FromBody] DesignationsInfoModel inputmodel)
        {
            BaseModel baseModel = null;

            try
            {
                if (inputmodel == null)
                    return BadRequest("Provide Valid Data.");

                using (EmployeeDesignationsBusinessAccess employeedesignationsbusinessaccessobj = new EmployeeDesignationsBusinessAccess())
                {
                    baseModel = await employeedesignationsbusinessaccessobj.AddEditDesignations(inputmodel);
                }

                return Ok(baseModel);
            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }

        }


        [HttpPost]
        [Route("DeleteDesignations")]
        public async Task<IActionResult> DeleteDesignations_Main([FromBody] DesignationsInfoModel inputmodel)
        {
            BaseModel baseModel = null;

            try
            {
                if (inputmodel == null)
                    return BadRequest("Provide Valid Data.");

                using (EmployeeDesignationsBusinessAccess employeedesignationsbusinessaccessobj = new EmployeeDesignationsBusinessAccess())
                {
                    baseModel = await employeedesignationsbusinessaccessobj.DeleteDesignations(inputmodel);
                }

                return Ok(baseModel);
            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }

        }


        #region "     EMPLOYEE DETAILS LIST          "
        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING   APPSERVERS DETAILS LIST      
        /// </summary>
        /// <param name="ehrcommondatastoremodel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("GetDesignationsList")]
        public async Task<IActionResult> GetDesignationsList_Main([FromBody]  DesignationsInfoModel inputmodel)
        {
            DesignationsInfoModel responsemodel = null;
            try
            {
                //responsemodel.emrwebexceptiontracelogmodel.AddToExecutionLog("EHRGoogleDataStore.Controllers", "DataStoreController", "AppServersList", "AppServersList Start", ExecutionLogType.Detail);


                if (inputmodel == null)
                {
                    return BadRequest("Invalid Request Data");
                }

                using (EmployeeDesignationsBusinessAccess employeedesignationsbusinessaccessobj = new EmployeeDesignationsBusinessAccess())
                {
                    responsemodel = await employeedesignationsbusinessaccessobj.GetDesignationsList(inputmodel);
                }

                //ehrcommondatastoremodel.emrwebexceptiontracelogmodel.AddToExecutionLog("EHRGoogleDataStore.Controllers", "DataStoreController", "AppServersList", "AppServersList End", ExecutionLogType.Detail);

            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }
            finally
            {

            }

            return Ok(responsemodel);

            //return Json(responsemodel);

        }

        #endregion
    }
}
