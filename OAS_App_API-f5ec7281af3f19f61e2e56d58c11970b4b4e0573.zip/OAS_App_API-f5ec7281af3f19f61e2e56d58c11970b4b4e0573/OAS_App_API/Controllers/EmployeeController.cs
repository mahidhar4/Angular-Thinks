﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OAS_App_Common;
using OAS_App_BusinessFaccade.Employee;
using OAS_App_API.ExceptionTracking;
using OAS_App_Common.Employee;
using Microsoft.AspNetCore.Cors;

using OAS_App_BusinessFaccade.Common;
using OAS_App_Common.Common;

namespace OAS_App_API.Controllers
{
    [Consumes("application/json")]
    [Produces("application/json")]
    [Route("api/Employee")]
    [EnableCors("AllowSpecificOrigin")]
    public class EmployeeController : Controller
    {



        [HttpPost]
        [Route("AddEditEmployee")]
        public async Task<IActionResult> AddEditEmployee_Main([FromBody] EmployeeInfo loginmodel)
        {
            BaseModel baseModel = null;

            try
            {
                if (loginmodel == null)
                    return BadRequest("Provide Valid Data.");

                using (EmployeeBusinessAccess oasauthenticationObj = new EmployeeBusinessAccess())
                {
                    baseModel = await oasauthenticationObj.AddEditEmployee(loginmodel);
                }

                return Ok(baseModel);
            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }

        }


        [HttpPost]
        [Route("DeleteEmployee")]
        public async Task<IActionResult> DeleteEmployee_Main([FromBody] EmployeeInfo loginmodel)
        {
            BaseModel baseModel = null;

            try
            {
                if (loginmodel == null)
                    return BadRequest("Provide Valid Data.");

                using (EmployeeBusinessAccess oasauthenticationObj = new EmployeeBusinessAccess())
                {
                    baseModel = await oasauthenticationObj.DeleteEmployee(loginmodel);
                }

                return Ok(baseModel);
            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }

        }


        #region "     EMPLOYEE DETAILS LIST          "
        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING   APPSERVERS DETAILS LIST      
        /// </summary>
        /// <param name="ehrcommondatastoremodel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("OASEmployeesList")]
        public async Task<IActionResult> oasEmployeesList_Main([FromBody]  EmployeeInfo loginmodel)
        {
            EmployeeInfo responsemodel = null;
            try
            {
                //responsemodel.emrwebexceptiontracelogmodel.AddToExecutionLog("EHRGoogleDataStore.Controllers", "DataStoreController", "AppServersList", "AppServersList Start", ExecutionLogType.Detail);


                if (loginmodel == null)
                {
                    return BadRequest("Invalid Request Data");
                }

                using (EmployeeBusinessAccess oasauthenticationObj = new EmployeeBusinessAccess())
                {
                    responsemodel = await oasauthenticationObj.oasEmployeesList(loginmodel);
                }

                //ehrcommondatastoremodel.emrwebexceptiontracelogmodel.AddToExecutionLog("EHRGoogleDataStore.Controllers", "DataStoreController", "AppServersList", "AppServersList End", ExecutionLogType.Detail);

            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }
            finally
            {

            }

            return Ok(responsemodel);

            //return Json(responsemodel);

        }

        #endregion


        #region "     EMPLOYEE WORK EXPERIANCE INFO LIST "
        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING   APPSERVERS DETAILS LIST      
        /// </summary>
        /// <param name="ehrcommondatastoremodel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("oasEmployeesWorkExperianceInfoList")]
        public async Task<IActionResult> oasEmployeesWorkExperianceInfoList_Main([FromBody]  EmployeeInfo loginmodel)
        {
            EmployeeInfo responsemodel = null;
            try
            {
                //responsemodel.emrwebexceptiontracelogmodel.AddToExecutionLog("EHRGoogleDataStore.Controllers", "DataStoreController", "AppServersList", "AppServersList Start", ExecutionLogType.Detail);


                if (loginmodel == null)
                {
                    return BadRequest("Invalid Request Data");
                }

                using (EmployeeBusinessAccess oasauthenticationObj = new EmployeeBusinessAccess())
                {
                    responsemodel = await oasauthenticationObj.oasEmployeesWorkExperianceInfoList(loginmodel);
                }

                //ehrcommondatastoremodel.emrwebexceptiontracelogmodel.AddToExecutionLog("EHRGoogleDataStore.Controllers", "DataStoreController", "AppServersList", "AppServersList End", ExecutionLogType.Detail);

            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }
            finally
            {

            }

            return Ok(responsemodel);

            //return Json(responsemodel);

        }

        #endregion


        #region "     EMPLOYEE EDUCATION INFO LIST "
        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING   APPSERVERS DETAILS LIST      
        /// </summary>
        /// <param name="ehrcommondatastoremodel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("oasEmployeesEducationInfoList")]
        public async Task<IActionResult> oasEmployeesEducationInfoList_Main([FromBody]  EmployeeInfo loginmodel)
        {
            EmployeeInfo responsemodel = null;
            try
            {
                //responsemodel.emrwebexceptiontracelogmodel.AddToExecutionLog("EHRGoogleDataStore.Controllers", "DataStoreController", "AppServersList", "AppServersList Start", ExecutionLogType.Detail);


                if (loginmodel == null)
                {
                    return BadRequest("Invalid Request Data");
                }

                using (EmployeeBusinessAccess oasauthenticationObj = new EmployeeBusinessAccess())
                {
                    responsemodel = await oasauthenticationObj.oasEmployeesEducationInfoList(loginmodel);
                }

                //ehrcommondatastoremodel.emrwebexceptiontracelogmodel.AddToExecutionLog("EHRGoogleDataStore.Controllers", "DataStoreController", "AppServersList", "AppServersList End", ExecutionLogType.Detail);

            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }
            finally
            {

            }

            return Ok(responsemodel);

            //return Json(responsemodel);

        }

        #endregion



        #region "   ADD OR EDIT EMPLOYEE DETAILS INFO  "
        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING ADD OR EDIT DEPARTMENTS INFO  
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>

        [HttpPost]
        [Route("AddEditDepartmentInfo")]
        public async Task<IActionResult> AddEditDepartmentInfo_Main([FromBody] DepartmentsInfoModel departmentsinfomodel)
        {
            BaseModel baseModel = null;

            try
            {
                if (departmentsinfomodel == null)
                    return BadRequest("Provide Valid Data.");

                using (EmployeeBusinessAccess oasauthenticationObj = new EmployeeBusinessAccess())
                {
                    baseModel = await oasauthenticationObj.AddEditDepartmentInfo(departmentsinfomodel);
                }

                return Ok(baseModel);
            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }

        }


        #endregion


        [HttpPost]
        [Route("DeleteDepartmentInfo")]
        public async Task<IActionResult> DeleteDepartmentInfo_Main([FromBody] DepartmentsInfoModel inputmodel)
        {
            BaseModel baseModel = null;

            try
            {
                if (inputmodel == null)
                    return BadRequest("Provide Valid Data.");

                using (EmployeeBusinessAccess oasauthenticationObj = new EmployeeBusinessAccess())
                {
                    baseModel = await oasauthenticationObj.DeleteDepartmentInfo(inputmodel);
                }

                return Ok(baseModel);
            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }

        }


        #region "   UPDATE EMPLOYEE PASSWORD    "
        /// <summary>
        /// CHANGE EMPLOYEE PASSWORD
        /// ***** CREATED BY:   SANJAY IDPUGANTI *****
        /// ***** CREATED DATE: 4/30/2018        *****
        /// </summary>
        /// <param name="loginModel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("UpdateEmployeePassword")]
        public async Task<IActionResult> UpdateEmployeePassword_Main([FromBody] LoginModel loginModel)
        {
            ResponseModel response = null;

            try
            {
                if (loginModel == null)
                    return BadRequest("Provide Valid Data.");

                using (CommonMySqlBusinessAccess common = new CommonMySqlBusinessAccess())
                {
                    response = await common.UpdateEmployeePassword(loginModel);
                }

                return Ok(response);
            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }
        }
        #endregion


        #region "     DEPARTMENTS DETAILS LIST          "
        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING   APPSERVERS DETAILS LIST      
        /// </summary>
        /// <param name="ehrcommondatastoremodel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("GetDepartmentsList")]
        public async Task<IActionResult> GetDepartmentsList_Main([FromBody]  DepartmentsInfoModel inputmodel)
        {
            DepartmentsInfoModel responsemodel = null;
            try
            {
                //responsemodel.emrwebexceptiontracelogmodel.AddToExecutionLog("EHRGoogleDataStore.Controllers", "DataStoreController", "AppServersList", "AppServersList Start", ExecutionLogType.Detail);


                if (inputmodel == null)
                {
                    return BadRequest("Invalid Request Data");
                }

                using (EmployeeBusinessAccess oasauthenticationObj = new EmployeeBusinessAccess())
                {
                    responsemodel = await oasauthenticationObj.GetDepartmentsList(inputmodel);
                }

                //ehrcommondatastoremodel.emrwebexceptiontracelogmodel.AddToExecutionLog("EHRGoogleDataStore.Controllers", "DataStoreController", "AppServersList", "AppServersList End", ExecutionLogType.Detail);

            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }
            finally
            {

            }

            return Ok(responsemodel);

            //return Json(responsemodel);

        }

        #endregion

    }
}