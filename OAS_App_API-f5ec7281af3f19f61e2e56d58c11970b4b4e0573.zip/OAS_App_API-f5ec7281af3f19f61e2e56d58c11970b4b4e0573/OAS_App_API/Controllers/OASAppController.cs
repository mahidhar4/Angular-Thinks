﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using OAS_App_Common;
using OAS_App_BusinessFaccade;
using OAS_App_API.ExceptionTracking;
using Microsoft.AspNetCore.Cors;
using OAS_App_Common.Common;
using Microsoft.AspNetCore.Hosting.Internal;
using Microsoft.DotNet.PlatformAbstractions;
using OAS_App_BusinessFaccade.Common;
using OAS_App_Common.Organization;

namespace OAS_App_API.Controllers
{
    [Consumes("application/json")]
    [Produces("application/json")]
    [Route("api/OASApp")]
    [EnableCors("AllowSpecificOrigin")]
    public class OASAppController : Controller
    {

        [HttpGet]
        [Route("Test")]
        public async Task<IActionResult> ActionAuditLogRecordInsert()
        {


            return Ok("hai! oas app");

        }


        /// <summary>
        /// THIS METHOD IS USEFUL IN VALIDATING THE USER LOGIN
        /// </summary>
        /// <param name="loginmodel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("ValidateLogin")]
        public async Task<IActionResult> ValidateLogin_Main([FromBody] LoginModel loginmodel)
        {
            BaseModel baseModel = null;

            try
            {
                if (loginmodel == null)
                    return BadRequest("Provide Valid Data.");

                if (loginmodel.orgmodel.clientsessioninfo == null)
                    loginmodel.orgmodel.clientsessioninfo = new clientSessionInfo();

                if (string.IsNullOrEmpty(loginmodel.orgmodel.clientsessioninfo.ClientExternalIPAddress))
                    loginmodel.orgmodel.clientsessioninfo.ClientExternalIPAddress = GetClientIPAddressRemote();

                if (string.IsNullOrEmpty(loginmodel.orgmodel.clientsessioninfo.ClientAspLocalIPAddress))
                    loginmodel.orgmodel.clientsessioninfo.ClientAspLocalIPAddress = GetClientIPAddressLocal();





                using (OASAuthentication oasauthenticationObj = new OASAuthentication())
                {
                    baseModel = await oasauthenticationObj.ValidateAuthentication(loginmodel);
                }


                return Ok(baseModel);

                //return Ok(baseModel);
            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }

        }


        /// <summary>
        /// THIS METHOD IS USEFUL IN VALIDATING THE USER LOGIN
        /// </summary>
        /// <param name="loginmodel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("ValidateLoginByUserId")]
        public async Task<IActionResult> ValidateLoginByUserId_Main([FromBody] LoginModel loginmodel)
        {
            BaseModel baseModel = null;

            try
            {
                if (loginmodel == null)
                    return BadRequest("Provide Valid Data.");

                if (loginmodel.orgmodel.clientsessioninfo == null)
                    loginmodel.orgmodel.clientsessioninfo = new clientSessionInfo();

                if (string.IsNullOrEmpty(loginmodel.orgmodel.clientsessioninfo.ClientExternalIPAddress))
                    loginmodel.orgmodel.clientsessioninfo.ClientExternalIPAddress = GetClientIPAddressRemote();

                if (string.IsNullOrEmpty(loginmodel.orgmodel.clientsessioninfo.ClientAspLocalIPAddress))
                    loginmodel.orgmodel.clientsessioninfo.ClientAspLocalIPAddress = GetClientIPAddressLocal();


                using (OASAuthentication oasauthenticationObj = new OASAuthentication())
                {
                    baseModel = await oasauthenticationObj.ValidateAuthenticationByUserID(loginmodel);
                }


                return Ok(baseModel);

            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }

        }

        /// <summary>
        /// THIS METHOD IS USEFUL IN SAVING OR UPDATING THE META DETAILS OF THE FORM
        /// </summary>
        /// <param name="commonsavingmodel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("SaveFormData")]
        public async Task<IActionResult> SaveFormData_Main([FromBody] CommonSavingModel commonsavingmodel)
        {
            ResponseModel baseModel = null;

            try
            {
                if (commonsavingmodel == null)
                    return BadRequest("Provide Valid Data.");

                //using (OASAuthentication oasauthenticationObj = new OASAuthentication())
                //{
                //    baseModel = await oasauthenticationObj.SaveFormData(commonsavingmodel);
                //}

                using (CommonMySqlBusinessAccess oasauthenticationObj = new CommonMySqlBusinessAccess())
                {
                    baseModel = await oasauthenticationObj.SaveCommonMetaData(commonsavingmodel);
                }

                return Ok(baseModel);
            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }

        }

        [HttpPost]
        [Route("ValidateEmployeeLeave")]
        public async Task<IActionResult> ValidateEmployeeLeave([FromBody] CommonSavingModel commonSaving)
        {
            CommonSavingModel baseModel = null;

            try
            {
                if (commonSaving == null)
                    return BadRequest("Provide Valid Data.");

                using (CommonMySqlBusinessAccess businessAccess = new CommonMySqlBusinessAccess())
                {
                    baseModel = await businessAccess.ValidateEmployeeLeave(commonSaving);
                }

                return Ok(baseModel);
            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="commonsavingmodel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("UpdateFormData")]
        public async Task<IActionResult> UpdateFormData_Main([FromBody] CommonSavingModel commonsavingmodel)
        {
            ResponseModel baseModel = null;

            try
            {
                if (commonsavingmodel == null)
                    return BadRequest("Provide Valid Data.");

                using (OASAuthentication oasauthenticationObj = new OASAuthentication())
                {
                    baseModel = await oasauthenticationObj.UpdateFormData(commonsavingmodel);
                }

                return Ok(baseModel);
            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }

        }

        /// <summary>
        /// THIS METHOD IS USEFUL IN DELETING THE FORM DATA
        /// </summary>
        /// <param name="commonsavingmodel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("DeleteFormData")]
        public async Task<IActionResult> DeleteFormData_Main([FromBody] CommonSavingModel commonsavingmodel)
        {
            ResponseModel baseModel = null;

            try
            {
                if (commonsavingmodel == null)
                    return BadRequest("Provide Valid Data.");

                //using (OASAuthentication oasauthenticationObj = new OASAuthentication())
                //{
                //    baseModel = await oasauthenticationObj.DeleteFormData(commonsavingmodel);
                //}

                using (CommonMySqlBusinessAccess oasauthenticationObj = new CommonMySqlBusinessAccess())
                {
                    baseModel = await oasauthenticationObj.DeleteCommonMetaData(commonsavingmodel);
                }

                return Ok(baseModel);
            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }

        }

        /// <summary>
        /// THIS METHOD IS USEFUL GETTING THE LIST DATA TO SHOW IN THE VIEW
        /// </summary>
        /// <param name="commonsavingmodel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("GetFormData_List")]
        public async Task<IActionResult> GetFormData_List_Main([FromBody] CommonSavingModel commonsavingmodel)
        {
            CommonSavingModel baseModel = null;

            try
            {
                if (commonsavingmodel == null)
                    return BadRequest("Provide Valid Data.");

                //using (OASAuthentication oasauthenticationObj = new OASAuthentication())
                //{
                //    baseModel = await oasauthenticationObj.GetFormData_List(commonsavingmodel);
                //}

                using (CommonMySqlBusinessAccess oasauthenticationObj = new CommonMySqlBusinessAccess())
                {
                    baseModel = await oasauthenticationObj.ExecuteReportAndGetData(commonsavingmodel);
                }

                return Ok(baseModel);
            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }

        }

        [HttpPost]
        [Route("GetEmployeeLeaves")]
        public async Task<IActionResult> GetEmployeeLeaves([FromBody] CommonSavingModel commonSavingModel)
        {
            CommonSavingModel responseModel = null;

            try
            {
                if (commonSavingModel == null)
                    return BadRequest("Provide Valid Data.");

                using (CommonMySqlBusinessAccess businessAccess = new CommonMySqlBusinessAccess())
                {
                    responseModel = await businessAccess.GetEmployeeLeaves(commonSavingModel);
                }

                return Ok(responseModel);
            }
            catch (Exception ex)
            {

                throw new CustomException(ex);
            }
        }


        [HttpPost]
        [Route("GetDatatypes")]
        public async Task<IActionResult> GetDatatypesList_Main([FromBody] DataTypeModel datatypeModel)
        {
            DataTypeModel model = null;
            try
            {
                if (datatypeModel == null)
                {
                    return BadRequest("Provide Valid Data.");
                }

                using (CommonMySqlBusinessAccess oasauthenticationObj = new CommonMySqlBusinessAccess())
                {
                    model = await oasauthenticationObj.GetDatatypesList(datatypeModel);
                }

                return Ok(model);
            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }
        }



        [HttpPost]
        [Route("ExecuteValidations")]
        public async Task<IActionResult> ExecuteValidations_Main([FromBody] CommonSavingModel commonsavingmodel)
        {
            CommonSavingModel baseModel = null;

            try
            {
                if (commonsavingmodel == null)
                    return BadRequest("Provide Valid Data.");

                //using (OASAuthentication oasauthenticationObj = new OASAuthentication())
                //{
                //    baseModel = await oasauthenticationObj.GetFormData_List(commonsavingmodel);
                //}

                using (CommonMySqlBusinessAccess oasauthenticationObj = new CommonMySqlBusinessAccess())
                {
                    baseModel = await oasauthenticationObj.ExecuteReportAndGetData(commonsavingmodel);
                }

                return Ok(baseModel);
            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }

        }

        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING THE STATE MAINTAIN MODE INFORMATION
        /// </summary>
        /// <param name="commonsavingmodel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("GetFormData_List_Edit")]
        public async Task<IActionResult> GetFormData_List_Edit_Main([FromBody] CommonSavingModel commonsavingmodel)
        {
            CommonSavingModel baseModel = null;

            try
            {
                if (commonsavingmodel == null)
                    return BadRequest("Provide Valid Data.");

                //using (OASAuthentication oasauthenticationObj = new OASAuthentication())
                //{
                //    baseModel = await oasauthenticationObj.GetFormData_List_EditMode(commonsavingmodel);
                //}

                if (commonsavingmodel.CommonSavingRowData == null)
                    return BadRequest("Provide Record ID.");

                using (CommonMySqlBusinessAccess oasauthenticationObj = new CommonMySqlBusinessAccess())
                {
                    baseModel = await oasauthenticationObj.GetCommonMetaData_EditMode(commonsavingmodel);
                }

                return Ok(baseModel);
            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }

        }



        #region "       CLIENT IP ADDRESS       "

        /// <summary>
        /// THIS METHOD IS USED TO GET THE CLIENT IP ADDRESS
        /// </summary>
        /// <returns></returns>
        public string GetClientIPAddressRemote()
        {
            string ipaddress = "";
            string strdata = string.Empty;
            string ipaddresslocal = "";

            try
            {

                ipaddress = HttpContext.Connection.RemoteIpAddress.ToString();

                ipaddresslocal = HttpContext.Connection.LocalIpAddress.ToString();


                System.IO.File.AppendAllText(ApplicationEnvironment.ApplicationBasePath + @"\temp\servervariables.txt", ipaddress + "|" + ipaddresslocal);

                //ipaddress = HttpContext.Request.HttpContext.Request.ser;// HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

                //if (ipaddress == "" || ipaddress == null)
                //    ipaddress = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];

                //if (HttpContext.Current.Request.ServerVariables.Keys.Count > 0)
                //{
                //    foreach (var item in HttpContext.Current.Request.ServerVariables.Keys)
                //    {
                //        strdata += item.ToString() + " : " + HttpContext.Current.Request.ServerVariables[item.ToString()] + "\r\n";
                //    }

                //    if (!Directory.Exists(HostingEnvironment.MapPath("~") + @"\temp\"))
                //    {
                //        Directory.CreateDirectory(HostingEnvironment.MapPath("~") + @"\temp\");
                //    }
                //    System.IO.File.WriteAllText(HostingEnvironment.MapPath("~") + @"\temp\servervariables.txt", strdata);

                //    // System.IO.File.WriteAllText(@"C:\BETA\path.txt", strdata);

                //}
            }
            catch (Exception ex)
            {
            }
            return ipaddress;
        }

        public string GetClientIPAddressLocal()
        {
            string ipaddresslocal = "";
            try
            {
                ipaddresslocal = HttpContext.Connection.LocalIpAddress.ToString();
            }
            catch (Exception ex)
            {
            }
            return ipaddresslocal;
        }

        #endregion


        #region "     NAV MENUS LIST     "
        /// <summary>
        /// THIS METHOD IS USEFUL GETTING THE LIST DATA TO NAV MENUS
        /// </summary>
        /// <param name="commonsavingmodel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("GetNavMenus_List")]
        public async Task<IActionResult> GetNavMenus_List_Main([FromBody] NavMenusModel navmenusmodel)
        {
            List<NavMenusModel> ModelResponse = null;

            try
            {
                if (navmenusmodel == null)
                    return BadRequest("Provide Valid Data.");

                using (OASAuthentication oasauthenticationObj = new OASAuthentication())
                {
                    ModelResponse = await oasauthenticationObj.GetNavMenus_List(navmenusmodel);
                }

                return Ok(ModelResponse);
            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }

        }
        #endregion

        #region "     NAV MENUS LIST     "
        /// <summary>
        /// THIS METHOD IS USEFUL GETTING THE LIST DATA TO NAV MENUS
        /// </summary>
        /// <param name="commonsavingmodel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("GetNavMenusInfoList")]
        public async Task<IActionResult> GetNavMenusInfoList_Main([FromBody] NavMenusModel navmenusmodel)
        {
            List<NavMenusModel> ModelResponse = null;

            try
            {
                if (navmenusmodel == null)
                    return BadRequest("Provide Valid Data.");

                using (OASAuthentication oasauthenticationObj = new OASAuthentication())
                {
                    ModelResponse = await oasauthenticationObj.GetNavMenusInfoList(navmenusmodel);
                }

                return Ok(ModelResponse);
            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }

        }
        #endregion


        #region "     ADD OR UPDATE MENUS INFORMATION     "
        /// <summary>
        /// THIS METHOD IS USEFUL IN ADDING OR UPDATING MENUS INFORMATION    
        /// </summary>
        /// <param name="ehrcommondatastoremodel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("SaveAndUpdateMenusInformation")]
        public async Task<IActionResult> SaveAndUpdateMenusInformation_Main([FromBody] NavMenusModel navmenusmodel)
        {
            ResponseModel baseModel = null;

            try
            {
                if (navmenusmodel == null)
                    return BadRequest("Provide Valid Data.");

                //using (FormsAndFieldsInfoBusinesAcess formsandfieldsinfobusinesacess = new FormsAndFieldsInfoBusinesAcess())
                //{
                //    baseModel = await formsandfieldsinfobusinesacess.SaveAndUpdateFormsInformation(oasformsinfomodel);
                //}

                using (OASAuthentication oasauthenticationObj = new OASAuthentication())
                {
                    baseModel = await oasauthenticationObj.SaveAndUpdateMenusInformation(navmenusmodel);
                }

                return Ok(baseModel);
            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }

        }


        #endregion

        #region "     DELETE MENUS INFORMATION     "
        /// <summary>
        /// THIS METHOD IS USEFUL IN ADDING OR UPDATING MENUS INFORMATION    
        /// </summary>
        /// <param name="ehrcommondatastoremodel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("DeleteMenusInformation")]
        public async Task<IActionResult> DeleteMenusInformation_Main([FromBody] NavMenusModel navmenusmodel)
        {
            ResponseModel baseModel = null;

            try
            {
                if (navmenusmodel == null)
                    return BadRequest("Provide Valid Data.");

                //using (FormsAndFieldsInfoBusinesAcess formsandfieldsinfobusinesacess = new FormsAndFieldsInfoBusinesAcess())
                //{
                //    baseModel = await formsandfieldsinfobusinesacess.SaveAndUpdateFormsInformation(oasformsinfomodel);
                //}

                using (OASAuthentication oasauthenticationObj = new OASAuthentication())
                {
                    baseModel = await oasauthenticationObj.DeleteMenusInformation(navmenusmodel);
                }

                return Ok(baseModel);
            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }

        }


        #endregion

        #region "   GET LINKED NAV MENUS LIST     "
        /// <summary>
        /// THIS METHOD IS USEFUL TO GET LINKED NAV MENUS LIST
        /// </summary>
        /// <param name="commonsavingmodel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("GetUserLinkedNavMenus_List")]
        public async Task<IActionResult> GetUserLinkedNavMenus_List_Main([FromBody] UserCustomizationNavMenusModel usercustomizationnavmenusmodel)
        {
            List<UserCustomizationNavMenusModel> ModelResponse = null;

            try
            {
                if (usercustomizationnavmenusmodel == null)
                    return BadRequest("Provide Valid Data.");

                using (OASAuthentication oasauthenticationObj = new OASAuthentication())
                {
                    ModelResponse = await oasauthenticationObj.GetUserLinkedNavMenus_List(usercustomizationnavmenusmodel);
                }

                return Ok(ModelResponse);
            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }

        }
        #endregion

        #region "    GET PROJECTS STATUS LIST INFORMATION     "
        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING PROJECTS STATUS LIST INFORMATION
        /// </summary>
        /// <param name="ehrcommondatastoremodel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("GetProjectsStausList")]
        public async Task<IActionResult> GetProjectsStausList_Main([FromBody] ProjectsStatusModel ProjectsStatusModel)
        {
            List<ProjectsStatusModel> projectsstatusmodelList = null;

            try
            {
                if (ProjectsStatusModel == null)
                    return BadRequest("Provide Valid Data.");

                using (OASAuthentication oasauthenticationObj = new OASAuthentication())
                {
                    projectsstatusmodelList = await oasauthenticationObj.GetProjectsStausList(ProjectsStatusModel);
                }

                return Ok(projectsstatusmodelList);
            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }

        }


        #endregion




        #region "    GET PROJECTS STATUS LIST INFORMATION     "
        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING PROJECTS STATUS LIST INFORMATION
        /// </summary>
        /// <param name="ehrcommondatastoremodel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("SaveAndUpdateCustomizedMenusInformation")]
        public async Task<IActionResult> SaveAndUpdateCustomizedMenusInformation_Main([FromBody] UserCustomizationNavMenusModel ProjectsStatusModel)
        {
            ResponseModel projectsstatusmodelList = null;

            try
            {
                if (ProjectsStatusModel == null)
                    return BadRequest("Provide Valid Data.");

                using (OASAuthentication oasauthenticationObj = new OASAuthentication())
                {
                    projectsstatusmodelList = await oasauthenticationObj.SaveAndUpdateCustomizedMenusInformation(ProjectsStatusModel);
                }

                return Ok(projectsstatusmodelList);
            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }

        }


        #endregion


        #region "   GET LINKED NAV MENUS LIST BASED ON ROLE     "
        /// <summary>
        /// THIS METHOD IS USEFUL TO GET LINKED NAV MENUS LIST
        /// </summary>
        /// <param name="commonsavingmodel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("GetNavMenusListBasedonRole")]
        public async Task<IActionResult> GetNavMenusListBasedonRole_Main([FromBody] UserCustomizationNavMenusModel usercustomizationnavmenusmodel)
        {
            List<UserCustomizationNavMenusModel> ModelResponse = null;

            try
            {
                if (usercustomizationnavmenusmodel == null)
                    return BadRequest("Provide Valid Data.");

                using (OASAuthentication oasauthenticationObj = new OASAuthentication())
                {
                    ModelResponse = await oasauthenticationObj.GetNavMenusListBasedonRole(usercustomizationnavmenusmodel);
                }

                return Ok(ModelResponse);
            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }

        }
        #endregion

        [HttpPost]
        [Route("GetTasksListInfo")]
        public async Task<IActionResult> GetTasksListInfo_Main([FromBody] CommonSavingModel commonsavingmodel)
        {
            CommonSavingModel responsemodel = null;

            try
            {
                if (commonsavingmodel == null)
                    return BadRequest("Provide Valid Data.");

                //using (OASAuthentication oasauthenticationObj = new OASAuthentication())
                //{
                //    baseModel = await oasauthenticationObj.GetFormData_List(commonsavingmodel);
                //}

                using (CommonMySqlBusinessAccess oasauthenticationObj = new CommonMySqlBusinessAccess())
                {
                    responsemodel = await oasauthenticationObj.GetTasksListInfo(commonsavingmodel);
                }

                return Ok(responsemodel);
            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }

        }

        [HttpPost]
        [Route("UpdateTaskStatus")]
        public async Task<IActionResult> UpdateTaskStatus_Main([FromBody] CommonSavingModel savemodel)
        {
            ResponseModel model = null;

            try
            {
                if (savemodel == null)
                    return BadRequest("Provide Valid Data.");

                using (CommonMySqlBusinessAccess oasauthenticationObj = new CommonMySqlBusinessAccess())
                {
                    model = await oasauthenticationObj.UpdateTaskStatus(savemodel);
                }

                return Ok(model);
            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }

        }


        [HttpPost]
        [Route("UpdateTaskResponsiblePerson")]
        public async Task<IActionResult> UpdateTaskResponsiblePerson_Main([FromBody] CommonSavingModel savemodel)
        {
            ResponseModel model = null;

            try
            {
                if (savemodel == null)
                    return BadRequest("Provide Valid Data.");

                using (CommonMySqlBusinessAccess oasauthenticationObj = new CommonMySqlBusinessAccess())
                {
                    model = await oasauthenticationObj.UpdateTaskResponsiblePerson(savemodel);
                }

                return Ok(model);
            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }

        }

        [HttpPost]
        [Route("UpdateMetaDataFieldsMultiple")]
        public async Task<IActionResult> UpdateMetaDataFieldsMultiple_Main([FromBody] CommonSavingModel savemodel)
        {
            ResponseModel model = null;

            try
            {
                if (savemodel == null)
                    return BadRequest("Provide Valid Data.");

                using (CommonMySqlBusinessAccess oasauthenticationObj = new CommonMySqlBusinessAccess())
                {
                    model = await oasauthenticationObj.UpdateMetaDataFieldsMultipleFields(savemodel);
                }

                return Ok(model);
            }
            catch (Exception ex)
            {
                throw new CustomException(ex);
            }

        }

    }
}
