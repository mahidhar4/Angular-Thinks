﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json.Serialization;
using System.Globalization;
using System.Threading;
using Microsoft.AspNetCore.Localization;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Microsoft.Extensions.DependencyInjection.Extensions;
using OAS_App_API.ExceptionTracking;

namespace OAS_App_API
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            //services.AddMvc();
            services
                .AddMvc()
                .AddJsonOptions(options => options.SerializerSettings.ContractResolver = new DefaultContractResolver());

            services.AddCors(options => options.AddPolicy("AllowSpecificOrigin",
                builder =>
                builder.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod()));

            System.Threading.Thread.CurrentThread.CurrentCulture = CultureInfo.CreateSpecificCulture("en-US");
            System.Threading.Thread.CurrentThread.CurrentUICulture = CultureInfo.CreateSpecificCulture("en-US");


            //services.Replace(typeof(ExceptionTracking), new ExceptionTracking.CustomException());

            //services.Replace();

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            // ADDING THE MIDDLE WARE LAYER IN THE API TO PROCESS THE REQUESTS IN A LOGGED MANNER TO FRONT END
            app.UseMiddleware(typeof(ErrorHandlingMiddleware));

            app.UseMvc();

            // Shows UseCors with named policy.
            app.UseCors("AllowSpecificOrigin");

            string enUSCulture = "en-US";

            app.UseRequestLocalization(new RequestLocalizationOptions
            {
                DefaultRequestCulture = new RequestCulture(enUSCulture),           
                
            });



            

            System.Threading.Thread.CurrentThread.CurrentCulture = CultureInfo.CreateSpecificCulture("en-US");
            System.Threading.Thread.CurrentThread.CurrentUICulture = CultureInfo.CreateSpecificCulture("en-US");

            //app.UseCors(builder =>
            //        builder.AllowAnyOrigin().AllowAnyMethod()
            //        .AllowAnyHeader()
            //    );
        }
    }

   

    
}
