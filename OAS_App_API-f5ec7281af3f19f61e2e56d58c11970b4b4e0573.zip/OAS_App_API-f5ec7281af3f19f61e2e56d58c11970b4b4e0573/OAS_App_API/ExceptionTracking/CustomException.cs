﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

namespace OAS_App_API.ExceptionTracking
{
    public class CustomException : Exception, IActionResult
    {


        public Exception _exception;

        public CustomException()
        {
        }

        public CustomException(Exception exception)
        {
            _exception = exception;
        }

        public Task ExecuteResultAsync(ActionContext context)
        {
            //HttpResponseMessage httpResponseMessage = httpRequestMessage.CreateResponse(HttpStatusCode.OK);
            //httpResponseMessage.Content = new StreamContent(bookStuff);
            ////httpResponseMessage.Content = new ByteArrayContent(bookStuff.ToArray());  
            //httpResponseMessage.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment");
            //httpResponseMessage.Content.Headers.ContentDisposition.FileName = PdfFileName;
            //httpResponseMessage.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");


            var code = HttpStatusCode.BadRequest; // 500 if unexpected

            var result = JsonConvert.SerializeObject(new { ErrorMessage = _exception.Message, RequestExecutionStatus = -2 });
            context.HttpContext.Response.ContentType = "application/json";
            context.HttpContext.Response.StatusCode = (int)code;
            return Task.FromResult(context.HttpContext.Response.WriteAsync(result));
            
        }
    }

    //public class eBookResult : IHttpActionResult
    //{
    //    MemoryStream bookStuff;
    //    string PdfFileName;
    //    HttpRequestMessage httpRequestMessage;
    //    HttpResponseMessage httpResponseMessage;
    //    public eBookResult(MemoryStream data, HttpRequestMessage request, string filename)
    //    {
    //        bookStuff = data;
    //        httpRequestMessage = request;
    //        PdfFileName = filename;
    //    }
    //    public System.Threading.Tasks.Task<HttpResponseMessage> ExecuteAsync(System.Threading.CancellationToken cancellationToken)
    //    {
    //        httpResponseMessage = httpRequestMessage.CreateResponse(HttpStatusCode.OK);
    //        httpResponseMessage.Content = new StreamContent(bookStuff);
    //        //httpResponseMessage.Content = new ByteArrayContent(bookStuff.ToArray());  
    //        httpResponseMessage.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment");
    //        httpResponseMessage.Content.Headers.ContentDisposition.FileName = PdfFileName;
    //        httpResponseMessage.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");

    //        return System.Threading.Tasks.Task.FromResult(httpResponseMessage);
    //    }
    //}


    /// <summary>
    /// THIS CLASS IS USEFUL IN BEHAVING AS LIKE A MIDDLE WARE FOR EACH REQUEST CALL OF THE API
    /// </summary>
    public class ErrorHandlingMiddleware
    {
        private readonly RequestDelegate next;

        public ErrorHandlingMiddleware(RequestDelegate next)
        {
            this.next = next;
        }

        public async Task Invoke(HttpContext context /* other dependencies */)
        {
            try
            {
                // handle all your request logging  here 
                await next(context);
            }
            catch (Exception ex)
            {
                await HandleExceptionAsync(context, ex);
            }
        }

        private static Task HandleExceptionAsync(HttpContext context, Exception exception)
        {

            // accepting as the success 
            var code = HttpStatusCode.OK; // 500 if unexpected

            //if (exception is KeyNotFoundException) code = HttpStatusCode.NotFound;

            //else if (exception is MyUnauthorizedException) code = HttpStatusCode.Unauthorized;
            //else if (exception is MyException) code = HttpStatusCode.BadRequest;

            var result = JsonConvert.SerializeObject(new { ErrorMessage = ((OAS_App_API.ExceptionTracking.CustomException)exception)._exception.Message, RequestExecutionStatus = -2 });
            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)code;
            return context.Response.WriteAsync(result);
        }
    }
}
