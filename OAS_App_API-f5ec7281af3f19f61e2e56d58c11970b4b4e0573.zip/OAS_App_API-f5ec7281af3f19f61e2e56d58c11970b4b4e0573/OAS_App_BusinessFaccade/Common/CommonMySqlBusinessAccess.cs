﻿using OAS_App_Common;
using OAS_App_Common.Common;
using OAS_App_DataAccess.common;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
using Google.Cloud.Storage.V1;
using System.Reflection;
using Google.Apis.Auth.OAuth2;
using OAS_App_Common.Employee;
using OAS_App_DataAccess.commonhelper;

namespace OAS_App_BusinessFaccade.Common
{
    public class CommonMySqlBusinessAccess : IDisposable
    {

        public async Task<DataTypeModel> GetDatatypesList(DataTypeModel dataTypeModel)
        {
            DataTypeModel responseModel = null;

            try
            {
                using (CommonDataAccess commonData = new CommonDataAccess())
                {
                    responseModel = await commonData.GetDatatypesList(dataTypeModel);
                }
            }
            finally
            {

            }
            return responseModel;
        }



        private string GetMasterDBName()
        {
            using (CommonHelper common = new CommonHelper())
            {
                if (common.intApplicationEnvironment == 3)
                    return "oas_master_production";
                else
                    return "oas_master";
            }

        }

        public ResponseModel GetExceptionModelWithResponse(object input)
        {
            object responseModel = null;

            if (input != null)
            {
                responseModel = (input as BaseModel);
                return (responseModel as ResponseModel);
            }
            else
                return null;
        }

        private string GetColumnNameBasedOnFieldID(long ColumnFieldID, long? FormID)
        {
            return ColumnFieldID > 0 ? "`c_" + ColumnFieldID.ToString() + "`" : (ColumnFieldID == 0 ? "" : (ColumnFieldID == -7793 ? "head" + FormID + "recordid" : ""));
        }

        private string GetColumnNameBasedOnFieldID(ReportsSelectFields selectField)
        {

            string FormIDTakend = selectField.FormID > 0 ? selectField.FormID.ToString() : selectField.FormIDToTakeForDefaultField;

            string FieldTaken = selectField.FieldID > 0 ? "`c_" + selectField.FieldID.ToString() + "`" : (selectField.FieldID == 0 ? "" :
                (selectField.FieldID == -7793 ? "head" + FormIDTakend + "recordid" : ""));


            FieldTaken = "FORM_" + FormIDTakend + "." + FieldTaken;

            return FieldTaken;
        }

        private string GetColumnNameBasedOnFieldID(ReportsFilterFields selectField)
        {

            string FormIDTakend = selectField.FormID > 0 ? selectField.FormID.ToString() : "";// : selectField.FormIDToTakeForDefaultField;

            string FieldTaken = selectField.FieldID > 0 ? "`c_" + selectField.FieldID.ToString() + "`" : (selectField.FieldID == 0 ? "" :
                (selectField.FieldID == -7793 ? "head" + FormIDTakend + "recordid" : ""));


            FieldTaken = "FORM_" + FormIDTakend + "." + FieldTaken;

            return FieldTaken;
        }

        private string GetColumnNameBasedOnFieldIDByDataType(ReportsFilterFields selectField)
        {

            string FormIDTakend = selectField.FormID > 0 ? selectField.FormID.ToString() : "";// : selectField.FormIDToTakeForDefaultField;


            string FieldTaken = selectField.FieldID > 0 ? "`c_" + selectField.FieldID.ToString() + "`" : (selectField.FieldID == 0 ? "" :
                (selectField.FieldID == -7793 ? "head" + FormIDTakend + "recordid" : ""));

            string FieldTakenFinal = "FORM_" + FormIDTakend + "." + FieldTaken;

            if (selectField.FieldDataType > 0)
            {
                //ref: https://www.w3schools.com/sql/func_mysql_cast.asp

                switch (selectField.FieldDataType)
                {
                    case FieldDataType.STRING:
                        break;
                    case FieldDataType.DATE:
                        FieldTakenFinal = "CAST(" + FieldTakenFinal + " as DATE)";
                        break;
                    case FieldDataType.DATETIME:
                        FieldTakenFinal = "CAST(" + FieldTakenFinal + " as DATETIME)";
                        break;
                    case FieldDataType.BOOLEAN:
                        break;
                    case FieldDataType.INTEGER:
                        FieldTakenFinal = "CAST(" + FieldTakenFinal + " as SIGNED)";
                        break;
                    case FieldDataType.DOUBLE:
                        FieldTakenFinal = "CAST(" + FieldTakenFinal + " as SIGNED)";
                        break;
                    case FieldDataType.FLOAT:
                        FieldTakenFinal = "CAST(" + FieldTakenFinal + " as SIGNED)";
                        break;
                    case FieldDataType.LONG:
                        FieldTakenFinal = "CAST(" + FieldTakenFinal + " as SIGNED)";
                        break;
                    case FieldDataType.GOOGLECLOUDHTML:
                        break;
                    default:
                        break;
                }
            }

            return FieldTakenFinal;
        }


        /// <summary>
        /// THIS METHOD IS USEFUL IN SAVING THE DATA BY EXECUTING THE SAVE TIME VALIDATIONS
        /// </summary>
        /// <param name="commonsavingmodel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> SaveCommonMetaData(CommonSavingModel commonsavingmodel)
        {
            ResponseModel responseModel = null;
            long recordID = 0;

            try
            {
                CommonSavingModel responseModelValidation = null;
                //perform duplicate validations while saving
                if (commonsavingmodel.ReportID > 0)
                {

                    const int SHIFT_VALIDATION_REPORT_ID = 63;
                    if (commonsavingmodel.ReportID == SHIFT_VALIDATION_REPORT_ID)
                    {
                        using (CommonDataAccess common = new CommonDataAccess())
                        {
                            responseModelValidation = await common.ValidateShift(commonsavingmodel);
                        }
                    }
                    else
                    {
                        //EXECUTE THE VALIDATION REPORTS
                        responseModelValidation = await ExecuteReportAndGetData(commonsavingmodel);
                    }
                    //EXECUTE THE VALIDATION REPORTS
                    //CommonSavingModel responseModelValidation = await ExecuteReportAndGetData(commonsavingmodel);


                    if (responseModelValidation != null)
                    {
                        if ((responseModelValidation.RequestExecutionStatus == null ||
                            responseModelValidation.RequestExecutionStatus == 0) &&
                            responseModelValidation.ResponseCnt > 0)
                        {
                            responseModel = new ResponseModel();
                            responseModel.ResponseID = responseModelValidation.ResponseCnt;
                            return responseModel;
                        }

                        else if (responseModelValidation.RequestExecutionStatus < 0)
                        {
                            responseModel = GetExceptionModelWithResponse(responseModelValidation);
                            return responseModel;
                        }
                    }
                }


                //if the current Record ID is already existsing then assigning it , other wise creating the new one
                if (commonsavingmodel.CommonSavingRowData.CommonSavingFieldsData != null && commonsavingmodel.CommonSavingRowData.CommonSavingFieldsData[0].RecordID > 0)
                    recordID = commonsavingmodel.CommonSavingRowData.CommonSavingFieldsData[0].RecordID;


                //CALLING THE SAVE RECORD META INFO IN DATA BASE
                using (CommonDataAccess commonData = new CommonDataAccess())
                {


                    #region  "   SAVING USER INFORMATION  "


                    //if (recordID == 0 && commonsavingmodel.CommonSavingRowData != null
                    //    && commonsavingmodel.CommonSavingRowData.CommonSavingFieldsData != null
                    //    && commonsavingmodel.CommonSavingRowData.CommonSavingFieldsData.Count > 0)
                    if (commonsavingmodel.CommonSavingRowData != null
                        && commonsavingmodel.CommonSavingRowData.CommonSavingFieldsData != null
                        && commonsavingmodel.CommonSavingRowData.CommonSavingFieldsData.Count > 0)
                    {

                        //EMPLOYEE INFORMATION FORM
                        if (Convert.ToInt64(commonsavingmodel.FormID) == 2018031716051198337)
                        {
                            //2018032014254536917  - Employee Login User ID
                            //2018031716080130631  - Employee Email ID (User name)
                            //2018031716081182733  - Employee Password

                            long[] fieldsEmployeeLogins = { 2018032014254536917, 2018031716080130631, 2018031716081182733 };

                            LoginModel loginModel = new LoginModel();
                            loginModel.orgmodel = commonsavingmodel.orgmodel;
                            bool isUserIDFieldFound = false;

                            var filteredFieldsList = commonsavingmodel.CommonSavingRowData.CommonSavingFieldsData.Where(
                                            item =>
                                                item.FieldID == 2018032014254536917
                                             || item.FieldID == 2018031716080130631
                                             || item.FieldID == 2018031716081182733).ToList();

                            if (filteredFieldsList != null && filteredFieldsList.Count > 0)
                            {
                                foreach (var item in filteredFieldsList)
                                {
                                    if (item.FieldID == 2018032014254536917)
                                    {
                                        loginModel.UserID = Convert.ToInt32(item.FieldValue.ToString());
                                        isUserIDFieldFound = true;
                                    }
                                    else if (item.FieldID == 2018031716080130631)
                                    {
                                        loginModel.loggeduseremailid = item.FieldValue.ToString();
                                    }
                                    else if (item.FieldID == 2018031716081182733)
                                    {
                                        loginModel.password_original = item.FieldValue.ToString();
                                        loginModel.loggeduserpassword = item.FieldValue.ToString();
                                        loginModel.UserType = Convert.ToInt32(UserTypes.Employee);
                                    }
                                }
                            }
                            //if (!isUserIDFieldFound)
                            //{

                            // insert mode
                            if (recordID == 0)
                                responseModel = await commonData.SaveUpdateOASUserInfo(loginModel);
                            // update mode
                            else
                                responseModel = await commonData.UpdateEmployeePassword(loginModel);

                            if (responseModel != null)
                            {
                                if (responseModel.RequestExecutionStatus == null
                                || responseModel.RequestExecutionStatus == 0)
                                {
                                    if (responseModel.ResponseID > 0)
                                    {
                                        //when not found in the list, adding it to the list
                                        if (!isUserIDFieldFound)
                                        {
                                            commonsavingmodel.CommonSavingRowData.CommonSavingFieldsData.Add(new CommonSavingFieldsModel()
                                            {
                                                FieldGroupID = 28,
                                                FieldSeqNumber = 28,
                                                FieldID = 2018032014254536917,
                                                FieldValue = responseModel.ResponseID.ToString(),
                                            });
                                        }
                                        //else
                                        //{
                                        //    foreach (var item in commonsavingmodel.CommonSavingRowData.CommonSavingFieldsData)
                                        //    {
                                        //        if (item.FieldID == 2018032014254536917)
                                        //        {
                                        //            item.FieldValue = responseModel.ResponseID;
                                        //        }
                                        //    }
                                        //}
                                    }
                                }
                                else if (responseModel.RequestExecutionStatus < 0)
                                {
                                    return responseModel;
                                }
                            }
                            //}
                        }
                    }

                    #endregion


                    //if the current Record ID is already existsing then assigning it , other wise creating the new one
                    if (commonsavingmodel.CommonSavingRowData.CommonSavingFieldsData != null && commonsavingmodel.CommonSavingRowData.CommonSavingFieldsData[0].RecordID > 0)
                        recordID = commonsavingmodel.CommonSavingRowData.CommonSavingFieldsData[0].RecordID;
                    else
                    {
                        using (OASCommonHelper helperObj = new OASCommonHelper())
                        {
                            recordID = helperObj.GetRandomNumber_DateUTC_Int();
                        }
                    }

                    #region " SAVING BINARY FIELDS DATA INTO GOOGLE AND GENERATING THE SIGNED URLS FOR THEM AND SAVING THEM INTO MYSQL FIELDS DATA "

                    //saving the binary data in cloud storage
                    commonsavingmodel = UploadBinaryObjectsToGoogleAndGetSignedURLS(commonsavingmodel, recordID);

                    #endregion

                    //saving the data in the data base
                    responseModel = await commonData.SaveCommonMetaData(commonsavingmodel, recordID);

                    if (responseModel != null && (responseModel.RequestExecutionStatus == null || responseModel.RequestExecutionStatus == 0))
                        responseModel.MultipleResponse = recordID.ToString();

                }

            }
            finally
            {

            }

            return responseModel;
        }

        public async Task<CommonSavingModel> GetEmployeeLeaves(CommonSavingModel commonSavingModel)
        {
            CommonSavingModel responseModel = null;

            try
            {
                using (CommonDataAccess common = new CommonDataAccess())
                {
                    responseModel = await common.GetEmployeeLeaves(commonSavingModel);
                }
            }
            finally
            {

            }
            return responseModel;
        }

        public async Task<CommonSavingModel> ValidateEmployeeLeave(CommonSavingModel commonSavingModel)
        {
            CommonSavingModel responseModel = null;

            try
            {
                using (CommonDataAccess common = new CommonDataAccess())
                {
                    responseModel = await common.ValidateEmployeeLeave(commonSavingModel);
                }
            }
            finally
            {

            }
            return responseModel;
        }




        /// <summary>
        /// THIS METHOD IS USEFUL IN UPLOADING THE BINARY OBJECTS TO THE GOOGLE 
        /// </summary>
        /// <param name="commonSavingModel"></param>
        /// <returns></returns>
        internal CommonSavingModel UploadBinaryObjectsToGoogleAndGetSignedURLS(CommonSavingModel commonSavingModel, long recordID)
        {

            StorageClient stroageClient = null;

            try
            {

                if (commonSavingModel != null && commonSavingModel.CommonSavingRowData != null &&
                    commonSavingModel.CommonSavingRowData.CommonSavingFieldsData != null &&
                    commonSavingModel.CommonSavingRowData.CommonSavingFieldsData.Count > 0)
                {



                    //getting all the html strings n base64 format type fields to upload into google cloud storage
                    var filteredFieldsList = commonSavingModel.CommonSavingRowData.CommonSavingFieldsData.Where(
                                    item => item.FieldType == FieldDataType.GOOGLECLOUDHTML).ToList();

                    //looping on all the fields list
                    if (filteredFieldsList != null && filteredFieldsList.Count > 0)
                    {

                        using (CommonCloudStorageBA commmonCloudStorageBAObj = new CommonCloudStorageBA())
                        {


                            //preparing the google credentials object instance with the credentials string json read from file
                            GoogleCredential storageClientGoogleCredential = commmonCloudStorageBAObj.GetGoogleCloudStorageCredentialsAssingedForCreating();

                            //// NEW INSTANCE TO CALL GOOGLE CLOUD STORAGE WITH CREDENTIALS VALUES BEFORE UPLOADING INFO INTO GOOGLE CLOUD STORAGE
                            stroageClient = StorageClient.Create(storageClientGoogleCredential);


                            //looping on all the fields list for uploading the binary into google
                            foreach (var itemInSavingFields in filteredFieldsList)
                            {
                                //checking field type
                                if (itemInSavingFields.FieldType == FieldDataType.GOOGLECLOUDHTML)
                                {
                                    if (itemInSavingFields.FieldValue != null && !string.IsNullOrEmpty(itemInSavingFields.FieldValue.ToString()))
                                    {
                                        string fileName = "";

                                        using (OASCommonHelper helperObj = new OASCommonHelper())
                                        {
                                            //savng the file under the current form with its fields folder and with its record id with current dateid in mmssfff
                                            fileName = "Form_" + commonSavingModel.FormID.ToString() + "/" + "Field_" + itemInSavingFields.FieldID.ToString() + "/" + "R" + recordID.ToString() + "_" + helperObj.GeDateUTC_Int().ToString();
                                        }

                                        //uploading the file content to the google cloud storage
                                        if (!string.IsNullOrEmpty(fileName))
                                        {
                                            using (CommonCloudStorageBA.GoogleStorageBucketInputInfo input = new CommonCloudStorageBA.GoogleStorageBucketInputInfo())
                                            {
                                                input.MethodName = this.GetType().FullName;

                                                input.BucketName = commmonCloudStorageBAObj.GetBucketName(commonSavingModel);

                                                //get the mime type
                                                input.FileMIMEType = commmonCloudStorageBAObj.GetMimeTypeBasedOnFileType(CommonCloudStorageBA.FileTypes.HTML);

                                                //get the folder path of the current module type
                                                input.FileNameWithFolderPath = commmonCloudStorageBAObj.GetFolderPath(CommonCloudStorageBA.ModuleTypes.HTMLBINARY, commonSavingModel) + fileName;

                                                //getting the original bytes content which is in base64 format
                                                input.FileContentInBinary = Convert.FromBase64String(itemInSavingFields.FieldValue.ToString());

                                                //uploading to the cloud storage
                                                Google.Apis.Storage.v1.Data.Object resultObject = commmonCloudStorageBAObj.UploadToGoogleCloudStorage(stroageClient, input, commonSavingModel);

                                                //means the binary has uploaded successfully to google cloud storage
                                                if (resultObject != null)
                                                {
                                                    //getting the signed URL for the current created folder or file 
                                                    string signedURL = commmonCloudStorageBAObj.GenerateSignedURLFromGCloud(input);

                                                    //assinging the signed URL into original field value
                                                    if (!string.IsNullOrEmpty(signedURL))
                                                    {
                                                        itemInSavingFields.FieldValue = signedURL;
                                                    }
                                                }

                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            finally
            {

            }
            return commonSavingModel;
        }








        /// <summary>
        /// THIS METHOD IS USEFUL IN DELETING THE META DATA RELATED TO THE FORM CURRENT RECORD ID
        /// </summary>
        /// <param name="commonsavingmodel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> DeleteCommonMetaData(CommonSavingModel commonsavingmodel)
        {
            ResponseModel responseModel = null;

            try
            {
                using (CommonDataAccess commonData = new CommonDataAccess())
                {
                    responseModel = await commonData.DeleteCommonMetaData(commonsavingmodel);
                }

                if (responseModel != null && (responseModel.RequestExecutionStatus == 0 || responseModel.RequestExecutionStatus == null))
                {
                    //checking if it is employee form or not
                    if (Convert.ToInt64(commonsavingmodel.FormID) == 2018031716051198337)
                    {
                        if (commonsavingmodel.CommonSearchFilterFieldsData != null && commonsavingmodel.CommonSearchFilterFieldsData.Count > 0)
                        {
                            //creating the logi model to delete the employee login
                            LoginModel loginModel = new LoginModel();

                            foreach (var item in commonsavingmodel.CommonSearchFilterFieldsData)
                            {
                                if (item.FieldID == 2018032014254536917)
                                {
                                    loginModel.UserID = Convert.ToInt32(item.FieldValue.ToString());
                                    break;
                                }
                                //else if (item.FieldID == 2018031716080130631)
                                //{
                                //    loginModel.loggeduseremailid = item.FieldValue.ToString();
                                //}
                                //else if (item.FieldID == 2018031716081182733)
                                //{
                                //    loginModel.password_original = item.FieldValue.ToString();
                                //    loginModel.loggeduserpassword = item.FieldValue.ToString();
                                //    loginModel.UserType = Convert.ToInt32(UserTypes.Employee);
                                //}
                            }
                            // cheking whether user info exists ornot
                            if (loginModel.UserID > 0)
                            {
                                using (CommonDataAccess commonData = new CommonDataAccess())
                                {
                                    loginModel.orgmodel = commonsavingmodel.orgmodel;
                                    responseModel = await commonData.DeleteEmployeeLogin(loginModel);
                                }
                            }

                        }
                    }
                }

            }
            finally
            {

            }

            return responseModel;
        }



        /// <summary>
        /// THIS  METHOD IS USEFUL IN GETTING THE EDIT MODE DATA OF THE CURRENT SAVED FORM RECORD INFORMATION
        /// </summary>
        /// <param name="commonsavingmodel"></param>
        /// <returns></returns>
        public async Task<CommonSavingModel> GetCommonMetaData_EditMode(CommonSavingModel commonsavingmodel)
        {
            CommonSavingModel responseModel = null;

            try
            {
                using (CommonDataAccess commonData = new CommonDataAccess())
                {
                    responseModel = await commonData.GetCommonMetaData_EditMode(commonsavingmodel);
                }
            }
            finally
            {

            }

            return responseModel;
        }


        public CommonSavingModel GetExceptionModel(object input)
        {
            object responseModel = null;

            if (input != null)
            {
                responseModel = (input as BaseModel);
                return (responseModel as CommonSavingModel);
            }
            else
                return null;
        }



        /// <summary>
        /// THIS METHOD IS USEFUL IN FORMING THE FILTER FIELDS WHERE CONDITION 
        /// </summary>
        /// <returns></returns>
        private string PrepareWhereConditionOnFields(ReportsFilterFields reportsFilterFields, CommonSavingModel commonsavingmodel)
        {

            StringBuilder stringBuilderWhereCondition = null;
            //string tablesWhereCondition = string.Empty;

            try
            {
                stringBuilderWhereCondition = new StringBuilder();

                if (reportsFilterFields != null && reportsFilterFields.ReportsFilterFieldsList != null
                    && reportsFilterFields.ReportsFilterFieldsList.Count > 0
                    && commonsavingmodel.CommonSearchFilterFieldsData != null && commonsavingmodel.CommonSearchFilterFieldsData.Count > 0)
                {

                    var filteredCurrentFormSelectList = reportsFilterFields.ReportsFilterFieldsList;


                    List<CommonSavingFieldsModel> filteredCurrentFieldValuesHasValues = (from item in commonsavingmodel.CommonSearchFilterFieldsData
                                                                                         where (item.FieldValue != null && !string.IsNullOrEmpty(item.FieldValue.ToString())
                                                                                                || item.FieldValue2 != null && !string.IsNullOrEmpty(item.FieldValue2.ToString()))
                                                                                         select item).ToList();

                    if (filteredCurrentFieldValuesHasValues == null || filteredCurrentFieldValuesHasValues.Count <= 0) return "";

                    int totalFiltersCnt = filteredCurrentFormSelectList.Count();
                    int filtersValuesCnt = filteredCurrentFieldValuesHasValues.Count();

                    if (filteredCurrentFormSelectList != null && totalFiltersCnt > 0 && filtersValuesCnt > 0)
                    {
                        int indexInLoopFilters = 0;

                        //looping on all filter fields
                        foreach (ReportsFilterFields itemFilterFieldInForm in filteredCurrentFormSelectList)
                        {

                            if (itemFilterFieldInForm.FieldID == null || itemFilterFieldInForm.FieldID == 0) continue;

                            List<CommonSavingFieldsModel> filteredCurrentFieldValues = (from item in filteredCurrentFieldValuesHasValues
                                                                                        where item.FieldID == itemFilterFieldInForm.FieldID
                                                                                        select item).ToList();

                            //when there is no value and if  there is no default values for it
                            //then not going to add the filter field in the list
                            if ((filteredCurrentFieldValues == null || filteredCurrentFieldValues.Count <= 0)
                                && (itemFilterFieldInForm.DefaultFieldValue == null || string.IsNullOrEmpty(itemFilterFieldInForm.DefaultFieldValue.ToString()))) continue;

                            //when there is no inpt data then also not adding the filter fields in the list
                            if (filteredCurrentFieldValues[0].FieldValue == null && filteredCurrentFieldValues[0].FieldValue2 == null) continue;

                            //when there is no inpt data then also not adding the filter fields in the list
                            if (string.IsNullOrEmpty(filteredCurrentFieldValues[0].FieldValue.ToString()) &&
                                (filteredCurrentFieldValues[0].FieldValue2 != null && string.IsNullOrEmpty(filteredCurrentFieldValues[0].FieldValue2.ToString()))) continue;

                            //tablesWhereCondition = tablesWhereCondition + GetColumnNameBasedOnFieldID(itemFilterFieldInForm);


                            indexInLoopFilters++;

                            stringBuilderWhereCondition.AppendLine(GetColumnNameBasedOnFieldID(itemFilterFieldInForm));

                            string filterFieldValues = "";
                            string filterFieldValues2 = "";


                            if (itemFilterFieldInForm.DefaultFieldValue != null)
                            {
                                string test = itemFilterFieldInForm.DefaultFieldValue.ToString();

                                if (!string.IsNullOrEmpty(test))
                                {
                                    if (test.IndexOf("~^~") > 0)
                                    {
                                        filterFieldValues = test.Split("~^~")[0].ToString();
                                        filterFieldValues2 = test.Split("~^~")[1].ToString();
                                    }
                                    else
                                    {
                                        filterFieldValues = test.ToString();
                                        filterFieldValues2 = "{{value2_c_" + itemFilterFieldInForm.FieldID + "}}";
                                    }
                                }
                                else
                                {
                                    filterFieldValues = "{{value1_c_" + itemFilterFieldInForm.FieldID + "}}";
                                    filterFieldValues2 = "{{value2_c_" + itemFilterFieldInForm.FieldID + "}}";
                                }
                            }
                            else
                            {
                                filterFieldValues = "{{value1_c_" + itemFilterFieldInForm.FieldID + "}}";
                                filterFieldValues2 = "{{value2_c_" + itemFilterFieldInForm.FieldID + "}}";
                            }

                            //applying the condition mode 
                            switch (itemFilterFieldInForm.ConditionMode)
                            {
                                case ReportsConditionMode.IN:
                                    stringBuilderWhereCondition.Append(" in " + filterFieldValues);
                                    break;
                                case ReportsConditionMode.NOTIN:
                                    stringBuilderWhereCondition.Append(" not in (" + filterFieldValues + ")");
                                    break;
                                case ReportsConditionMode.BETWEEN:
                                    stringBuilderWhereCondition.Append(" between " + filterFieldValues + " and " + filterFieldValues2);
                                    break;
                                case ReportsConditionMode.STARTSWITH:
                                    stringBuilderWhereCondition.Append(" like '" + filterFieldValues + "%'");
                                    break;
                                case ReportsConditionMode.CONTAINS:
                                    stringBuilderWhereCondition.Append(" like '%" + filterFieldValues + "%'");
                                    break;
                                case ReportsConditionMode.ENDSWITH:
                                    stringBuilderWhereCondition.Append(" like '%" + filterFieldValues + "'");
                                    break;
                                case ReportsConditionMode.LESSTHAN:
                                    stringBuilderWhereCondition.Append(" < " + filterFieldValues);
                                    break;
                                case ReportsConditionMode.GREATERTHAN:
                                    stringBuilderWhereCondition.Append(" > " + filterFieldValues);
                                    break;
                                case ReportsConditionMode.LESSTHANEQUAL:
                                    stringBuilderWhereCondition.Append(" <= " + filterFieldValues);
                                    break;
                                case ReportsConditionMode.GREATERTHANEQUAL:
                                    stringBuilderWhereCondition.Append(" >= " + filterFieldValues);
                                    break;
                                case ReportsConditionMode.EQUALS:
                                    stringBuilderWhereCondition.Append(" = " + filterFieldValues);
                                    break;
                                case ReportsConditionMode.NOTEQUALS:
                                    stringBuilderWhereCondition.Append(" != " + filterFieldValues);
                                    break;
                                case ReportsConditionMode.NOTNULL:
                                    stringBuilderWhereCondition.Append(" IS NOT NULL");
                                    break;
                                case ReportsConditionMode.ISNULL:
                                    stringBuilderWhereCondition.Append(" IS NULL");
                                    break;
                                default:
                                    break;
                            }

                            //appending the condition mode only when it is not last field
                            if (indexInLoopFilters < totalFiltersCnt && indexInLoopFilters < filtersValuesCnt)
                            {
                                switch (itemFilterFieldInForm.ConditionType)
                                {
                                    case ReportsConditionType.AND:
                                        stringBuilderWhereCondition.Append(" and ");
                                        break;
                                    case ReportsConditionType.OR:
                                        stringBuilderWhereCondition.Append(" or ");
                                        break;
                                    default:
                                        break;
                                }
                            }

                        }
                    }


                }


                return stringBuilderWhereCondition.ToString();
            }

            finally
            {

            }

        }



        /// <summary>
        /// THIS METHOD IS USEFUL IN EXCEUTING THE REPORT AND GETTING THE DATA 
        /// </summary>
        /// <param name="commonsavingmodel"></param>
        /// <returns></returns>
        public async Task<CommonSavingModel> ExecuteReportAndGetData(CommonSavingModel commonsavingmodel)
        {
            CommonSavingModel responseModel = null;
            ReportsSelectFields ReportsSelectFieldsresult = null;
            ReportsSelectFields ReportsAllFieldsresult = null;
            ReportsFilterFields ReportsFilterFieldsresult = null;
            ReportsFilterFields ReportsSortFieldsresult = null;
            ReportsFormTablesInvolved ReportsFormTablesInvolvedObjresult = null;
            ReportsFormTablesInvolved ReportsFormTablesInvolvedUniqueObjresult = null;
            ReportsFormTableColumnsFieldsInvolved ReportsFormTableColumnsFieldsInvolvedresult = null;
            long recordID = 0;
            StringBuilder tempTableDropping = null;

            StringBuilder tempTableDroppingIfExists = null;
            StringBuilder stringBuilderFinal = null;
            StringBuilder tempTablesCreation = null;
            StringBuilder sortingdetails = null;

            try
            {

                tempTableDropping = new StringBuilder();
                tempTableDroppingIfExists = new StringBuilder();
                stringBuilderFinal = new StringBuilder();
                tempTablesCreation = new StringBuilder();
                sortingdetails = new StringBuilder(5000);

                //while saving/updating the meta data
                if (commonsavingmodel.CommonSavingRowData != null && commonsavingmodel.CommonSavingRowData.CommonSavingFieldsData != null &&
                    commonsavingmodel.CommonSavingRowData.CommonSavingFieldsData.Count > 0 && commonsavingmodel.CommonSavingRowData.CommonSavingFieldsData[0].RecordID > 0)
                    recordID = commonsavingmodel.CommonSavingRowData.CommonSavingFieldsData[0].RecordID;

                using (CommonDataAccess commonData = new CommonDataAccess())
                {

                    ReportsModel reportInformation = await commonData.GetReportInformation(commonsavingmodel);


                    //getting the select fields list for report
                    using (ReportsSelectFields ReportsSelectFieldsObj = new ReportsSelectFields())
                    {
                        ReportsSelectFieldsObj.orgmodel = commonsavingmodel.orgmodel;
                        ReportsSelectFieldsObj.ReportID = commonsavingmodel.ReportID;
                        ReportsSelectFieldsresult = await commonData.GetReportsSelectFieldsList(ReportsSelectFieldsObj);
                    }

                    if (ReportsSelectFieldsresult != null)
                    {
                        if (ReportsSelectFieldsresult.RequestExecutionStatus < 0)
                        {
                            responseModel = GetExceptionModel(ReportsSelectFieldsresult);
                            return responseModel;
                        }
                    }


                    //getting the all fields list for report
                    using (ReportsSelectFields ReportsSelectFieldsObj = new ReportsSelectFields())
                    {
                        ReportsSelectFieldsObj.orgmodel = commonsavingmodel.orgmodel;
                        ReportsSelectFieldsObj.ReportID = commonsavingmodel.ReportID;
                        ReportsAllFieldsresult = await commonData.GetReportsLinkedAllFormFieldsList(ReportsSelectFieldsObj);
                    }


                    if (ReportsAllFieldsresult != null)
                    {
                        if (ReportsAllFieldsresult.RequestExecutionStatus < 0)
                        {
                            responseModel = GetExceptionModel(ReportsAllFieldsresult);
                            return responseModel;
                        }
                    }




                    //getting the filter fields list for report
                    using (ReportsFilterFields ReportsFilterFieldsObj = new ReportsFilterFields())
                    {
                        ReportsFilterFieldsObj.orgmodel = commonsavingmodel.orgmodel;
                        ReportsFilterFieldsObj.ReportID = commonsavingmodel.ReportID;
                        ReportsFilterFieldsresult = await commonData.GetReportsFilterFieldsList(ReportsFilterFieldsObj);
                    }

                    if (ReportsFilterFieldsresult != null)
                    {
                        if (ReportsFilterFieldsresult.RequestExecutionStatus < 0)
                        {
                            responseModel = GetExceptionModel(ReportsFilterFieldsresult);
                            return responseModel;
                        }
                    }


                    //getting the sort fields list for report
                    using (ReportsFilterFields ReportsFilterFieldsObj = new ReportsFilterFields())
                    {
                        ReportsFilterFieldsObj.orgmodel = commonsavingmodel.orgmodel;
                        ReportsFilterFieldsObj.ReportID = commonsavingmodel.ReportID;
                        ReportsSortFieldsresult = await commonData.GetReportsSortFieldsList(ReportsFilterFieldsObj);
                    }

                    if (ReportsSortFieldsresult != null)
                    {
                        if (ReportsSortFieldsresult.RequestExecutionStatus < 0)
                        {
                            responseModel = GetExceptionModel(ReportsSortFieldsresult);
                            return responseModel;
                        }
                    }


                    //getting list of tables/forms involved in joins for this report
                    using (ReportsFormTablesInvolved ReportsFormTablesInvolvedObj = new ReportsFormTablesInvolved())
                    {
                        ReportsFormTablesInvolvedObj.orgmodel = commonsavingmodel.orgmodel;
                        ReportsFormTablesInvolvedObj.ReportID = commonsavingmodel.ReportID;
                        ReportsFormTablesInvolvedObjresult = await commonData.GetReportsFormTablesInvolvedList(ReportsFormTablesInvolvedObj);
                    }

                    if (ReportsFormTablesInvolvedObjresult != null)
                    {
                        if (ReportsFormTablesInvolvedObjresult.RequestExecutionStatus < 0)
                        {
                            responseModel = GetExceptionModel(ReportsFormTablesInvolvedObjresult);
                            return responseModel;
                        }
                    }

                    //getting list of tables/forms UNIQUE LIST involved in joins for this report
                    using (ReportsFormTablesInvolved ReportsFormTablesInvolvedObj = new ReportsFormTablesInvolved())
                    {
                        ReportsFormTablesInvolvedObj.orgmodel = commonsavingmodel.orgmodel;
                        ReportsFormTablesInvolvedObj.ReportID = commonsavingmodel.ReportID;
                        ReportsFormTablesInvolvedUniqueObjresult = await commonData.GetReportsFormTablesInvolvedUniqueList(ReportsFormTablesInvolvedObj);
                    }

                    if (ReportsFormTablesInvolvedUniqueObjresult != null)
                    {
                        if (ReportsFormTablesInvolvedUniqueObjresult.RequestExecutionStatus < 0)
                        {
                            responseModel = GetExceptionModel(ReportsFormTablesInvolvedObjresult);
                            return responseModel;
                        }
                    }




                    //getting list of tables/forms with their fields involved in joins for this report
                    using (ReportsFormTableColumnsFieldsInvolved ReportsFormTableColumnsFieldsInvolvedObj = new ReportsFormTableColumnsFieldsInvolved())
                    {
                        ReportsFormTableColumnsFieldsInvolvedObj.orgmodel = commonsavingmodel.orgmodel;
                        ReportsFormTableColumnsFieldsInvolvedObj.ReportID = commonsavingmodel.ReportID;
                        ReportsFormTableColumnsFieldsInvolvedresult = await commonData.GetReportsFormTableInvolvedColumnsFieldsList(ReportsFormTableColumnsFieldsInvolvedObj);
                    }

                    if (ReportsFormTableColumnsFieldsInvolvedresult != null)
                    {
                        if (ReportsFormTableColumnsFieldsInvolvedresult.RequestExecutionStatus < 0)
                        {
                            responseModel = GetExceptionModel(ReportsFormTableColumnsFieldsInvolvedresult);
                            return responseModel;
                        }
                    }



                    // preparing the sort order of the list output
                    if (ReportsSortFieldsresult != null && ReportsSortFieldsresult.ReportsFilterFieldsList != null
                        && ReportsSortFieldsresult.ReportsFilterFieldsList.Count > 0)
                    {

                        bool isinside = false;

                        foreach (ReportsFilterFields item in ReportsSortFieldsresult.ReportsFilterFieldsList)
                        {
                            if (!isinside)
                            {
                                isinside = true;
                                sortingdetails.AppendLine(GetColumnNameBasedOnFieldIDByDataType(item) + " " + (item.sortorder == SortOrder.DESCENDING ? "desc" : "asc"));
                            }
                            else
                                sortingdetails.AppendLine("," + GetColumnNameBasedOnFieldIDByDataType(item) + " " + (item.sortorder == SortOrder.DESCENDING ? "desc" : "asc"));

                        }
                    }



                    //forming the sql query with customized details
                    StringBuilder stringBuilderTablesJoin = new StringBuilder();
                    string totalStringFormedQuery = string.Empty;

                    string tablesSelectList = string.Empty;
                    string tablesWhereCondition = string.Empty;


                    if (ReportsFormTablesInvolvedObjresult != null &&
                        ReportsFormTablesInvolvedObjresult.ReportsFormTablesInvolvedList != null
                        && ReportsFormTablesInvolvedObjresult.ReportsFormTablesInvolvedList.Count > 0)
                    {

                        //sorting the list by sequence
                        ReportsFormTablesInvolvedObjresult.ReportsFormTablesInvolvedList = ReportsFormTablesInvolvedObjresult.ReportsFormTablesInvolvedList.OrderBy(item => item.InvolvmentSequenceNumberTable).ToList();

                        //direct list query
                        if (reportInformation.ReportType == ReportType.DIRECTLIST)
                        {


                            foreach (ReportsFormTablesInvolved itemTableInvolvedInJoin in ReportsFormTablesInvolvedObjresult.ReportsFormTablesInvolvedList)
                            {
                                if (itemTableInvolvedInJoin.InvolvedTable1FormID != null && itemTableInvolvedInJoin.InvolvedTable1FormID > 0)
                                {

                                    tablesSelectList = "head_{{formid}}.recordid,body_{{formid}}.recorddataid,field.formid,body_{{formid}}.fieldid";

                                    //looping on all select fields
                                    if (ReportsSelectFieldsresult != null && ReportsSelectFieldsresult.ReportsSelectFieldsList != null
                                        && ReportsSelectFieldsresult.ReportsSelectFieldsList.Count > 0)
                                    {
                                        List<ReportsSelectFields> filteredCurrentFormSelectList = ReportsSelectFieldsresult.ReportsSelectFieldsList.Where(item =>
                                                                                        item.FormID == itemTableInvolvedInJoin.InvolvedTable1FormID
                                                                                        || (itemTableInvolvedInJoin.InvolvedTable2FormID != null && item.FormID == itemTableInvolvedInJoin.InvolvedTable2FormID)).ToList();


                                        if (filteredCurrentFormSelectList != null && filteredCurrentFormSelectList.Count > 0)
                                        {

                                            foreach (ReportsSelectFields itemSelectFieldInForm in filteredCurrentFormSelectList)
                                            {
                                                tablesSelectList = tablesSelectList + ",max(if(body_{{formid}}.fieldid = " + itemSelectFieldInForm.FieldID + " , body_{{formid}}.filedValue, NULL)) as `c_" + itemSelectFieldInForm.FieldID + "`";
                                            }

                                        }
                                    }

                                    //looping on all filter fields
                                    if (ReportsFilterFieldsresult != null && ReportsFilterFieldsresult.ReportsFilterFieldsList != null &&
                                        ReportsFilterFieldsresult.ReportsFilterFieldsList.Count > 0)
                                    {
                                        List<ReportsFilterFields> filteredCurrentFormSelectList = ReportsFilterFieldsresult.ReportsFilterFieldsList.Where(item =>
                                                        item.FormID == itemTableInvolvedInJoin.InvolvedTable1FormID
                                                        || (itemTableInvolvedInJoin.InvolvedTable2FormID != null && item.FormID == itemTableInvolvedInJoin.InvolvedTable2FormID)).ToList();

                                        int totalFiltersCnt = filteredCurrentFormSelectList.Count();

                                        if (filteredCurrentFormSelectList != null && totalFiltersCnt > 0)
                                        {
                                            int indexInLoopFilters = 0;

                                            //looping on all filter fields
                                            foreach (ReportsFilterFields itemFilterFieldInForm in filteredCurrentFormSelectList)
                                            {

                                                indexInLoopFilters++;

                                                if (itemFilterFieldInForm.FieldID == null || itemFilterFieldInForm.FieldID == 0) continue;

                                                tablesSelectList = tablesSelectList + "\n,max(if(body_{{formid}}.fieldid = " + itemFilterFieldInForm.FieldID + " , body_{{formid}}.filedValue, NULL)) as `cf_" + itemFilterFieldInForm.FieldID + "`";

                                                tablesWhereCondition = tablesWhereCondition + " `cf_" + itemFilterFieldInForm.FieldID + "`";

                                                string filterFieldValues = "";
                                                string filterFieldValues2 = "";


                                                if (itemFilterFieldInForm.DefaultFieldValue != null)
                                                {
                                                    string test = itemFilterFieldInForm.DefaultFieldValue.ToString();

                                                    if (!string.IsNullOrEmpty(test))
                                                    {
                                                        if (test.IndexOf("~^~") > 0)
                                                        {
                                                            filterFieldValues = test.Split("~^~")[0].ToString();
                                                            filterFieldValues2 = test.Split("~^~")[1].ToString();
                                                        }
                                                        else
                                                        {
                                                            filterFieldValues = test.ToString();
                                                            filterFieldValues2 = "{{value2_cf_" + itemFilterFieldInForm.FieldID + "}}";
                                                        }
                                                    }
                                                    else
                                                    {
                                                        filterFieldValues = "{{value1_cf_" + itemFilterFieldInForm.FieldID + "}}";
                                                        filterFieldValues2 = "{{value2_cf_" + itemFilterFieldInForm.FieldID + "}}";
                                                    }
                                                }
                                                else
                                                {
                                                    filterFieldValues = "{{value1_cf_" + itemFilterFieldInForm.FieldID + "}}";
                                                    filterFieldValues2 = "{{value2_cf_" + itemFilterFieldInForm.FieldID + "}}";
                                                }

                                                //applying the condition mode 
                                                switch (itemFilterFieldInForm.ConditionMode)
                                                {
                                                    case ReportsConditionMode.IN:
                                                        tablesWhereCondition = tablesWhereCondition + " in " + filterFieldValues;
                                                        break;
                                                    case ReportsConditionMode.NOTIN:
                                                        tablesWhereCondition = tablesWhereCondition + " not in (" + filterFieldValues + ")";
                                                        break;
                                                    case ReportsConditionMode.BETWEEN:
                                                        tablesWhereCondition = tablesWhereCondition + " between " + filterFieldValues + " and " + filterFieldValues2;
                                                        break;
                                                    case ReportsConditionMode.STARTSWITH:
                                                        tablesWhereCondition = tablesWhereCondition + " like '" + filterFieldValues + "%'";
                                                        break;
                                                    case ReportsConditionMode.CONTAINS:
                                                        tablesWhereCondition = tablesWhereCondition + " like '%" + filterFieldValues + "%'";
                                                        break;
                                                    case ReportsConditionMode.ENDSWITH:
                                                        tablesWhereCondition = tablesWhereCondition + " like '%" + filterFieldValues + "'";
                                                        break;
                                                    case ReportsConditionMode.LESSTHAN:
                                                        tablesWhereCondition = tablesWhereCondition + " < " + filterFieldValues;
                                                        break;
                                                    case ReportsConditionMode.GREATERTHAN:
                                                        tablesWhereCondition = tablesWhereCondition + " > " + filterFieldValues;
                                                        break;
                                                    case ReportsConditionMode.LESSTHANEQUAL:
                                                        tablesWhereCondition = tablesWhereCondition + " <= " + filterFieldValues;
                                                        break;
                                                    case ReportsConditionMode.GREATERTHANEQUAL:
                                                        tablesWhereCondition = tablesWhereCondition + " >= " + filterFieldValues;
                                                        break;
                                                    case ReportsConditionMode.EQUALS:
                                                        tablesWhereCondition = tablesWhereCondition + " = " + filterFieldValues;
                                                        break;
                                                    case ReportsConditionMode.NOTEQUALS:
                                                        tablesWhereCondition = tablesWhereCondition + " != " + filterFieldValues;
                                                        break;
                                                    case ReportsConditionMode.NOTNULL:
                                                        tablesWhereCondition = tablesWhereCondition + " IS NOT NULL";
                                                        break;
                                                    case ReportsConditionMode.ISNULL:
                                                        tablesWhereCondition = tablesWhereCondition + " IS NULL";
                                                        break;
                                                    default:
                                                        break;
                                                }

                                                //appending the condition mode only when it is not last field
                                                if (indexInLoopFilters < totalFiltersCnt)
                                                {
                                                    switch (itemFilterFieldInForm.ConditionType)
                                                    {
                                                        case ReportsConditionType.AND:
                                                            tablesWhereCondition = tablesWhereCondition + " and ";
                                                            break;
                                                        case ReportsConditionType.OR:
                                                            tablesWhereCondition = tablesWhereCondition + " or ";
                                                            break;
                                                        default:
                                                            break;
                                                    }
                                                }

                                            }
                                        }
                                    }


                                    string tablesForCurrentFormWithHeader = string.Empty;

                                    string tablesForCurrentFormWithBody = string.Empty;

                                    string tablesForMasterFields = string.Empty;

                                    string totalResult = string.Empty;

                                    tablesForCurrentFormWithHeader = "tbl_form_{{formid}}_metadata_header head_{{formid}} \n";

                                    tablesForCurrentFormWithBody = "tbl_form_{{formid}}_metadata_body body_{{formid}} on body_{{formid}}.recordid = head_{{formid}}.recordid and body_{{formid}}.datastatus = 0 \n";


                                    if ((itemTableInvolvedInJoin.InvolvmentJoinType == null || itemTableInvolvedInJoin.InvolvmentJoinType == 0)
                                        && itemTableInvolvedInJoin.InvolvedTable2FormID == null)
                                    {
                                        tablesForMasterFields = GetMasterDBName() + ".tbl_master_fields field on body_{{formid}}.fieldid = field.fieldid and field.datastatus = 0 \n";

                                        //totalResult = tablesForCurrentFormWithHeader + "\n inner join \n" + tablesForCurrentFormWithBody + "\n  inner join \n " + tablesForMasterFields + "where \n  head_{{formid}}.datastatus = 0 \n  group by head_{{formid}}.recordid";

                                        //totalResult = tablesForCurrentFormWithHeader + "\n inner join \n" + tablesForCurrentFormWithBody + "\n  inner join \n " + tablesForMasterFields + "where \n  head_{{formid}}.datastatus = 0 \n  group by head_{{formid}}.recordid";


                                        totalResult = tablesForCurrentFormWithHeader + "\n inner join \n" + tablesForCurrentFormWithBody + "\n  inner join \n " + tablesForMasterFields + "where \n  head_{{formid}}.datastatus = 0 \n  group by head_{{formid}}.recordid order by body_{{formid}}.recordid, body_{{formid}}.groupid, body_{{formid}}.sequenceingroup";

                                    }

                                    totalResult = totalResult.Replace("{{formid}}", itemTableInvolvedInJoin.InvolvedTable1FormID.ToString());

                                    tablesSelectList = tablesSelectList.Replace("{{formid}}", itemTableInvolvedInJoin.InvolvedTable1FormID.ToString());

                                    stringBuilderTablesJoin.AppendLine(totalResult);
                                }
                            }


                            totalStringFormedQuery = "select \n" + tablesSelectList + "\n from \n" + stringBuilderTablesJoin.ToString();
                        }

                        //relational list query
                        else if (reportInformation.ReportType == ReportType.RELATIONALLIST)
                        {



                            bool isVist = false;


                            //looping on all the fields
                            foreach (var item in ReportsSelectFieldsresult.ReportsSelectFieldsList)
                            {
                                if (!isVist)
                                {
                                    isVist = true;

                                    stringBuilderFinal.AppendLine(GetColumnNameBasedOnFieldID(item));
                                }
                                else
                                {
                                    stringBuilderFinal.AppendLine("," + GetColumnNameBasedOnFieldID(item));
                                }
                            }

                            reportInformation.p_SelectQuery = stringBuilderFinal.ToString();

                            int currentLoopIndex = 0;

                            int totalLengthofRelations = ReportsFormTablesInvolvedObjresult.ReportsFormTablesInvolvedList.Count();


                            if (ReportsFormTablesInvolvedUniqueObjresult.ReportsFormTablesInvolvedList != null
                                && ReportsFormTablesInvolvedUniqueObjresult.ReportsFormTablesInvolvedList.Count > 0)
                            {


                                //LOOPING ON UNIQUE FORMS INVOLVED IN THE RELATION TO MAKE THE REPORT
                                foreach (var item in ReportsFormTablesInvolvedUniqueObjresult.ReportsFormTablesInvolvedList)
                                {

                                    if (item.UniqueFormID == 0) continue;

                                    string tablesForCurrentFormWithHeader = string.Empty;

                                    string tablesForCurrentFormWithBody = string.Empty;

                                    string tablesForMasterFields = string.Empty;

                                    StringBuilder totalResult = new StringBuilder();

                                    StringBuilder tablesSelectListInside = new StringBuilder();

                                    tempTableDropping.AppendLine("DROP TEMPORARY TABLE tbl_Form_" + item.UniqueFormID + ";");

                                    tempTableDroppingIfExists.AppendLine("DROP TEMPORARY TABLE IF EXISTS tbl_Form_" + item.UniqueFormID + ";");

                                    tempTablesCreation.AppendLine();

                                    tempTablesCreation.AppendLine("CREATE TEMPORARY TABLE tbl_Form_" + item.UniqueFormID);

                                    tempTablesCreation.AppendLine(" ( ");

                                    tempTablesCreation.AppendLine(" head" + item.UniqueFormID + "recordid BIGINT");

                                    tablesSelectList = tablesSelectList + "\n head_{{formid}}.recordid";

                                    tablesSelectListInside.AppendLine("head_" + item.UniqueFormID.ToString() + ".recordid");


                                    //getting current form linked fields list
                                    var filteredCurrentFormList = ReportsAllFieldsresult.ReportsSelectFieldsList.Where(item1 =>
                                                                                        item1.FormID == item.UniqueFormID).ToList();

                                    //selecting all fields in current form
                                    foreach (ReportsSelectFields itemSelectFieldInForm in filteredCurrentFormList)
                                    {
                                        tempTablesCreation.AppendLine(",`c_" + itemSelectFieldInForm.FieldID + "` LONGTEXT");

                                        tablesSelectList = tablesSelectList + "\n,max(if(body_{{formid}}.fieldid = " + itemSelectFieldInForm.FieldID + " , body_{{formid}}.filedValue, NULL)) as `c_" + itemSelectFieldInForm.FieldID + "`";

                                        tablesSelectListInside.AppendLine(",max(if(body_" + item.UniqueFormID.ToString() + ".fieldid = " + itemSelectFieldInForm.FieldID + " , body_" + item.UniqueFormID.ToString() + ".filedValue, NULL)) as `c_" + itemSelectFieldInForm.FieldID + "`");
                                    }

                                    tempTablesCreation.AppendLine(" ); ");


                                    tempTablesCreation.AppendLine("INSERT INTO tbl_Form_" + item.UniqueFormID);

                                    tablesForCurrentFormWithHeader = "tbl_form_" + item.UniqueFormID.ToString() + "_metadata_header head_" + item.UniqueFormID.ToString() + " ";

                                    tablesForCurrentFormWithBody = "tbl_form_" + item.UniqueFormID.ToString() + "_metadata_body body_" + item.UniqueFormID.ToString() + " on body_" + item.UniqueFormID.ToString() + ".recordid = head_" + item.UniqueFormID.ToString() + ".recordid and body_" + item.UniqueFormID.ToString() + ".datastatus = 0 ";

                                    tablesForMasterFields = GetMasterDBName() + ".tbl_master_fields field on body_" + item.UniqueFormID.ToString() + ".fieldid = field.fieldid and field.datastatus = 0 ";

                                    // totalResult = tablesForCurrentFormWithHeader + "\n inner join \n" + tablesForCurrentFormWithBody + "\n  inner join \n " + tablesForMasterFields + "where \n  head_{{formid}}.datastatus = 0 \n  group by head_{{formid}}.recordid;";

                                    totalResult.AppendLine(tablesForCurrentFormWithHeader);

                                    totalResult.AppendLine("inner join");

                                    totalResult.AppendLine(tablesForCurrentFormWithBody);

                                    totalResult.AppendLine("inner join");

                                    totalResult.AppendLine(tablesForMasterFields);

                                    totalResult.AppendLine("where");

                                    totalResult.AppendLine("head_" + item.UniqueFormID.ToString() + ".datastatus = 0 ");

                                    totalResult.AppendLine("group by head_" + item.UniqueFormID.ToString() + ".recordid;");

                                    //tablesSelectList = tablesSelectList.Replace("{{formid}}", item.UniqueFormID.ToString());

                                    tempTablesCreation.AppendLine("select");

                                    tempTablesCreation.AppendLine(tablesSelectListInside.ToString());

                                    tempTablesCreation.AppendLine();

                                    tempTablesCreation.AppendLine("from");

                                    tempTablesCreation.AppendLine();

                                    tempTablesCreation.AppendLine(totalResult.ToString());

                                }

                                reportInformation.p_CreateQuery = tempTablesCreation.ToString();

                                string visitedForms1InJoin = string.Empty;
                                string visitedForms2InJoin = string.Empty;


                                foreach (ReportsFormTablesInvolved itemTableInvolvedInJoin in ReportsFormTablesInvolvedObjresult.ReportsFormTablesInvolvedList)
                                {
                                    if (itemTableInvolvedInJoin.InvolvedTable1FormID != null && itemTableInvolvedInJoin.InvolvedTable1FormID > 0
                                        && itemTableInvolvedInJoin.InvolvedTable2FormID != null && itemTableInvolvedInJoin.InvolvedTable2FormID > 0)
                                    {

                                        bool isExistsForm1 = false;
                                        bool isExistsForm2 = false;

                                        if (visitedForms1InJoin.IndexOf("F_" + itemTableInvolvedInJoin.InvolvedTable1FormID.ToString()) > -1)
                                        {
                                            isExistsForm1 = true;
                                        }
                                        else
                                        {
                                            visitedForms1InJoin += ",F_" + itemTableInvolvedInJoin.InvolvedTable1FormID.ToString();
                                        }

                                        if (visitedForms2InJoin.IndexOf("F_" + itemTableInvolvedInJoin.InvolvedTable2FormID.ToString()) > -1)
                                        {
                                            isExistsForm2 = true;
                                        }
                                        else
                                        {
                                            visitedForms2InJoin += ",F_" + itemTableInvolvedInJoin.InvolvedTable2FormID;
                                        }


                                        string totalResult = string.Empty;
                                        string joinConditions = string.Empty;

                                        currentLoopIndex++;

                                        if (!isExistsForm1)
                                            totalResult += "tbl_Form_" + itemTableInvolvedInJoin.InvolvedTable1FormID + " FORM_" + itemTableInvolvedInJoin.InvolvedTable1FormID;

                                        //getting current join involvement condition fields details
                                        var currentTableJOINLinkedConditions = ReportsFormTableColumnsFieldsInvolvedresult.ReportsFormTableColumnsFieldsInvolvedList.Where(
                                            item => item.ReportsFormTablesInvolvedInfoID == itemTableInvolvedInJoin.ReportsFormTablesInvolvedInfoID).ToList();

                                        if (currentTableJOINLinkedConditions != null && currentTableJOINLinkedConditions.Count > 0)
                                        {
                                            joinConditions += "1=1 and ";

                                            int joinCount = 0;
                                            int totalJoinsCondtions = currentTableJOINLinkedConditions.Count;

                                            foreach (var item in currentTableJOINLinkedConditions)
                                            {
                                                joinCount++;

                                                if (item.InvolvedTable1FormID > 0)
                                                    joinConditions += " FORM_" + item.InvolvedTable1FormID + "." + GetColumnNameBasedOnFieldID(item.InvolvedTable1ColumnFieldID, item.InvolvedTable1FormID) + " = ";


                                                if (!string.IsNullOrEmpty(item.InvolvedTable1ColumnFieldDefaultValue))
                                                {
                                                    joinConditions += item.InvolvedTable1ColumnFieldDefaultValue;
                                                }
                                                else
                                                {
                                                    if (item.InvolvedTable2FormID > 0)
                                                        joinConditions += " FORM_" + item.InvolvedTable2FormID + "." + GetColumnNameBasedOnFieldID(item.InvolvedTable2ColumnFieldID, item.InvolvedTable2FormID);
                                                }

                                                if (joinCount < totalJoinsCondtions)
                                                {
                                                    if (item.InvolvmentJoinType > 0)
                                                    {
                                                        switch (item.ColumsInvoled_ConditionType)
                                                        {
                                                            case ReportsConditionType.AND:
                                                                joinConditions += " AND ";
                                                                break;
                                                            case ReportsConditionType.OR:
                                                                joinConditions += " OR ";
                                                                break;
                                                            default:
                                                                break;
                                                        }
                                                    }
                                                }
                                            }
                                        }


                                        //when it is not last table relation
                                        if (currentLoopIndex <= totalLengthofRelations)
                                        {
                                            string joinstring = "";

                                            if (itemTableInvolvedInJoin.InvolvmentJoinType > 0)
                                            {
                                                switch (itemTableInvolvedInJoin.InvolvmentJoinType)
                                                {
                                                    case InvolvmentJoinType.INNERJOIN:
                                                        joinstring = "\n inner join \n";
                                                        break;
                                                    case InvolvmentJoinType.LEFTJOIN:
                                                        joinstring = "\n left join \n";
                                                        break;
                                                    case InvolvmentJoinType.RIGHTJOIN:
                                                        joinstring = "\n right join \n";
                                                        break;
                                                    default:
                                                        break;
                                                }

                                            }

                                            totalResult = totalResult + joinstring;
                                        }

                                        if (!isExistsForm2)
                                            totalResult += "tbl_Form_" + itemTableInvolvedInJoin.InvolvedTable2FormID + " FORM_" + itemTableInvolvedInJoin.InvolvedTable2FormID;


                                        if (!string.IsNullOrEmpty(joinConditions))
                                        {
                                            totalResult += " on " + joinConditions;
                                        }

                                        //append line
                                        stringBuilderTablesJoin.AppendLine(totalResult);

                                    }
                                }

                                reportInformation.p_BodyQuery = stringBuilderTablesJoin.ToString();

                                tablesWhereCondition = PrepareWhereConditionOnFields(ReportsFilterFieldsresult, commonsavingmodel);

                            }

                            //foreach (ReportsFormTablesInvolved itemTableInvolvedInJoin in ReportsFormTablesInvolvedObjresult.ReportsFormTablesInvolvedList)
                            //{
                            //    if (itemTableInvolvedInJoin.InvolvedTable1FormID != null && itemTableInvolvedInJoin.InvolvedTable1FormID > 0)
                            //    {
                            //        tablesSelectList = string.Empty;

                            //        string tablesForCurrentFormWithHeader = string.Empty;

                            //        string tablesForCurrentFormWithBody = string.Empty;

                            //        string tablesForMasterFields = string.Empty;

                            //        string totalResult = string.Empty;

                            //        currentLoopIndex++;

                            //        //getting current form linked fields list
                            //        var filteredCurrentFormList = ReportsAllFieldsresult.ReportsSelectFieldsList.Where(item =>
                            //                                                            item.FormID == itemTableInvolvedInJoin.InvolvedTable1FormID).ToList();

                            //        //making the record id as default column and then appending the rest of columns in the table data
                            //        tablesSelectList = "\n head_{{formid}}.recordid as " + "header{{formid}}recordid";

                            //        //selecting all fields in current form
                            //        foreach (ReportsSelectFields itemSelectFieldInForm in filteredCurrentFormList)
                            //        {
                            //            tablesSelectList = tablesSelectList + "\n,max(if(body_{{formid}}.fieldid = " + itemSelectFieldInForm.FieldID + " , body_{{formid}}.filedValue, NULL)) as `c_" + itemSelectFieldInForm.FieldID + "`";
                            //        }


                            //        tablesForCurrentFormWithHeader = "tbl_form_{{formid}}_metadata_header head_{{formid}} \n";

                            //        tablesForCurrentFormWithBody = "tbl_form_{{formid}}_metadata_body body_{{formid}} on body_{{formid}}.recordid = head_{{formid}}.recordid and body_{{formid}}.datastatus = 0 \n";

                            //        tablesForMasterFields = GetMasterDBName() + ".tbl_master_fields field on body_{{formid}}.fieldid = field.fieldid and field.datastatus = 0 \n";

                            //        totalResult = tablesForCurrentFormWithHeader + "\n inner join \n" + tablesForCurrentFormWithBody + "\n  inner join \n " + tablesForMasterFields + "where \n  head_{{formid}}.datastatus = 0 \n  group by head_{{formid}}.recordid";

                            //        totalResult = totalResult.Replace("{{formid}}", itemTableInvolvedInJoin.InvolvedTable1FormID.ToString());

                            //        tablesSelectList = tablesSelectList.Replace("{{formid}}", itemTableInvolvedInJoin.InvolvedTable1FormID.ToString());

                            //        totalResult = "(select \n" + tablesSelectList + "\n from \n" + totalResult + ") FORM_" + itemTableInvolvedInJoin.InvolvedTable1FormID;


                            //        string joinConditions = string.Empty;

                            //        //getting current join involvement condition fields details
                            //        var currentTableJOINLinkedConditions = ReportsFormTableColumnsFieldsInvolvedresult.ReportsFormTableColumnsFieldsInvolvedList.Where(
                            //            item => item.ReportsFormTablesInvolvedInfoID == itemTableInvolvedInJoin.ReportsFormTablesInvolvedInfoID).ToList();


                            //        if (currentTableJOINLinkedConditions != null && currentTableJOINLinkedConditions.Count > 0)
                            //        {
                            //            joinConditions += "1=1 and ";

                            //            int joinCount = 0;
                            //            int totalJoinsCondtions = currentTableJOINLinkedConditions.Count;

                            //            foreach (var item in currentTableJOINLinkedConditions)
                            //            {
                            //                joinCount++;

                            //                if (item.InvolvedTable1FormID > 0)
                            //                    joinConditions += " FORM_" + item.InvolvedTable1FormID + "." + GetColumnNameBasedOnFieldID(item.InvolvedTable1ColumnFieldID, item.InvolvedTable1FormID) + " = ";


                            //                if (!string.IsNullOrEmpty(item.InvolvedTable1ColumnFieldDefaultValue))
                            //                {
                            //                    joinConditions += item.InvolvedTable1ColumnFieldDefaultValue;
                            //                }
                            //                else
                            //                {
                            //                    if (item.InvolvedTable2FormID > 0)
                            //                        joinConditions += " FORM_" + item.InvolvedTable2FormID + "." + GetColumnNameBasedOnFieldID(item.InvolvedTable2ColumnFieldID, item.InvolvedTable1FormID);
                            //                }

                            //                if (joinCount < totalJoinsCondtions)
                            //                {
                            //                    if (item.InvolvmentJoinType > 0)
                            //                    {
                            //                        switch (item.ColumsInvoled_ConditionType)
                            //                        {
                            //                            case ReportsConditionType.AND:
                            //                                joinConditions += " AND ";
                            //                                break;
                            //                            case ReportsConditionType.OR:
                            //                                joinConditions += " OR ";
                            //                                break;
                            //                            default:
                            //                                break;
                            //                        }
                            //                    }
                            //                }
                            //            }
                            //        }

                            //        //when it is not last table relation
                            //        if (currentLoopIndex < totalLengthofRelations)
                            //        {
                            //            string joinstring = "";

                            //            if (itemTableInvolvedInJoin.InvolvmentJoinType > 0)
                            //            {
                            //                switch (itemTableInvolvedInJoin.InvolvmentJoinType)
                            //                {
                            //                    case InvolvmentJoinType.INNERJOIN:
                            //                        joinstring = "\n inner join \n";
                            //                        break;
                            //                    case InvolvmentJoinType.LEFTJOIN:
                            //                        joinstring = "\n left join \n";
                            //                        break;
                            //                    case InvolvmentJoinType.RIGHTJOIN:
                            //                        joinstring = "\n right join \n";
                            //                        break;
                            //                    default:
                            //                        break;
                            //                }

                            //            }

                            //            totalResult = totalResult + joinstring;
                            //        }


                            //        //append line
                            //        stringBuilderTablesJoin.AppendLine(totalResult);

                            //    }
                            //}

                            //totalStringFormedQuery = "select \n" + tablesSelectListFinal + "\n from \n" + stringBuilderTablesJoin.ToString();



                        }

                        //validation query
                        else if (reportInformation.ReportType == ReportType.VALIDATION)
                        {
                            foreach (ReportsFormTablesInvolved itemTableInvolvedInJoin in ReportsFormTablesInvolvedObjresult.ReportsFormTablesInvolvedList)
                            {
                                if (itemTableInvolvedInJoin.InvolvedTable1FormID != null && itemTableInvolvedInJoin.InvolvedTable1FormID > 0)
                                {
                                    tablesSelectList = string.Empty;

                                    tablesSelectList = "head_{{formid}}.recordid,body_{{formid}}.recorddataid,field.formid,body_{{formid}}.fieldid";

                                    //looping on all filter fields
                                    if (ReportsFilterFieldsresult != null && ReportsFilterFieldsresult.ReportsFilterFieldsList != null &&
                                        ReportsFilterFieldsresult.ReportsFilterFieldsList.Count > 0)
                                    {
                                        List<ReportsFilterFields> filteredCurrentFormSelectList = ReportsFilterFieldsresult.ReportsFilterFieldsList.Where(item =>
                                                        item.FormID == itemTableInvolvedInJoin.InvolvedTable1FormID
                                                        || (itemTableInvolvedInJoin.InvolvedTable2FormID != null && item.FormID == itemTableInvolvedInJoin.InvolvedTable2FormID)).ToList();

                                        int totalFiltersCnt = filteredCurrentFormSelectList.Count();

                                        if (filteredCurrentFormSelectList != null && totalFiltersCnt > 0)
                                        {
                                            int indexInLoopFilters = 0;

                                            //looping on all filter fields
                                            foreach (ReportsFilterFields itemFilterFieldInForm in filteredCurrentFormSelectList)
                                            {

                                                indexInLoopFilters++;

                                                if (itemFilterFieldInForm.FieldID == null || itemFilterFieldInForm.FieldID == 0) continue;

                                                tablesSelectList = tablesSelectList + "\n,max(if(body_{{formid}}.fieldid = " + itemFilterFieldInForm.FieldID + " , body_{{formid}}.filedValue, NULL)) as `cf_" + itemFilterFieldInForm.FieldID + "`";

                                                tablesWhereCondition = tablesWhereCondition + " `cf_" + itemFilterFieldInForm.FieldID + "`";

                                                string filterFieldValues = "";
                                                string filterFieldValues2 = "";


                                                if (itemFilterFieldInForm.DefaultFieldValue != null)
                                                {
                                                    string test = itemFilterFieldInForm.DefaultFieldValue.ToString();

                                                    if (!string.IsNullOrEmpty(test))
                                                    {
                                                        if (test.IndexOf("~^~") > 0)
                                                        {
                                                            filterFieldValues = test.Split("~^~")[0].ToString();
                                                            filterFieldValues2 = test.Split("~^~")[1].ToString();
                                                        }
                                                        else
                                                        {
                                                            filterFieldValues = test.ToString();
                                                            filterFieldValues2 = "{{value2_cf_" + itemFilterFieldInForm.FieldID + "}}";
                                                        }
                                                    }
                                                    else
                                                    {
                                                        filterFieldValues = "{{value1_cf_" + itemFilterFieldInForm.FieldID + "}}";
                                                        filterFieldValues2 = "{{value2_cf_" + itemFilterFieldInForm.FieldID + "}}";
                                                    }
                                                }
                                                else
                                                {
                                                    filterFieldValues = "{{value1_cf_" + itemFilterFieldInForm.FieldID + "}}";
                                                    filterFieldValues2 = "{{value2_cf_" + itemFilterFieldInForm.FieldID + "}}";
                                                }

                                                //applying the condition mode 
                                                switch (itemFilterFieldInForm.ConditionMode)
                                                {
                                                    case ReportsConditionMode.IN:
                                                        tablesWhereCondition = tablesWhereCondition + " in " + filterFieldValues;
                                                        break;
                                                    case ReportsConditionMode.NOTIN:
                                                        tablesWhereCondition = tablesWhereCondition + " not in (" + filterFieldValues + ")";
                                                        break;
                                                    case ReportsConditionMode.BETWEEN:
                                                        tablesWhereCondition = tablesWhereCondition + " between " + filterFieldValues + " and " + filterFieldValues2;
                                                        break;
                                                    case ReportsConditionMode.STARTSWITH:
                                                        tablesWhereCondition = tablesWhereCondition + " like '" + filterFieldValues + "%'";
                                                        break;
                                                    case ReportsConditionMode.CONTAINS:
                                                        tablesWhereCondition = tablesWhereCondition + " like '%" + filterFieldValues + "%'";
                                                        break;
                                                    case ReportsConditionMode.ENDSWITH:
                                                        tablesWhereCondition = tablesWhereCondition + " like '%" + filterFieldValues + "'";
                                                        break;
                                                    case ReportsConditionMode.LESSTHAN:
                                                        tablesWhereCondition = tablesWhereCondition + " < " + filterFieldValues;
                                                        break;
                                                    case ReportsConditionMode.GREATERTHAN:
                                                        tablesWhereCondition = tablesWhereCondition + " > " + filterFieldValues;
                                                        break;
                                                    case ReportsConditionMode.LESSTHANEQUAL:
                                                        tablesWhereCondition = tablesWhereCondition + " <= " + filterFieldValues;
                                                        break;
                                                    case ReportsConditionMode.GREATERTHANEQUAL:
                                                        tablesWhereCondition = tablesWhereCondition + " >= " + filterFieldValues;
                                                        break;
                                                    case ReportsConditionMode.EQUALS:
                                                        tablesWhereCondition = tablesWhereCondition + " = '" + filterFieldValues + "'";
                                                        break;
                                                    case ReportsConditionMode.NOTEQUALS:
                                                        tablesWhereCondition = tablesWhereCondition + " != '" + filterFieldValues + "'";
                                                        break;
                                                    case ReportsConditionMode.NOTNULL:
                                                        tablesWhereCondition = tablesWhereCondition + " IS NOT NULL";
                                                        break;
                                                    case ReportsConditionMode.ISNULL:
                                                        tablesWhereCondition = tablesWhereCondition + " IS NULL";
                                                        break;
                                                    default:
                                                        break;
                                                }

                                                //appending the condition mode only when it is not last field
                                                if (indexInLoopFilters < totalFiltersCnt)
                                                {
                                                    switch (itemFilterFieldInForm.ConditionType)
                                                    {
                                                        case ReportsConditionType.AND:
                                                            tablesWhereCondition = tablesWhereCondition + " and ";
                                                            break;
                                                        case ReportsConditionType.OR:
                                                            tablesWhereCondition = tablesWhereCondition + " or ";
                                                            break;
                                                        default:
                                                            break;
                                                    }
                                                }

                                            }
                                        }
                                    }


                                    string tablesForCurrentFormWithHeader = string.Empty;

                                    string tablesForCurrentFormWithBody = string.Empty;

                                    string tablesForMasterFields = string.Empty;

                                    string totalResult = string.Empty;

                                    tablesForCurrentFormWithHeader = "tbl_form_{{formid}}_metadata_header head_{{formid}} \n";

                                    tablesForCurrentFormWithBody = "tbl_form_{{formid}}_metadata_body body_{{formid}} on body_{{formid}}.recordid = head_{{formid}}.recordid and body_{{formid}}.datastatus = 0 \n";


                                    if ((itemTableInvolvedInJoin.InvolvmentJoinType == null || itemTableInvolvedInJoin.InvolvmentJoinType == 0)
                                        && itemTableInvolvedInJoin.InvolvedTable2FormID == null)
                                    {
                                        tablesForMasterFields = GetMasterDBName() + ".tbl_master_fields field on body_{{formid}}.fieldid = field.fieldid and field.datastatus = 0 \n";

                                        //totalResult = tablesForCurrentFormWithHeader + "\n inner join \n" + tablesForCurrentFormWithBody + "\n  inner join \n " + tablesForMasterFields + "where \n  head_{{formid}}.datastatus = 0 \n  group by head_{{formid}}.recordid";

                                        totalResult = tablesForCurrentFormWithHeader + "\n inner join \n" + tablesForCurrentFormWithBody + "\n  inner join \n " + tablesForMasterFields + "where \n  head_{{formid}}.datastatus = 0 \n  group by head_{{formid}}.recordid";
                                    }

                                    totalResult = totalResult.Replace("{{formid}}", itemTableInvolvedInJoin.InvolvedTable1FormID.ToString());

                                    tablesSelectList = tablesSelectList.Replace("{{formid}}", itemTableInvolvedInJoin.InvolvedTable1FormID.ToString());

                                    stringBuilderTablesJoin.AppendLine(totalResult);
                                }
                            }


                            totalStringFormedQuery = "select \n" + tablesSelectList + "\n from \n" + stringBuilderTablesJoin.ToString();
                        }




                        if (!string.IsNullOrEmpty(tablesWhereCondition) &&
                            commonsavingmodel.CommonSearchFilterFieldsData != null && commonsavingmodel.CommonSearchFilterFieldsData.Count() > 0)
                        {

                            foreach (var item in commonsavingmodel.CommonSearchFilterFieldsData)
                            {
                                string filterFieldValues = "{{value1_cf_" + item.FieldID + "}}";
                                string filterFieldValues2 = "{{value2_cf_" + item.FieldID + "}}";

                                if (reportInformation.ReportType == ReportType.RELATIONALLIST)
                                {
                                    filterFieldValues = "{{value1_c_" + item.FieldID + "}}";
                                    filterFieldValues2 = "{{value2_c_" + item.FieldID + "}}";
                                }


                                string fieldValueToReplace = string.Empty;
                                string fieldValue2ToReplace = string.Empty;

                                if (item.FieldValue != null)
                                {
                                    fieldValueToReplace = item.FieldValue.ToString();
                                }

                                if (item.FieldValue2 != null)
                                {
                                    fieldValue2ToReplace = item.FieldValue2.ToString();
                                }

                                tablesWhereCondition = tablesWhereCondition.Replace(filterFieldValues, fieldValueToReplace);
                                tablesWhereCondition = tablesWhereCondition.Replace(filterFieldValues2, fieldValue2ToReplace);
                            }
                            if (reportInformation.ReportType == ReportType.VALIDATION)
                            {
                                if (recordID > 0)
                                {
                                    totalStringFormedQuery = "select count(*) as Cnt \n from\n (" + totalStringFormedQuery + ")X  where (" + tablesWhereCondition + ") and recordid <> " + recordID + ";";
                                }
                                else
                                    totalStringFormedQuery = "select count(*) as Cnt \n from\n (" + totalStringFormedQuery + ")X  where " + tablesWhereCondition + ";";
                            }

                            else if (reportInformation.ReportType == ReportType.DIRECTLIST)
                            {

                                string tempsorting = "";

                                if (sortingdetails != null && sortingdetails.ToString().Length > 0)
                                {
                                    tempsorting = "\n\n" + "order by \n\n" + sortingdetails.ToString();
                                }

                                totalStringFormedQuery = "select * \n from\n (" + totalStringFormedQuery + ")X  where " + tablesWhereCondition + tempsorting + ";";
                            }


                            reportInformation.p_FilterQuery = tablesWhereCondition;

                        }
                        else
                        {
                            tablesWhereCondition = string.Empty;
                        }


                        if (tempTableDropping != null)
                        {
                            totalStringFormedQuery = totalStringFormedQuery + tempTableDropping.ToString();
                            reportInformation.p_DropQuery = tempTableDropping.ToString();
                        }

                        reportInformation.ReportQuerytoExec = totalStringFormedQuery;
                        reportInformation.orgmodel = commonsavingmodel.orgmodel;




                        if (reportInformation.ReportType == ReportType.RELATIONALLIST)
                        {
                            string tempsorting = "";

                            if (sortingdetails != null && sortingdetails.ToString().Length > 0)
                            {
                                tempsorting = "\n" + "order by " + sortingdetails.ToString();
                            }

                            if (!string.IsNullOrEmpty(tablesWhereCondition))
                            {
                                totalStringFormedQuery = tempTableDroppingIfExists.ToString() + tempTablesCreation.ToString() +
                                 "select \n" + stringBuilderFinal.ToString() + "\n from \n" + stringBuilderTablesJoin.ToString() + " where 1 = 1 and " + tablesWhereCondition + tempsorting + ";\n\n" + tempTableDropping.ToString();
                            }
                            else
                            {
                                totalStringFormedQuery = tempTableDroppingIfExists.ToString() + tempTablesCreation.ToString() +
                                "select \n" + stringBuilderFinal.ToString() + "\n from \n" + stringBuilderTablesJoin.ToString() + tempsorting + ";\n\n" + tempTableDropping.ToString();
                            }

                            reportInformation.ReportQuerytoExec = totalStringFormedQuery;

                            responseModel = await commonData.ExecuteReportAndGetDataByQuery(reportInformation);
                        }
                        else
                            responseModel = await commonData.ExecuteReportAndGetData(reportInformation);



                    }
                }
            }
            finally
            {
                //disposing the used objects
                ReportsSelectFieldsresult = null;
                ReportsAllFieldsresult = null;
                ReportsFilterFieldsresult = null;
                ReportsSortFieldsresult = null;
                ReportsFormTablesInvolvedObjresult = null;
                ReportsFormTablesInvolvedUniqueObjresult = null;
                ReportsFormTableColumnsFieldsInvolvedresult = null;
                recordID = 0;
                tempTableDropping = null;

                tempTableDroppingIfExists = null;
                stringBuilderFinal = null;
                tempTablesCreation = null;
                sortingdetails = null;

            }

            return responseModel;
        }




        public async Task<CommonSavingModel> GetTasksListInfo(CommonSavingModel commonsavingmodel)
        {
            CommonSavingModel responseModel = null;

            try
            {
                using (CommonDataAccess commonData = new CommonDataAccess())
                {
                    responseModel = await commonData.GetTasksListInfo(commonsavingmodel);
                }
            }
            finally
            {

            }

            return responseModel;
        }

        public async Task<ResponseModel> UpdateTaskStatus(CommonSavingModel commonsavingmodel)
        {
            ResponseModel responseModel = null;
            try
            {
                //CALLING THE SAVE RECORD META INFO IN DATA BASE
                using (CommonDataAccess commonData = new CommonDataAccess())
                {
                    responseModel = await commonData.UpdateTaskStatus(commonsavingmodel);
                    //saving the data in the data base
                }
            }
            finally
            {
            }
            return responseModel;
        }

        public async Task<ResponseModel> UpdateTaskResponsiblePerson(CommonSavingModel commonsavingmodel)
        {
            ResponseModel responseModel = null;
            try
            {
                //CALLING THE SAVE RECORD META INFO IN DATA BASE
                using (CommonDataAccess commonData = new CommonDataAccess())
                {
                    responseModel = await commonData.UpdateTaskResponsiblePerson(commonsavingmodel);
                    //saving the data in the data base
                }
            }
            finally
            {
            }
            return responseModel;
        }


        /// <summary>
        /// CALL DATA ACCESS TO UPDATE USER PASSWORD 
        /// </summary>
        /// ***** CREATED BY:   SANJAY IDPUGANTI *****
        /// ***** CREATED DATE: 4/30/2018        *****
        /// <param name="loginModel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> UpdateEmployeePassword(LoginModel loginModel)
        {
            ResponseModel responseModel = null;

            try
            {
                using (CommonDataAccess commonData = new CommonDataAccess())
                {
                    // updating in the central data base
                    responseModel = await commonData.UpdateEmployeePassword(loginModel);

                    // if updated successfully in main data base then updating it in the meta data base forms
                    if (responseModel != null && (responseModel.RequestExecutionStatus == null || responseModel.RequestExecutionStatus == 0))
                    {
                        using (CommonSavingModel model = new CommonSavingModel())
                        {
                            model.orgmodel = loginModel.orgmodel;
                            model.formid = 2018031716051198337;
                            model.RecordID = Convert.ToInt64(loginModel.orgmodel.loggedusergdsuid);
                            model.CommonSavingRowData = new CommonSavingRowsFieldsModel();

                            model.CommonSavingRowData.CommonSavingFieldsData = new List<CommonSavingFieldsModel>();


                            model.CommonSavingRowData.CommonSavingFieldsData.Add(new CommonSavingFieldsModel()
                            {
                                FieldID = 2018032014254536917,
                                FieldValue = loginModel.orgmodel.LoggedUserID,
                                FieldGroupID = 28,
                                FieldSeqNumber = 28
                            });

                            model.CommonSavingRowData.CommonSavingFieldsData.Add(new CommonSavingFieldsModel()
                            {
                                FieldID = 2018031716081182733,
                                FieldValue = loginModel.loggeduserpassword,
                                FieldGroupID = 8,
                                FieldSeqNumber = 8
                            });


                            //2018032014254536917  - Employee Login User ID
                            //2018031716080130631  - Employee Email ID (User name)
                            //2018031716081182733  - Employee Password

                            responseModel = await commonData.UpdateMetaDataFieldsMultiple(model);
                        }

                    }
                }
            }
            finally
            {

            }
            return responseModel;
        }

        public async Task<ResponseModel> UpdateMetaDataFieldsMultipleFields(CommonSavingModel commonsavingmodel)
        {
            ResponseModel responseModel = null;
            try
            {
                //CALLING THE SAVE RECORD META INFO IN DATA BASE
                using (CommonDataAccess commonData = new CommonDataAccess())
                {
                    responseModel = await commonData.UpdateMetaDataFieldsMultiple(commonsavingmodel);
                    //saving the data in the data base
                }
            }
            finally
            {
            }
            return responseModel;
        }




        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {

            }
        }
        #endregion
    }
}



