﻿using Google.Apis.Auth.OAuth2;
using Google.Apis.Storage.v1;
using Google.Cloud.Storage.V1;
using OAS_App_Common;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace OAS_App_BusinessFaccade.Common
{
    public class CommonCloudStorageBA : IDisposable
    {

        #region "                                 UPLOAD DATA TO GOOGLE CLOUD STORAGE  COMMON CLASSES                                         "

        public class GoogleStorageBucketInputInfo : IDisposable
        {

            public string BucketName { get; set; }

            public string FileNameWithFolderPath { get; set; }

            public string FileMIMEType { get; set; }

            public byte[] FileContentInBinary { get; set; }

            public string MethodName { get; set; }


            #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
            // Dispose() calls Dispose(true)
            public void Dispose()
            {
                Dispose(true);
                GC.SuppressFinalize(this);
            }


            // The bulk of the clean-up code is implemented in Dispose(bool)
            protected virtual void Dispose(bool disposing)
            {
                if (disposing)
                {

                }
            }
            #endregion
        }

        public class GoogleCloudCredentialsModel : IDisposable
        {
            /// <summary>
            /// THIS VARIABLE IS USED TO HOLD SERVICE ACCOUNT KEY TYPE.
            /// 1. UPLODER/CREATOR SERVICE SERVICE ACCOUNT KEY  
            /// 2. DOWNLOADER/VIEWER SERVICE SERVICE ACCOUNT KEY 
            /// </summary>
            public int GoogleServiceKeyNameID { get; set; }

            /// <summary>
            /// THIS VARIABLE IS USED TO HOLD SERVICE ACCOUNT KEY  TYPE DESC.
            /// 1. UPLODER/CREATOR SERVICE SERVICE ACCOUNT KEY  
            /// 2. DOWNLOADER/VIEWER SERVICE SERVICE ACCOUNT KEY 
            /// </summary>
            public string GoogleServiceKeyNameDesc { get; set; }

            /// <summary>
            /// THIS VARIABLE IS USED TO HOLD SERVICE ACCOUNT KEY  CREDENTIAL DETAILS.
            /// </summary>
            public string GoogleServiceKeyData { get; set; }

            /// <summary>
            ///  THIS VARIABLE IS USED TO HOLD SERVICE ACCOUNT KEY STATUS.
            /// 1. ACTIVE
            /// 2. INACTIVE
            /// </summary>
            public int GoogleServiceKeyStatus { get; set; }

            /// <summary>
            ///  THIS VARIABLE IS USED TO HOLD SERVICE ACCOUNT KEY STATUS DESC.
            /// 1. ACTIVE
            /// 2. INACTIVE
            /// </summary>
            public string GoogleServiceKeyStatusDesc { get; set; }


            /// <summary>
            /// THIS VARIABLE IS USED TO HOLD GOOGLE CLOUD CREDENTIAL
            /// </summary>
            public GoogleCredential GoogleCredential { get; set; }


            #region " ************ DISPOSING USED OBJECTS BLOCK********************* "

            // Dispose() calls Dispose(true)
            public void Dispose()
            {
                Dispose(true);
                GC.SuppressFinalize(this);
            }

            // The bulk of the clean-up code is implemented in Dispose(bool)
            protected virtual void Dispose(bool disposing)
            {
                if (disposing)
                {
                    GoogleServiceKeyNameID = 0;
                    GoogleServiceKeyNameDesc = string.Empty;
                    GoogleServiceKeyData = string.Empty;
                    GoogleServiceKeyStatus = 0;
                    GoogleServiceKeyStatusDesc = string.Empty;
                    GoogleCredential = null;
                }
            }

            #endregion
        }


        #endregion



        #region "                                 UPLOAD DATA TO GOOGLE CLOUD STORAGE                                           "


        /// <summary>
        /// THIS METHOD IS USEFUL IN UPLOADING THE GIVE FILE TO THE BUCKET IN CLOUD STORAGE
        /// </summary>
        /// <param name="storageClient"></param>
        /// <param name="input"></param>
        /// <param name="serializeMe"></param>
        /// <param name="RetryAttempt"></param>
        /// <returns></returns>
        public Google.Apis.Storage.v1.Data.Object UploadToGoogleCloudStorage(StorageClient storageClient,
            GoogleStorageBucketInputInfo input, object serializeMe, int RetryAttempt = 0)
        {
            Google.Apis.Storage.v1.Data.Object objResult = null;
            int retryTimeOutMilliSecs = 1000;//1 sec            
            try
            {
                //checking for valid data
                if (input == null)
                    return objResult;

                // WE TRYING MAX 3 RETRY ATTEMPTS TO UPLOAD FILE TO GOOLGE
                if (RetryAttempt > 3) return objResult;

                if (RetryAttempt == 0)
                {

                }

                //checking for valid data
                if (storageClient == null || string.IsNullOrEmpty(input.BucketName) || string.IsNullOrWhiteSpace(input.BucketName)
                    || string.IsNullOrEmpty(input.FileNameWithFolderPath) || string.IsNullOrWhiteSpace(input.FileNameWithFolderPath)
                    || string.IsNullOrWhiteSpace(input.FileMIMEType) || string.IsNullOrEmpty(input.FileMIMEType)
                    || input.FileContentInBinary == null || input.FileContentInBinary.Length <= 0)
                {
                    objResult = null;
                }
                else
                {

                    if (RetryAttempt > 0)
                    {
                        //if (ex.GetHttpCode() == 503)
                        retryTimeOutMilliSecs = 2 * 1000;

                        //trail - I
                        System.Threading.Thread.Sleep(retryTimeOutMilliSecs);

                    }

                    // when File Name is not found in Specified Bucket + Folder Path
                    try
                    {
                        // upload file to Bucket
                        objResult = storageClient.UploadObject(input.BucketName, input.FileNameWithFolderPath, input.FileMIMEType, new MemoryStream(input.FileContentInBinary));

                    }
                    catch (Exception exInsert)
                    {
                        // Google thrown error while uploading
                        if (isRetryException(exInsert))
                        {
                            UploadToGoogleCloudStorage(storageClient, input, serializeMe, RetryAttempt + 1);
                        }

                        if (RetryAttempt == 3)
                        {

                            throw exInsert;
                        }

                    }

                }

            }
            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {

            }
            return objResult;
        }



        private bool isRetryException(Exception exInput)
        {
            //https://cloud.google.com/storage/docs/xml-api/reference-status#standardcodes
            //301—Moved Permanently, 304—Not Modified, 307—Temporary Redirect, 308—Resume Incomplete, 400—Bad Request, 401—Unauthorized, 403—Forbidden, 404—Not Found ,
            // 405—Method Not Allowed, 409—Conflict, 411—Length Required, 412—Precondition Failed, 416—Requested Range Not Satisfiable, 429—Too Many Requests, 500—Internal Server Error,
            // 503—Service Unavailable

            //
            // Summary:
            //     Gets the HTTP response status code to return to the client.
            //
            // Returns:
            //     A non-zero HTTP code representing the exception or the System.Exception.InnerException
            //     code; otherwise, HTTP response status code 500.
            bool responsetoReturn = true;

            //if((exInput as HttpException).ErrorCode == 50)

            return responsetoReturn;
        }



        #endregion



        #region "          GENERATE GOOGLE SIGNED URL FOR USER SELECTED DOCUMENT          "
        /// <summary>
        /// ***********PURPOSE: THIS METHOD IS USED FOR GENERATE GOOGLE SIGNED URL FOR USER SELECTED DOCUMENT WHICH WILL WORK FOR LIFE TIME.
        /// ******************* MODIFIED DEVELOPER: DATE - NAME - WHAT IS MODIFIED; *************************  
        /// </summary>
        /// <param name="ehrclientauthrequestmodel"></param>
        /// <returns></returns>
        public string GenerateSignedURLFromGCloud(GoogleStorageBucketInputInfo inputInfo)
        {
            string GoogleSignedURL = string.Empty;

            try
            {
                // TRACK LOG FOR EXCEPTIONS


                if (string.IsNullOrEmpty(inputInfo.BucketName) || string.IsNullOrEmpty(inputInfo.FileNameWithFolderPath))
                {
                    // ERROR MAIL CODE GOES HERE

                    return GoogleSignedURL;
                }

                byte[] CredentialContent = Encoding.UTF8.GetBytes(GetGoogleCloudStorageCredentialsAssingedForViewingStrJSON());

                UrlSigner urlSigner = UrlSigner.FromServiceAccountData(new MemoryStream(CredentialContent));

                // GETTING SINGED URL WITH LIFE TIME PERIOD
                GoogleSignedURL = urlSigner.Sign(inputInfo.BucketName, inputInfo.FileNameWithFolderPath, null, null);

            }
            finally
            {

            }
            return GoogleSignedURL;

        }
        #endregion




        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING THE GOOGLE CLOUD STORAGE CREDENTIALS WITH IT'S SCOPE
        /// </summary>
        /// <param name="GoogleServiceKeyData"></param>
        /// <returns></returns>
        public GoogleCredential GetGoogleCloudStorageCredentialsAssingedForCreating()
        {
            GoogleCredential GoogleCredentialDocCreator = null;
            string GoogleServiceKeyData = string.Empty;
            string environment = "1";

            try
            {

                // 1- DEVELOPMENT ; 2 - QA ; 3- PRODUCTION ENVIRONMENT

                //for production
                if (environment != null && environment == "3")
                    GoogleServiceKeyData = "eyJ0eXBlIjoic2VydmljZV9hY2NvdW50IiwicHJvamVjdF9pZCI6ImNhbGNpdW0tZmllbGQtMTgyOTExIiwicHJpdmF0ZV9rZXlfaWQiOiI1NzBkNGM1N2Y2NTkzM2QzZThjYjRjNmI5Y2Y1NTNmNmQwODAwMTJmIiwicHJpdmF0ZV9rZXkiOiItLS0tLUJFR0lOIFBSSVZBVEUgS0VZLS0tLS1cbk1JSUV2Z0lCQURBTkJna3Foa2lHOXcwQkFRRUZBQVNDQktnd2dnU2tBZ0VBQW9JQkFRQzdicW4wL0trWXo0enpcbjN1bzlGQXFCL3BOcTlkamttUEJ5b0lwVk1vcGhWRTNsY3Z0WVl4bWNmbTAra1lpZVk0ZFh5dzFaeTJSSWZKcS9cbjBvZHJjUVdpNUJxOC9BbU51YVFzYThySTJLMjg3cW1wdnEvZDd3ZlJrMFRiL2dQa1RGdHV1aEprRWRKZ05kYUxcbnVxK012V1ZYK25HOHNjbnYrSHM0OTJvcmhCekV1cURBYWlDbXgwam05cnhLdU1VNDBIN2srSjZlZFpYT2pPL0lcbkg2d0xSKzdobWhZaFlRUlhXQ3BJT2NJOUlPMmZvenhVRnY2ZE9kVXM4U25wd0VxUjVZUW5lRzZwOGd2QjNKd2VcblJEejNiRmhqSmhhcTU5YU51QmNNaXFiWmdWU2NSV3dPVGoyMXdyTXRvSjZIV1g0UVY1SWVUdmVQRnY5ZXo1MzdcbkJycXJHcVFWQWdNQkFBRUNnZ0VBQXFhUm1vZFBmUWU2cThEendFeHlwcGd4NUhIUGpHUlp2THl2MXYxazg0WjlcbnAyRzR1QzByZGsya3NvSHV2VGVNVktBZlpZaW95Z00yaUp5NW56RFN2bWRoRVVmcXcvVGZHbEs0RWVmYi9FaXpcbjZaMjgvd3FIQmRDZG0yNjFoazh2SWtRMG1nVU1FdGkrN1BXWHFzRENnYTRkNjVYRHB3SDFNMHlsM2xZdFNMREpcbkxkRWdTank0UTI2THllYmpacmh0Z0puY3FzaG1PYWpKTEkyV0NUMzZmeUs4elR0aEhMT3ZWbXpJU0ovWWZyU1VcbjlrT2RjaCtkcVQrUkRqbitKbXFrS0d5bnJmTytvRUZyS3o0OVJlRjFiRk1aQ3lNT1VNWStIb2ZXaUZnd2hCM0RcbmdJRmlDUnFHNnI4dFU2aWtibEl5ZHd5MjF0YzdIMWNaNWh5TmFESDJZUUtCZ1FEeDNMOWU5RjdMYWVsc0N5TkNcbmRuY1RhcDlzOXIrQlVGSTU4aUw1bldEREZKclNVRnNaczVtNml3YzlmRE1aZTdianE2bGRLVnBYeUJteDgvZHhcbktpa0pFN3dESFJ0YXpvUW44eEpMaHdZa2RRTjN0ZEdrdlNHcjVEODBVYU8vTlNubS8rMzJ4Q0U0TXgvTFRjbUVcbkpHelBPbjJKM2RIVXpRT2ErdEU0VTdnSTRRS0JnUURHWTJ1RGlaWE1maWtBaVM5eC82Q0RRUDRvTnNwMzM4Sk9cbnl6WkZ5WGt4TWVEZWc1V05CVDV3dkJHNFNJRUIzbmxUbEtYY1pjeDRqR0srY1ErUWNPWW9rZWlRMURza1hqZTdcbnlwcm8wRTh4ZVgwYmNkNDBuN0VTcWdtcjZiRXI3R0hBOEpPdVRPNXpCVjR3ZTNBV25rdWlDb3dBWXNITU82ZklcbkVidC9NZmI5dFFLQmdRRGlHNUQ4NEUvT3N0RDVwTi90dm5wTHVKNGFiQU5ValJhUi9ZQWRBN2YyS0VrazNPS09cbkFJMXpDNDVWT01zOHc1K1M4R1NCSjZ2QjdOdTR0VzlhYUNPOHpLb3o3djRud25GaU42ZWUzRGd0MVFiTTN6bUNcblhSNGhhRngrT09Sd1dPODNlWU9wOG1scjlMK0FmTlFycVRIZiticHJMT2lCbkxnR0p2MTVQeXNKZ1FLQmdIM0xcbmhOei9YUEV4L2lYTTF6emQ3cFhMbkYwN2dON0tENWVPMjNjYzdhLzRCTEtUbFR5NldvRjVmM0x1NW42YzV5bk1cblUrK1F6VHFUS2ZuQUR6SnpwRDJOWjM2T1ZJSVhEQmdUdkc1cnlBdURFWVZaaXFDcnNjZzM4YklFbU1kVk9CYnpcbmRYRk1idGFZVE1WSlFDWFhjZlhwNGlSTWVyNWFCV1dqZU5TS2hpY1JBb0dCQUs5T1RxRFJpV3kvcGNiRkRhR2VcbmY5TElhSnBaQklORWJSMjZRbW8xNWZFdGdNYmoyS1RDVUxNb0VLSFJaczFMTE5iZllTQnE3cHpSYlVsMTBJQ1Bcbjc0ZG90K0FPdzJPbzVvU2tsV0lkNjY5VE53OFpFeUlFWTQra0EzaytTSlBZamthOTFrQldsdHN4ODJlbERObHdcbnovNHVBenNKOFBVQ0FpNk1HS1lGMFg2aFxuLS0tLS1FTkQgUFJJVkFURSBLRVktLS0tLVxuIiwiY2xpZW50X2VtYWlsIjoiZXl3YmluYXJ5c3RvcmFnZW9iamVjdGNyZWF0b3JAY2FsY2l1bS1maWVsZC0xODI5MTEuaWFtLmdzZXJ2aWNlYWNjb3VudC5jb20iLCJjbGllbnRfaWQiOiIxMDY1MDgwMDQ1NTg4Njg0ODc4NjEiLCJhdXRoX3VyaSI6Imh0dHBzOi8vYWNjb3VudHMuZ29vZ2xlLmNvbS9vL29hdXRoMi9hdXRoIiwidG9rZW5fdXJpIjoiaHR0cHM6Ly9hY2NvdW50cy5nb29nbGUuY29tL28vb2F1dGgyL3Rva2VuIiwiYXV0aF9wcm92aWRlcl94NTA5X2NlcnRfdXJsIjoiaHR0cHM6Ly93d3cuZ29vZ2xlYXBpcy5jb20vb2F1dGgyL3YxL2NlcnRzIiwiY2xpZW50X3g1MDlfY2VydF91cmwiOiJodHRwczovL3d3dy5nb29nbGVhcGlzLmNvbS9yb2JvdC92MS9tZXRhZGF0YS94NTA5L2V5d2JpbmFyeXN0b3JhZ2VvYmplY3RjcmVhdG9yJTQwY2FsY2l1bS1maWVsZC0xODI5MTEuaWFtLmdzZXJ2aWNlYWNjb3VudC5jb20ifQ==";
                else
                    GoogleServiceKeyData = "eyJ0eXBlIjoic2VydmljZV9hY2NvdW50IiwicHJvamVjdF9pZCI6ImVocnlvdXJ3YXktMTc4MzA3IiwicHJpdmF0ZV9rZXlfaWQiOiJiYzM4OTk1OTA0NmQ1M2M0YjAzOGRmMzZjMTY0ZTBkNmNkMzA4ZDE2IiwicHJpdmF0ZV9rZXkiOiItLS0tLUJFR0lOIFBSSVZBVEUgS0VZLS0tLS1cbk1JSUV2Z0lCQURBTkJna3Foa2lHOXcwQkFRRUZBQVNDQktnd2dnU2tBZ0VBQW9JQkFRQzNQd2xSM2p2SitvczNcbjFJV3VmRDcxakFKV1A2QTVtZ3NzR2ppYUpqZmlMN3RibmZ4dzZkdVZQcEo1WWgzd0s4QUVMdFU0SkpaVjFGUkVcbktEQU1GaHJhUVhhdlczL0Q3SzVjaGtnazVhd0tsRzY2QlYweFE0cm1UYVM4dkZmVU1hbllubjN6Um1TcTRsMHZcbk1NS1c4RnFVTlYrZndNcWJaSzdEbTNXY3JNcGl5d3VoTmNHcmNmc01NVjU4UDZCYUMzTHV0UWpJR2VqcHBjTE1cbmUzcm5BdnZmTGRMWlhya0JZMnRxZjNmNkhYbjlEaVNkbEhzdTBVQi9hSjRxUHJzUUhuTDl1UjhyVEd4Vk1idVRcbmFZSHo4WDh3Tk81RGF3ZU5BREdlWTVpMm9UdUxBUmZFUzE4Qlo0VUQrUm9QeHV3TENpSXAwSmUyV295cjRQU3Zcbk1FVXFlMjQxQWdNQkFBRUNnZ0VBQlA2d3hhcFZOWVgzd3BTNG1SODZQRUFrdGdWYW5BaDczTldqYkxHc05oTGpcbnloNXFwUnNpTkdORjdPaTkzaGtzNkh1MW0xNnpGUkdoSHRFek1CUUNVSlhFSjYzYy9TanhCK21LK2ZVUkpTSDNcbnR4OUpHQ0NqVEYzK3BxbzQ1YWY5NW5ZVThKam9FK3NWVUlYekRROEFPYU9oaFZKSm1tR0lPbXJQU1Z6VDlVd3JcblJ1WlV0Nlk5cmxYTDBpUll4TUFwRlNRTHAvR1YyTVdTMWg3bldDcUpTdXJtcHFhQTlIUFBzUE8yS2xUSE1pQ3Ncbmh3WjI3a29qa1R6bHVPd1R6SEFRRU5aK2xOOEordm9XMjdueVptbEx5MXZYRG9VcTY3ZzJJRXZERVV2enlCTUdcbk1LcGVSeVdNaVhSSGoxQlZkVzVSY2NjSWRpWDJnRjdZOTdVeXJQbFhVUUtCZ1FEN1p5RldKbExDa2xjNXVLcklcbkZKV3BKU1pyQzlUN0RKT2JuckQ5V0hXVGQvREhQTHJaZEhGQVZSdWJQUkE2d2NYUzFRdnpJWnlRQ1FFcXdYblZcbnNNR2EyN1diVWtvYkZpSmtRTUtzWFVla29MZmdGalJ3Q2tkUU1CZGVEaWEyck00VzBLS2ZhNFRJV2YvSFlBYzBcbkRYbUVNSVhJZ1NHN0tqWnpjSFY2UXZpSVpRS0JnUUM2bU5uR29SdTc0dkhGazdnTXBBTFFob3hyUGdOZ1hWeDdcbmZ4K1g1bExhV21mRUpCK2phTk5XUnkxV2tWSXBzV1VwdnpnNFdQYW9rL0M2VmVXWUpONHBZdENsNHZ0eklYVVVcbnVQR0hrdWpST29PL0hoa2l1a2U3ZFgxRHFhQ1hYRjNkaUlPNk5FczRxZXNYd1F3OW12NFFaNmxEd3M3MG5xazJcbmRRdFkxWVlwa1FLQmdRQzJuRzdHbVFlOGRYZ09ZV2tMOUlmUldUN1N1c0YxcWVqK1BRTHF3M3FFSjdjcHdaOG5cbm5VRTJMWnZqNHpNS3V2M3E2djNIR1Q4VUVMWmNURFVuVjBFS0wxVjNBUXI3S2RUSlpaRUNpcThqa2VwK1J5TEhcbnoyK0ZlNms5bEtIaVJ4dGJ6eWlSREJSalE1eGJRaEY1YWVBK2VOQjBsL2ZjY0FrbFNTYk1MQ0ZEVVFLQmdCLzNcbkxWOThtLzZzMnhRb3dSL1JQUFl5Qm40Y3FvRm9uUDQvQWMrSTBtcTdrQWttMHhDd1ZYdnpSNDRMNlJKaFpGNHBcbmR0MFlTSEVLbnZPYzRXOFY2Y1VYTzMwZmpFbmwwbVBSWnZiOXNNcWZCcERIL0RCWnp3NExDNEY2M3BydlpOa2Rcbm1NdGVTQUNXQTBNWGZCeFZuKzU1ZzZLckRiOFVLeEs4TEV4MGo3NHhBb0dCQUlyMGd6eUFaWmlGaHRtY0tKUWNcbjFMb3hZTVc5VFFrR3JrdDFseVc3TWwzcjdOeDVZSy9JTnZSbGtabE5qZzU4K24zcS9EUTcxQ1Fud2Y3Q3VhTGNcbjVkY1FjUUNPcHgwQksvaGl5S1hlb1hrK0xpaUY1VzVuYi94N1Q2YTNqL28xUHdCSm5oMys1dlZpVFJCVnBKTEdcbjlXK1ZuSllnVTdUcEV3a2VienFkdUY0dVxuLS0tLS1FTkQgUFJJVkFURSBLRVktLS0tLVxuIiwiY2xpZW50X2VtYWlsIjoiZ29vZ2xlLWNsb3VkLXN0b3JhZ2UtdXBsb2FkZXJAZWhyeW91cndheS0xNzgzMDcuaWFtLmdzZXJ2aWNlYWNjb3VudC5jb20iLCJjbGllbnRfaWQiOiIxMDE4MzA5MzI0MDU4MTI3MzQ5OTciLCJhdXRoX3VyaSI6Imh0dHBzOi8vYWNjb3VudHMuZ29vZ2xlLmNvbS9vL29hdXRoMi9hdXRoIiwidG9rZW5fdXJpIjoiaHR0cHM6Ly9hY2NvdW50cy5nb29nbGUuY29tL28vb2F1dGgyL3Rva2VuIiwiYXV0aF9wcm92aWRlcl94NTA5X2NlcnRfdXJsIjoiaHR0cHM6Ly93d3cuZ29vZ2xlYXBpcy5jb20vb2F1dGgyL3YxL2NlcnRzIiwiY2xpZW50X3g1MDlfY2VydF91cmwiOiJodHRwczovL3d3dy5nb29nbGVhcGlzLmNvbS9yb2JvdC92MS9tZXRhZGF0YS94NTA5L2dvb2dsZS1jbG91ZC1zdG9yYWdlLXVwbG9hZGVyJTQwZWhyeW91cndheS0xNzgzMDcuaWFtLmdzZXJ2aWNlYWNjb3VudC5jb20ifQ==";

                //getting the json original string from  base64 string
                GoogleServiceKeyData = System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(GoogleServiceKeyData));


                //creating the credentials instance with json string
                GoogleCredentialDocCreator = GoogleCredential.FromJson(GoogleServiceKeyData).CreateScoped(new string[] { StorageService.Scope.DevstorageReadWrite });

            }
            finally
            {
                //disposing
                GoogleServiceKeyData = string.Empty;
            }

            return GoogleCredentialDocCreator;
        }

        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING THE GOOGLE CLOUD STORAGE CREDENTIALS WITH IT'S SCOPE
        /// </summary>
        /// <param name="GoogleServiceKeyData"></param>
        /// <returns></returns>
        public GoogleCredential GetGoogleCloudStorageCredentialsAssingedForViewing()
        {
            GoogleCredential GoogleCredentialDocCreator = null;
            try
            {
                //creating the credentials instance with json string
                GoogleCredentialDocCreator = GoogleCredential.FromJson(GetGoogleCloudStorageCredentialsAssingedForViewingStrJSON()).CreateScoped(new string[] { StorageService.Scope.DevstorageReadOnly });
            }
            finally
            {

            }

            return GoogleCredentialDocCreator;
        }

        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING THE VIEW CREDENTIALS JSON
        /// </summary>
        /// <returns></returns>
        public string GetGoogleCloudStorageCredentialsAssingedForViewingStrJSON()
        {

            string GoogleServiceKeyData = string.Empty;
            string environment = "1";

            try
            {

                // 1- DEVELOPMENT ; 2 - QA ; 3- PRODUCTION ENVIRONMENT
                //for production
                if (environment != null && environment == "3")
                    GoogleServiceKeyData = "eyJ0eXBlIjoic2VydmljZV9hY2NvdW50IiwicHJvamVjdF9pZCI6ImNhbGNpdW0tZmllbGQtMTgyOTExIiwicHJpdmF0ZV9rZXlfaWQiOiI5YmFhNzk4NjdmZTQ2YTI1ODFjYjQzNWM5NGM2M2RkMDQxYjIxZmVjIiwicHJpdmF0ZV9rZXkiOiItLS0tLUJFR0lOIFBSSVZBVEUgS0VZLS0tLS1cbk1JSUV2UUlCQURBTkJna3Foa2lHOXcwQkFRRUZBQVNDQktjd2dnU2pBZ0VBQW9JQkFRQ29ETkp3bXNVRXp4eGpcbm53bkZIcTY5MG1ic1dBR1dBblNNaGZ4bjFQNzFNc280aHh2MlhWV0tGTE53MWxsYmpXVXVRYnZ5VjlsZzUvaGZcbmkvWW1uQzB4ZmRKZFVCZFpCOEJQcWhpei8zM3IvZHVCN1lUTXVhaXBHb1ExaWJYbFRNU2EyTllJemtlRjBTeExcbmJQSi9FdG1ZQUZmMEJid2liYjM3L3VYakZGTElrV1hWTXcrMDR6bnQ2NzJ3eXRHWENPV3pqODZtZXRBN2JvZVNcblZFaHNhVExCekpPTkZKejhBYm5WWmwycDBjdUJYcms5WDNsa0t6NXEvZjZNcVVZaUI5ekpiZk5YNGJVVmM1L2NcbmFtMUxxa1o1eW9abFFwWmlRdVhEOW1lMGNlN0tzQXV4S1g5cWlxQkVJVEFIcTBJTDZEdWZlem1nc3VzR1dkaXRcbkVPL2Rzd0l4QWdNQkFBRUNnZ0VBQkNZWFNlMWtndTl5K2dJL2NRQVhqWEI5WDRsKzhkeHhkT2FMSFhqOUlrSDJcbitpeWZOUkp0cnZaeU5GR2wzM0VmQ1A0Vk1WZExKZkh6RlF4QjFhQ25vdm1vbTVWWXRTWWxpa01GTmwvZjRYbDJcbmMyNTdzbWJlM011QXdxN1BHeXZ4dDAwVUpIVXRxbVEvMm5lbVppdmMzU3RoQUlCZE5mcnJBcFdkaEhJcWIwNnZcbkwxZm9kMzFQMmFseC9UZFpHM1c5VFBjcC9BNkpBcGlwWmpFYmsrVmxwdkViUkR0VDNmV25XRVEzWnZEZS9LTTZcblh5S09NVFNMaTBveW9nWE95K3Fkb3FKVXpJYkNIajdZTmRGMFJ5K09DOWRIb1MzYTRqV09Jdm1STWdUdjlqeDdcbjhpWkhTb0VZMEJia09sdXNycDVkbGN6WG8zNnhkVjNHQWxVR3hsT09nd0tCZ1FEcHl6RDNQcStIcVlRTHNrQ1JcblFoaG5wRkM4bWlmeWN0WE9qajhHaVk2TUJtZDlia3ZTVlVTbjdIR3RJTTkvQTRteXdrNWgvcXF6N1V3bzdqcVBcbldwNTYyRUx3eHNoT203cks3VERhdWJ1WkFUeW1WdC9qMWw1K0wwOEhSMVFXeXFobmRreXVsZUlaWmZvN0RmellcbitPTG9CanYxdmtGVWRxMFdFMDRFOU92TVF3S0JnUUM0QXdyTkwwdC9WWUVpZ2ZoaHJHY3orb2V0TUNSdTI5bjlcbms0QTBqdEN1VGdReHhZbHJDS041V1JBcTJwUEw2YU5KL0JFei83b2NVZUwxak9VWDlneDBnODNaSTkwRlFIK2dcbkQraXR5STBUUGFTL21HUHI4ZW5vcDR1S0VwK2R2eGtvMzZ5MFJOTWZnMkpSenIvb3FxamtWTFNxZmVIckVHdmRcbnV0RzBnNm5LZXdLQmdCamVOeUFsZDlCTFZMTlZ5NDVuNUdhcDBMaXZBUTdGN2o0aFhVelp0dUxvRDN3RkRtV2FcbkVrcDJXUVVjVjFYZ1QzWkhPc1VycklhaytCUG1leTRpYW5jUXA5WXFuc1hWeE1HdkJ5Sk0zVXFDR2l4clV6ZE5cbjV4RXZBUTM2SlZTalM5UnRmZXlZSHN1cTBEb1YyODVNY3Y1UkkzR1pRaU8wMStaZ09VMUhyQWszQW9HQkFLbHJcbmc2SnZEUi9yNWIyVDFOQjVIM3dvQ290V2EvVDF6cnM5OXloczVZM1dudDRFZGdWcUtya3JXMHRaZkFLZTFvempcbjNDTDRMSzZ1Wmp5V3dNZFM3eHpIemR0Q3ZkaDhEZ1dkSUNvQklJSzZtdGtjd2NNWE5MblVxUkV6SEdyczY0bEtcbmg0UmlhYy8xODZ4R28wTGcvaWRjSmd0alk0STkyRktLRTFJVWQxdkpBb0dBVk1WeVNleWVMT1p1c3M0c2ZZUWtcbmhOQUMwVmhramxjL3dFT2xCZ0hTOHRIRFpGRkZ5YnJScTZuZHlvRXJLd2pyaFZEZllpRDJPbWNwM1IwSmM2L1pcbjZGcWxsMGViTHowT29kd09pRWYveHJ1akhBaWlTU091SXVEbFZmeWpCY2RVeERlUytLZ0lrOG5JMVBlMFNPYmVcblhUOU1LbzFkUHREaCtNc2tEdjc2NkN3PVxuLS0tLS1FTkQgUFJJVkFURSBLRVktLS0tLVxuIiwiY2xpZW50X2VtYWlsIjoiZXl3YmluYXJ5c3RvcmFnZW9iamVjdHZpZXdlckBjYWxjaXVtLWZpZWxkLTE4MjkxMS5pYW0uZ3NlcnZpY2VhY2NvdW50LmNvbSIsImNsaWVudF9pZCI6IjExNTU1NjU5NzI1NTQ0MTcwOTI5MSIsImF1dGhfdXJpIjoiaHR0cHM6Ly9hY2NvdW50cy5nb29nbGUuY29tL28vb2F1dGgyL2F1dGgiLCJ0b2tlbl91cmkiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20vby9vYXV0aDIvdG9rZW4iLCJhdXRoX3Byb3ZpZGVyX3g1MDlfY2VydF91cmwiOiJodHRwczovL3d3dy5nb29nbGVhcGlzLmNvbS9vYXV0aDIvdjEvY2VydHMiLCJjbGllbnRfeDUwOV9jZXJ0X3VybCI6Imh0dHBzOi8vd3d3Lmdvb2dsZWFwaXMuY29tL3JvYm90L3YxL21ldGFkYXRhL3g1MDkvZXl3YmluYXJ5c3RvcmFnZW9iamVjdHZpZXdlciU0MGNhbGNpdW0tZmllbGQtMTgyOTExLmlhbS5nc2VydmljZWFjY291bnQuY29tIn0=";
                else
                    GoogleServiceKeyData = "eyJ0eXBlIjoic2VydmljZV9hY2NvdW50IiwicHJvamVjdF9pZCI6ImVocnlvdXJ3YXktMTc4MzA3IiwicHJpdmF0ZV9rZXlfaWQiOiI4MTY0YTJmMzIwMDk3NDA4YWYxZjMwYjJmYzg2MTJjNDFmZGFmYjc0IiwicHJpdmF0ZV9rZXkiOiItLS0tLUJFR0lOIFBSSVZBVEUgS0VZLS0tLS1cbk1JSUV2Z0lCQURBTkJna3Foa2lHOXcwQkFRRUZBQVNDQktnd2dnU2tBZ0VBQW9JQkFRQ3VZRS9nOEE0L2xRY0NcbnNPdTB1NFMwSnhSMWM3ZG5LWG10aU9aa0Uzak5hay8rN1RacHVxQ2ZHTjdjVEVlT1gwV1diVDhUK3d0Yit6QWxcbjA1S1hyRFV3S1V5VytjUVgxTlo1OUZ2eTZYc2Fpc0F3L2hBVVl1YTlVU0FPM00yT3BTWFFUNU9CMVBRd1d0czNcbmx0Q055UTMzZ0gyMng2OVVnWHhKUFU4aWhnOTFTampnMld6RzA2Y0l0U3Y0cjdoYTlZMlFuNUYzNkFTMWhHV0FcbmJaTDdMMzI5S2xDcGFDS0h1UWRuU243dmNQOTdhUDcvWmt6MFlqZVY1NWxnNzBoWXNWVDdKZEx5RnNRam9CQ3NcbkZqTHNuUHVJNStIekQ5dFdJekxOVXJ3Y0EvZkpDL1lUQVhwTDNTMHJVNEpGUkRIT0U0ck1FY3pTOS92NTJMdmdcblRFcEJORThQQWdNQkFBRUNnZ0VBREgxTmUxajJURXVLUXdFVkFNN2xoRm5BTjJGZ1kzMHUvK1RzUzRLeGhsVDFcbkFkZFByR2IzbGkyYjJMK0Y2SWFlWDFYWHpNQ1FZYmd1REtlSXVtQlZOdXZlVm5ueE41dkErTjh0cnNwV1RPSmZcblBhTVUxOEQxc2QyYnBEVGdiRFViN2oyazNRbTVxN1QyT3BjTXZQc0hpeENpOEhLQTlsYUg1bDhEeWY4OElEUmdcbmE3NGlJWXQ2Qk9ubWZHc21peWJrcEIySmpBZnRoNGprMHBMNUd2Z01rVXlvdE8vNTBlelIrSWFUL01qRTgxWFdcbkltQkZFaU1kcGw5aEMwTWUzMVFmUStlSnJOQmtmbXdkZWFKUnZkUGoxVk5WUkVGQmxkY2FINVcyczdtM2NwVDJcbjc5TnpEWVVqNjN4d1FEdDRyaHpiV1RmdGFLWE83eXJrZndLT3Q5ay9RUUtCZ1FEZXFvV0cyNHoyanljSVA0QUtcbnZ3TUQxL2xsbHJwMkVRbjdlSHFJNnF3c3BwTHVKSHNaanJmQ001Tk9kc0pYMS9FdldMZmVJdUNoN1BmeUhaUFRcbis1RFhGMXNxMEtXQktJTFhZNUJ0RTh0bHlvZDNLZlk1Q1NDK3NzcHJOcmRlaU1GZXhnT05WcS8ybUtRcDh5dW9cbktMMXFSZy94UkVFSEhSZGZ4Y3RrSjBEbGtRS0JnUURJZXgvRVYyUXAycjd0MHA3aDh1bEhJVm9PSUNTakVhTzdcbitjZmM2Ukxpb1dDZzdyRWNnS2pzeHd2cHQxdjllYVl5ZGpyWDFmZlZmemFWanRRVnFXenIxaDBJR1FvNUhxTzRcbkp0UlhXSFQvbHUvUnFvZlBFaTR4MjM3cmZIUjB6YjFkVnEyMUR1aHF5VFArdTdJczJHaXpBZlRYN1RkNFdxTkZcbjkyN09vTVVhbndLQmdRQ1hWTE50WlRmWHRwRWpsT3l6NFAvdWs5Rm5UdHFwTllsZ1JKQ2JEMHMzQ1hyZ3FTQ1VcbnpSOXN1RnJNUUFCemJVcjVEOFhmRGpzM01mT050TFpzb3hQY2EzNUZpZ3FCem9PbVdYK2w4b2NSUm1WdEFyTGFcbkxxNzNqRkh3TGY3UUhBZTRIc0g1UkVwUlFZcUpERURHaC9HOEVhUHlLSjQ5ZEhNWFh6bU5kdlF2VVFLQmdRQzFcbjB1VVd2Mk82aWdmTHpkQUhnTFdOcTNQdmg3dHlvZGJyN3pnUzVOZ1o3dDZpVnBrUERxa21SY2hLS2VBbVhhUWJcbjlCcWVFaEw1OEt4aXErMHgwRDFYRHhPNWVteEpMYjZ5ajVUWnV3SXhwSVRRbFdjaXFJeDQ3MmVHejVNWE5GbGdcblEvSzdXVS8xT1pJTW45S1MxWnJ2YndET3JQZzRFWXd2TXArdWl5VDRaUUtCZ0JDQzFGTjU1RnRjR2M2SFBYUEpcbnI4NWxtM3p2T2tFUU5rSkhBNjY3OVNETFRVSDRyNGlKY2xTZ3ZkUlBwa3VwelhoT0lxSnZWQkwzNXRpZHBId2NcblE0NHRSbWpXV29vUDIydklMcG1ldzJ2WG9DYmR6QlMzMDBLNjgxbkVGM1dvby96Q0hmdjBJMFp2elFuVU8yaGZcbkNZTzZBS2dJUE9rQ1NVRnJEeXcyUGxNRFxuLS0tLS1FTkQgUFJJVkFURSBLRVktLS0tLVxuIiwiY2xpZW50X2VtYWlsIjoiZ29vZ2xlLWNsb3VkLXN0b3JhZ2Utdmlld2VyQGVocnlvdXJ3YXktMTc4MzA3LmlhbS5nc2VydmljZWFjY291bnQuY29tIiwiY2xpZW50X2lkIjoiMTAxOTAxMjA0MTE3OTU5NTI3MDAzIiwiYXV0aF91cmkiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20vby9vYXV0aDIvYXV0aCIsInRva2VuX3VyaSI6Imh0dHBzOi8vYWNjb3VudHMuZ29vZ2xlLmNvbS9vL29hdXRoMi90b2tlbiIsImF1dGhfcHJvdmlkZXJfeDUwOV9jZXJ0X3VybCI6Imh0dHBzOi8vd3d3Lmdvb2dsZWFwaXMuY29tL29hdXRoMi92MS9jZXJ0cyIsImNsaWVudF94NTA5X2NlcnRfdXJsIjoiaHR0cHM6Ly93d3cuZ29vZ2xlYXBpcy5jb20vcm9ib3QvdjEvbWV0YWRhdGEveDUwOS9nb29nbGUtY2xvdWQtc3RvcmFnZS12aWV3ZXIlNDBlaHJ5b3Vyd2F5LTE3ODMwNy5pYW0uZ3NlcnZpY2VhY2NvdW50LmNvbSJ9";

                //getting the json original string from  base64 string
                GoogleServiceKeyData = System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(GoogleServiceKeyData));

            }
            finally
            {
                //disposing
                //GoogleServiceKeyData = string.Empty;
            }

            return GoogleServiceKeyData;
        }


        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING THE FOLDER PATH BASED ON MODULE TYPE
        /// </summary>
        /// <param name="moduleTypes"></param>
        /// <returns></returns>
        internal string GetFolderPath(ModuleTypes moduleTypes, BaseModel baseModel)
        {
            string bucketNameWithFolder = string.Empty;

            bucketNameWithFolder = "OAS";

            if (baseModel.orgmodel != null && baseModel.orgmodel.OrganizationID > 0)
                bucketNameWithFolder = bucketNameWithFolder + "/OAS_" + baseModel.orgmodel.OrganizationID;

            switch (moduleTypes)
            {
                case ModuleTypes.HTMLBINARY:
                    bucketNameWithFolder = bucketNameWithFolder + "/HTMLBINARY/";
                    break;
                default:
                    break;
            }
            return bucketNameWithFolder;
        }

        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING THE MIME TYPE BASED ON FILE TYPE
        /// </summary>
        /// <param name="fileTypes"></param>
        /// <returns></returns>
        internal string GetMimeTypeBasedOnFileType(FileTypes fileTypes)
        {
            string mime = string.Empty;

            switch (fileTypes)
            {
                case FileTypes.HTML:
                    mime = "text/html";
                    break;
                case FileTypes.PDF:
                    mime = "application/pdf";
                    break;
                default:
                    break;
            }

            return mime;
        }


        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING THE BUCKET NAME
        /// </summary>
        /// <returns></returns>
        internal string GetBucketName(BaseModel baseModel)
        {
            string bucketName = string.Empty;


            if (baseModel != null && baseModel.orgmodel != null && baseModel.orgmodel.OrganizationID > 0)
            {
                if (baseModel.orgmodel.OrganizationID == 1)
                    bucketName = "testehrcommon";
            }


            return bucketName;
        }


        public enum ModuleTypes
        {
            HTMLBINARY = 1
        }

        public enum FileTypes
        {
            HTML = 1,
            PDF = 2
        }

        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {

            }
        }
        #endregion
    }
}
