﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OAS_App_BusinessFaccade.Common
{
    public class EmployeeAuthorizationBA : IDisposable
    {













        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {

            }
        }
        #endregion
    }
}
