﻿using Google.Cloud.Datastore.V1;
using Google.Protobuf;

using Newtonsoft.Json;
using OAS_App_Common;
using OAS_App_Common.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace OAS_App_BusinessFaccade.Common
{

    public enum OASDataStoreKind
    {
        OrganizationsInfo = 1,
        UsersLoginsInfo = 2,
        EmployeesInfo = 3,
        DepartmentsInfo = 4,
        DesignationsInfo = 5,
        EmployeeWorkExperianceInfo = 6,
        EmployeeEducationInfo = 7,
        EmployeeDependentsInfo = 8,
        OASFormsInfo = 9,
        OASFieldsInformation = 10,
        DynamicForm = 11,
        ClientSessionsIPInfo = 12,
        DateIDs = 13,
        TimeIDs = 14,
    }

    public enum OASDataStatus
    {
        ActiveData = 0,
        InactiveData = 1
    }

    public class CommonBusinessAccess : IDisposable
    {




        public DatastoreDb BuildRequiredPropertiesForGoogleDataStore()
        {
            DatastoreDb datastoredb = null;
            string projectId = string.Empty;
            string credentialPath = string.Empty;
            string ServiceKeyCredential = string.Empty;
            string EnvironmentVariableValue = string.Empty;
            int intApplicationEnvironment = 0;
            try
            {

                //emrwebexceptiontracelogmodel.AddToExecutionLog("EHRGoogleDataStore.BusinessAccess", "CommonBusinessAccess", "BuildRequiredPropertiesForGoogleDataStore", "BuildRequiredPropertiesForGoogleDataStore Start", ExecutionLogType.Detail);


                // Your Google Cloud Platform project ID

                //ServiceKeyCredential = "{\"type\": \"service_account\",  " +
                //    "\"project_id\": \"g-calendar-176310\",  " +
                //    "\"private_key_id\": \"5ef8b24054f55b80c1061ba17b636cf19c06da33\",  " +
                //    "\"private_key\": \"-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCYsbdkYuZPM6ot\narlRldpvtohrq6Gr5MvmgesxNGdGspH24IH0ny6y7g9ALH++CQU0/APbVNa4sBqs\nQV/x/j6XB6SF4LqOyfybJfFWCY6rTGyPkfWUE1GvIlEIdlJG+oUISf4tEaoTvn8n\nwpxitbqDoUnCnDyX/x6TAkq1J2AlqHYqgyN2gR7ZP98HBnAnzfb+dOseL+XeCX5t\nYFPNR2FRmHiXMsCx57mnfLpmSiEUE9R9P5CbTkmxsE5wZHYuPlIE4F1A1+K61FIR\nX/L6wUfcu0OZVY6iC+b5EU+OoP/mcNFTyb8dDNvWSqQPpmNAcip8WZFf2BMj0nrA\nj1mI919tAgMBAAECggEAQDbUwjHZW0uF8M2mG8pib4KbAnTOa8Svf0P5zdqU6CVm\nvyURYfejovn8jedo3VlbyDmHwbB/EHJ29SQVHmbmmYtMREULD8ugIPsm8CDaz+02\n5nXiiiBJxNYwr9daqKDoW2EKtJduKBl/zg/IxrZYNs0YgPBFh0Jx8C8Rjfd+Nrdo\nibVNZT6EEAblUg8rlte7MgR6PqWdGLqaCR393dBhuReAmnIR+XqJlEpkyR+MeWKt\n/4As8VlGU2Exrsaha3lf2EBnSZO1qYebmQj+6QGVdVMCN3T4pRzNFMJCd1hVyd6e\nDLWUF22fRTn9GqqHAd0QtawBEQ8BjaCX5g0zWIr6/QKBgQDKvTOuufv3APpMK+Kp\nUgfx0M8nin89/QRtgboW1uah9jT1wdGvSkxdEZCwGUk+uA2hDPOsCnXBTcWAhzet\n9SXdq3OgtgceWBtsaIBA6pnxBkIBmYkpSwZjoUafv1h3MGlQj7NgdPcjCxF7btsB\n4rt7Ls91ZfTVKsVevZRn2+GujwKBgQDAztmq8F6KYZ77PY5WZdXBK5tqBoQCJo5j\np9o51+GqrSmXRMduuJakf6rE8rm89vIKlhI1C7F/DJ6CFHTUwvKoG7WxS0hC5IH9\n3mg6QDnuMc2S3EcKQ/narWjsX9LF+dv/GHxsmTnWmhzVxMpvmghJwRmn7zlLUuW7\nCwqvMQZQQwKBgB9cqVQMHTgWhKGn4EZFFEmJ/aGmQQy7ySWPfdPupnrDdWnW87Lk\nEXAMOY+kObpkCmexczhX3eNrPnQldq2IULU7woVH404EXymj+MMSB4JLb4aD0735\nhyF+X0hy9yJo8MGvmRYAwgI/whKQEXz3L/1cPmdwwDEBjsqbFQwD7aNtAoGAEQNv\ns6TIQt/AXp0c7UTJKuWFLkLq7SGn2OVb3VTOZfgnvmBkVMHXESbu07gzaZhE3WhG\nrQWeIP7lEcdqU8fsD6d6Te29r6FoUxWIDvPR6NHeOQJVBnPfHUvGAW2nNK8KmaT4\nfcC7mNM6jiZyUoy+BHwUnnv+i0YCXZHo3HKwAu8CgYA45zEz/b4lISVrVcR4+CdG\nSA7s6Knmbh35IQzQuvKQ+OTcwI2vgGVslATFTPa0n9FNWUA3U4LNFiX3PjNqaQf2\n0WKXlrBapTODBvW1+J8gkX8VRp/UWkCNavjnLwvT6FzAc3bvZ+AZCff+2B7xZyD9\nTK21pmiAiN24g5Yb0gyUBw==\n-----END PRIVATE KEY-----\n\",  " +
                //    "\"client_email\": \"googledatastore@g-calendar-176310.iam.gserviceaccount.com\",  " +
                //    "\"client_id\": \"113209085559089310265\",  " +
                //    "\"auth_uri\": \"https://accounts.google.com/o/oauth2/auth\",  " +
                //    "\"token_uri\": \"https://accounts.google.com/o/oauth2/token\",  " +
                //    "\"auth_provider_x509_cert_url\": \"https://www.googleapis.com/oauth2/v1/certs\",  " +
                //    "\"client_x509_cert_url\": \"https://www.googleapis.com/robot/v1/metadata/x509/googledatastore%40g-calendar-176310.iam.gserviceaccount.com\"}\"";

                // credentialPath = @"C:\web\2017\EHRGoogleCloudDataStore\EHRGoogleDataStore\Credentials\GoogleSampleProject-5ef8b24054f5.json";

                //intApplicationEnvironment = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["Environment"]); // 1- DEVELOPMENT ; 2 - QA ; 3- PRODUCTION ENVIRONMENT


                intApplicationEnvironment = 2;

                //// --------------------------------------------------------- TESTING ACCOUNT ---------------------------------------------------------
                //projectId = "g-calendar-176310"; // alexanderjoel516@gmail.com projectid
                //credentialPath = Environment.CurrentDirectory + @"\Credentials\GoogleSampleProject-5ef8b24054f5.json";
                //// --------------------------------------------------------- TESTING ACCOUNT ---------------------------------------------------------

                if (intApplicationEnvironment == 3)
                {

                    //// --------------------------------------------------------- PRODUCTION ACCOUNT ---------------------------------------------------------
                    projectId = "calcium-field-182911"; // alexanderjoel516@gmail.com projectid

                    //credentialPath = HostingEnvironment.ApplicationPhysicalPath + @"Credentials\EHRYOURWAYProduction-01e251c10f90.json";

                    //credentialPath = HostingEnvironment.MapPath("~") + @"\Credentials\EHRYOURWAYProduction-01e251c10f90.json";

                    credentialPath = Environment.CurrentDirectory + @"\Credentials\EHRYOURWAYProduction-01e251c10f90.json";

                    //// --------------------------------------------------------- PRODUCTION ACCOUNT ---------------------------------------------------------
                }
                else
                {
                    // --------------------------------------------------------- DEVELOPMENT ACCOUNT ---------------------------------------------------------
                    projectId = "ehryourway-178307"; // mohan@ehryourway.com

                    //credentialPath = HostingEnvironment.ApplicationPhysicalPath + @"Credentials\EHRYOURWAY-2ba72f3e011a.json";

                    //credentialPath = HostingEnvironment.MapPath("~") + @"\Credentials\EHRYOURWAY-2ba72f3e011a.json";

                    credentialPath = Environment.CurrentDirectory + @"\Credentials\EHRYOURWAY-2ba72f3e011a.json";
                    // --------------------------------------------------------- DEVELOPMENT ACCOUNT ---------------------------------------------------------
                }

                EnvironmentVariableValue = Environment.GetEnvironmentVariable("GOOGLE_APPLICATION_CREDENTIALS");

                if (EnvironmentVariableValue == null || EnvironmentVariableValue != credentialPath)
                {
                    System.Environment.SetEnvironmentVariable("GOOGLE_APPLICATION_CREDENTIALS", credentialPath);
                }

                //var credential = GoogleCredential.FromJson(ServiceKeyCredential);//.CreateScoped(new string[] { DatastoreClient.DefaultScopes });

                //DatastoreSettings datastoreSettings = new DatastoreSettings();


                //DatastoreClient dsClinent = DatastoreClient.Create(new Grpc.Core.Channel("", Grpc.Core.ChannelCredentials.Create((Grpc.Core.ChannelCredentials)credential)) { }, null); //DatastoreClientImpl.Create(new ServiceAccountCredential() { },null);

                //DatastoreClient dsClinent = DatastoreClient.Create();

                datastoredb = DatastoreDb.Create(projectId, "adaptamedehrauditlogaction");

                //datastoredb = DatastoreDb.Create(projectId, "oaskjsystems");

                //emrwebexceptiontracelogmodel.AddToExecutionLog("EHRGoogleDataStore.BusinessAccess", "CommonBusinessAccess", "BuildRequiredPropertiesForGoogleDataStore", "BuildRequiredPropertiesForGoogleDataStore End", ExecutionLogType.Detail);


            }
            catch (Exception ex)
            {
                //using (CommonBusinessAccess commonbusiness = new CommonBusinessAccess())
                //{
                //    commonbusiness.SendFailureInfoEmailToTechnicalTeam(null, this.GetType().Name, "ActionAuditLogInsert", ex.Message, null, emrwebexceptiontracelogmodel);
                //}
                throw ex;
            }
            finally
            {


            }

            return datastoredb;
        }


        #region "           GET KIND NAME BASED ON PRACTICE ID AND MODULE TYPE          "

        /// <summary>
        /// METHOD USED TO GET THE KIND NAME (TABLE NAME) TO SAVE ENTITIES (ROWS) IN GOOGLE DATA STORE BASED ON LOGGED PRACTICE ID & MODULE TYPE
        /// </summary>
        /// <param name="ehrcommondatastoremodel"></param>
        /// <returns></returns>
        public string GetKindNameBasedOnPracticeID(OASDataStoreKind kindType, int OrganizationID, Int64 FormID = 0)
        {
            string kindName = string.Empty;

            try
            {
                switch (kindType)
                {

                    case OASDataStoreKind.OrganizationsInfo:
                        kindName = "tbl_OAS_organizations_info";
                        break;

                    case OASDataStoreKind.UsersLoginsInfo:
                        kindName = "tbl_OAS_employees_logins_info";
                        break;
                    case OASDataStoreKind.EmployeesInfo:
                        kindName = "tbl_OAS_" + OrganizationID + "_employees_info";

                        break;
                    case OASDataStoreKind.DepartmentsInfo:
                        kindName = "tbl_OAS_" + OrganizationID + "_Departments_info";
                        break;
                    case OASDataStoreKind.DesignationsInfo:
                        kindName = "tbl_OAS_" + OrganizationID + "_Designations_info";
                        break;
                    case OASDataStoreKind.EmployeeWorkExperianceInfo:
                        kindName = "tbl_OAS_" + OrganizationID + "_Employee_Work_Experience_info";
                        break;
                    case OASDataStoreKind.EmployeeEducationInfo:
                        kindName = "tbl_OAS_" + OrganizationID + "_Employee_Education_info";
                        break;
                    case OASDataStoreKind.EmployeeDependentsInfo:
                        kindName = "tbl_OAS_" + OrganizationID + "_Employee_Dependents_info";
                        break;
                    case OASDataStoreKind.OASFormsInfo:
                        kindName = "tbl_OAS_FormsInfromation";
                        break;
                    case OASDataStoreKind.OASFieldsInformation:
                        kindName = "tbl_OAS_FieldsInformation";
                        break;

                    case OASDataStoreKind.ClientSessionsIPInfo:
                        kindName = "tbl_OAS_Client_Sessions_IPinfo";
                        break;

                    case OASDataStoreKind.DynamicForm:
                        if (FormID > 0)
                        {
                            kindName = "tbl_OAS_" + OrganizationID.ToString() + "_Form_" + FormID + "_Data";
                        }
                        break;
                    case OASDataStoreKind.DateIDs:
                        kindName = "tbl_Dates";
                        break;
                    case OASDataStoreKind.TimeIDs:
                        kindName = "tbl_Times";
                        break;

                    default:
                        break;
                }
            }
            finally
            {

            }

            return kindName;
        }

        #endregion









        /// <summary>
        ///     THIS METHOD IS USEFUL IN INSERTING THE DATA INTO DATA STORE DB
        /// </summary>
        /// <param name="baseModel"></param>
        /// <param name="EntityListsToInsert"></param>
        /// <param name="datastoredb"></param>
        /// <param name="input"></param>
        /// <param name="serializeMe"></param>
        /// <returns></returns>
        internal IReadOnlyList<Key> Common_InsertDataIntoDataStore(object baseModel, List<Entity> EntityListsToInsert, DatastoreDb datastoredb, GoogleDataStoreInputInfo input, object serializeMe)
        {
            IReadOnlyList<Key> resultKeys = null;
            int retryTimeOutMilliSecs = 1000;//1 sec
            try
            {

                //checking for valid data
                if (baseModel == null || input == null)
                    return resultKeys;


                if (string.IsNullOrEmpty(input.MethodName) || string.IsNullOrWhiteSpace(input.MethodName))
                    input.MethodName = System.Reflection.MethodBase.GetCurrentMethod().Name;



                if (baseModel == null || EntityListsToInsert == null || EntityListsToInsert.Count <= 0 || datastoredb == null || input == null)
                {
                    resultKeys = null;
                }
                else
                {
                    try
                    {
                        //regular Insertion
                        resultKeys = datastoredb.Insert(EntityListsToInsert);
                    }
                    catch (Exception ex)
                    {
                        //trial - I
                        try
                        {
                            if (isRetryException(ex))
                            {
                                //if (ex.GetHttpCode() == 503)
                                retryTimeOutMilliSecs = 2 * 1000;

                                //trial - I
                                // as the google accepts the next request accepts after 30 secs only
                                System.Threading.Thread.Sleep(retryTimeOutMilliSecs);
                                resultKeys = datastoredb.Upsert(EntityListsToInsert);
                            }
                        }
                        catch (Exception ex1)
                        {
                            //trial - II    
                            if (isRetryException(ex1))
                            {
                                try
                                {
                                    //if (ex1.GetHttpCode() == 503)
                                    retryTimeOutMilliSecs = 2 * 1000;

                                    //trial - II                                   
                                    System.Threading.Thread.Sleep(retryTimeOutMilliSecs);

                                    resultKeys = datastoredb.Upsert(EntityListsToInsert);
                                }
                                catch (Exception ex2)
                                {
                                    //trial - III                   
                                    if (isRetryException(ex2))
                                    {

                                        //if (ex2.GetHttpCode() == 503)
                                        retryTimeOutMilliSecs = 2 * 1000;

                                        //trial - III                                   
                                        System.Threading.Thread.Sleep(retryTimeOutMilliSecs);
                                        resultKeys = datastoredb.Upsert(EntityListsToInsert);

                                    }

                                }

                            }

                        }
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            finally
            {

            }

            return resultKeys;
        }



        internal async Task<IReadOnlyList<Key>> Common_InsertDataIntoDataStore_Async(object baseModel, List<Entity> EntityListsToInsert, DatastoreDb datastoredb, GoogleDataStoreInputInfo input, object serializeMe)
        {
            IReadOnlyList<Key> resultKeys = null;
            int retryTimeOutMilliSecs = 1000;//1 sec

            try
            {

                //checking for valid data
                if (baseModel == null || input == null)
                    return resultKeys;

                if (string.IsNullOrEmpty(input.MethodName) || string.IsNullOrWhiteSpace(input.MethodName))
                    input.MethodName = System.Reflection.MethodBase.GetCurrentMethod().Name;

                if (baseModel == null || EntityListsToInsert == null || EntityListsToInsert.Count <= 0 || datastoredb == null || input == null)
                {
                    resultKeys = null;
                }
                else
                {
                    try
                    {
                        //regular Insertion
                        resultKeys = await datastoredb.InsertAsync(EntityListsToInsert);
                    }
                    catch (Exception ex)
                    {
                        //trial - I
                        try
                        {
                            if (isRetryException(ex))
                            {
                                //if (ex.GetHttpCode() == 503)
                                retryTimeOutMilliSecs = 2 * 1000;

                                //trial - I
                                // as the google accepts the next request accepts after 30 secs only
                                System.Threading.Thread.Sleep(retryTimeOutMilliSecs);
                                resultKeys = await datastoredb.UpsertAsync(EntityListsToInsert);
                            }
                        }
                        catch (Exception ex1)
                        {
                            //trial - II    
                            if (isRetryException(ex1))
                            {
                                try
                                {
                                    //if (ex1.GetHttpCode() == 503)
                                    retryTimeOutMilliSecs = 2 * 1000;

                                    //trial - II                                   
                                    System.Threading.Thread.Sleep(retryTimeOutMilliSecs);

                                    resultKeys = await datastoredb.UpsertAsync(EntityListsToInsert);
                                }
                                catch (Exception ex2)
                                {
                                    //trial - III                   
                                    if (isRetryException(ex2))
                                    {

                                        //if (ex2.GetHttpCode() == 503)
                                        retryTimeOutMilliSecs = 2 * 1000;

                                        //trial - III                                   
                                        System.Threading.Thread.Sleep(retryTimeOutMilliSecs);
                                        resultKeys = await datastoredb.UpsertAsync(EntityListsToInsert);

                                    }

                                }

                            }

                        }
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

            }

            return resultKeys;
        }



        internal IReadOnlyList<Key> Common_UpdateDataIntoDataStore(object baseModel, List<Entity> EntityListsToInsert, DatastoreDb datastoredb, GoogleDataStoreInputInfo input, object serializeMe)
        {
            IReadOnlyList<Key> resultKeys = null;
            int retryTimeOutMilliSecs = 1000;//1 sec
            try
            {

                //checking for valid data
                if (baseModel == null || input == null)
                    return resultKeys;


                if (string.IsNullOrEmpty(input.MethodName) || string.IsNullOrWhiteSpace(input.MethodName))
                    input.MethodName = System.Reflection.MethodBase.GetCurrentMethod().Name;



                if (baseModel == null || EntityListsToInsert == null || EntityListsToInsert.Count <= 0 || datastoredb == null || input == null)
                {
                    resultKeys = null;
                }
                else
                {
                    try
                    {
                        //regular Insertion
                        resultKeys = datastoredb.Upsert(EntityListsToInsert);
                    }
                    catch (Exception ex)
                    {
                        //trial - I
                        try
                        {
                            if (isRetryException(ex))
                            {
                                //if (ex.GetHttpCode() == 503)
                                retryTimeOutMilliSecs = 2 * 1000;

                                //trial - I
                                // as the google accepts the next request accepts after 30 secs only
                                System.Threading.Thread.Sleep(retryTimeOutMilliSecs);
                                resultKeys = datastoredb.Upsert(EntityListsToInsert);
                            }
                        }
                        catch (Exception ex1)
                        {
                            //trial - II    
                            if (isRetryException(ex1))
                            {
                                try
                                {
                                    //if (ex1.GetHttpCode() == 503)
                                    retryTimeOutMilliSecs = 2 * 1000;

                                    //trial - II                                   
                                    System.Threading.Thread.Sleep(retryTimeOutMilliSecs);

                                    resultKeys = datastoredb.Upsert(EntityListsToInsert);
                                }
                                catch (Exception ex2)
                                {
                                    //trial - III                   
                                    if (isRetryException(ex2))
                                    {

                                        //if (ex2.GetHttpCode() == 503)
                                        retryTimeOutMilliSecs = 2 * 1000;

                                        //trial - III                                   
                                        System.Threading.Thread.Sleep(retryTimeOutMilliSecs);
                                        resultKeys = datastoredb.Upsert(EntityListsToInsert);

                                    }

                                }

                            }

                        }
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            finally
            {

            }

            return resultKeys;
        }


        internal async Task<IReadOnlyList<Key>> Common_UpdateDataIntoDataStore_Async(object baseModel, List<Entity> EntityListsToInsert, DatastoreDb datastoredb, GoogleDataStoreInputInfo input, object serializeMe)
        {
            IReadOnlyList<Key> resultKeys = null;
            int retryTimeOutMilliSecs = 1000;//1 sec

            try
            {

                //checking for valid data
                if (baseModel == null || input == null)
                    return resultKeys;


                if (string.IsNullOrEmpty(input.MethodName) || string.IsNullOrWhiteSpace(input.MethodName))
                    input.MethodName = System.Reflection.MethodBase.GetCurrentMethod().Name;



                if (baseModel == null || EntityListsToInsert == null || EntityListsToInsert.Count <= 0 || datastoredb == null || input == null)
                {
                    resultKeys = null;
                }
                else
                {
                    try
                    {
                        //regular Insertion
                        resultKeys = await datastoredb.UpsertAsync(EntityListsToInsert);
                    }
                    catch (Exception ex)
                    {
                        //trial - I
                        try
                        {
                            if (isRetryException(ex))
                            {
                                //if (ex.GetHttpCode() == 503)
                                retryTimeOutMilliSecs = 2 * 1000;

                                //trial - I
                                // as the google accepts the next request accepts after 30 secs only
                                System.Threading.Thread.Sleep(retryTimeOutMilliSecs);
                                resultKeys = await datastoredb.UpsertAsync(EntityListsToInsert);
                            }
                        }
                        catch (Exception ex1)
                        {
                            //trial - II    
                            if (isRetryException(ex1))
                            {
                                try
                                {
                                    //if (ex1.GetHttpCode() == 503)
                                    retryTimeOutMilliSecs = 2 * 1000;

                                    //trial - II                                   
                                    System.Threading.Thread.Sleep(retryTimeOutMilliSecs);

                                    resultKeys = await datastoredb.UpsertAsync(EntityListsToInsert);
                                }
                                catch (Exception ex2)
                                {
                                    //trial - III                   
                                    if (isRetryException(ex2))
                                    {

                                        //if (ex2.GetHttpCode() == 503)
                                        retryTimeOutMilliSecs = 2 * 1000;

                                        //trial - III                                   
                                        System.Threading.Thread.Sleep(retryTimeOutMilliSecs);
                                        resultKeys = await datastoredb.UpsertAsync(EntityListsToInsert);

                                    }

                                }

                            }

                        }
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            finally
            {

            }

            return resultKeys;
        }


        private bool isRetryException(Exception exInput)
        {
            //https://cloud.google.com/storage/docs/xml-api/reference-status#standardcodes
            //301—Moved Permanently, 304—Not Modified, 307—Temporary Redirect, 308—Resume Incomplete, 400—Bad Request, 401—Unauthorized, 403—Forbidden, 404—Not Found ,
            // 405—Method Not Allowed, 409—Conflict, 411—Length Required, 412—Precondition Failed, 416—Requested Range Not Satisfiable, 429—Too Many Requests, 500—Internal Server Error,
            // 503—Service Unavailable

            //
            // Summary:
            //     Gets the HTTP response status code to return to the client.
            //
            // Returns:
            //     A non-zero HTTP code representing the exception or the System.Exception.InnerException
            //     code; otherwise, HTTP response status code 500.
            bool responsetoReturn = true;

            try
            {
                string exceptionMessagestr = string.Empty;

                //Google.Rpc.Code.Unavailable
                //System.Net.HttpStatusCode.ServiceUnavailable
                //if (((Google.GoogleApiException)exInput).HttpStatusCode == Google.Rpc.Code.Unavailable)
                //{

                //}


                //if (((Google.Rpc.QuotaFailure.)exInput).HttpStatusCode == Google.Rpc.Code.Unavailable)
                //{

                //}

                if (exInput != null)
                {
                    if (!string.IsNullOrEmpty(exInput.Message))
                        exceptionMessagestr = exInput.Message.ToString().ToLower();
                    else if (exInput.InnerException != null && !string.IsNullOrEmpty(exInput.InnerException.Message))
                        exceptionMessagestr = exInput.InnerException.Message.ToString().ToLower();
                }


                //Status(StatusCode=Unavailable, Detail="Endpoint read failed")
                if (exceptionMessagestr.Contains("StatusCode=Unavailable".ToLower())
                    || exceptionMessagestr.Contains("StatusCode=DeadlineExceeded".ToLower())
                    || exceptionMessagestr.Contains("StatusCode=Aborted".ToLower()))
                {
                    responsetoReturn = true;
                }
                else
                    responsetoReturn = false;

            }
            catch (Exception)
            {

            }

            return responsetoReturn;
        }



        #region             "       SET VALUES FOR PROPERTIES IN ENTITTY         "


        /// <summary>
        /// THIS METHOD IS USEFUL IN SETTING THE ENTITTY INTEGER VALUE FOR PROPERTY
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="propName"></param>
        /// <param name="propValue"></param>
        /// <param name="isNullable"></param>
        /// <param name="ExcludeFromIndex"></param>
        internal void setEntityStringValue(ref Entity entity, string propName, string propValue, bool isNullable, bool ExcludeFromIndex)
        {

            if (isNullable)
            {
                if (!string.IsNullOrEmpty(propValue))
                {
                    entity[propName] = new Value()
                    {
                        ExcludeFromIndexes = ExcludeFromIndex,
                        StringValue = propValue
                    };
                }
                else
                {
                    entity[propName] = new Value()
                    {
                        ExcludeFromIndexes = ExcludeFromIndex,
                        NullValue = Google.Protobuf.WellKnownTypes.NullValue.NullValue
                    };
                }
            }
            else
            {
                if (!string.IsNullOrEmpty(propValue))
                {
                    entity[propName] = new Value()
                    {
                        ExcludeFromIndexes = ExcludeFromIndex,
                        StringValue = propValue
                    };
                }
                else
                {
                    entity[propName] = new Value()
                    {
                        ExcludeFromIndexes = ExcludeFromIndex,
                        NullValue = Google.Protobuf.WellKnownTypes.NullValue.NullValue
                    };
                }
            }
        }


        /// <summary>
        /// THIS METHOD IS USEFUL IN SETTING THE BOOLEAN VALUE FOR BOOLEAN TYPE PROPERTY
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="propName"></param>
        /// <param name="propValue"></param>
        /// <param name="ExcludeFromIndex"></param>
        internal void setEntityBooleanValue(ref Entity entity, string propName, bool propValue, bool ExcludeFromIndex)
        {

            entity[propName] = new Value()
            {
                ExcludeFromIndexes = ExcludeFromIndex,
                BooleanValue = propValue
            };
        }


        /// <summary>
        /// THIS METHOD IS USEFUL IN SETTING THE INTEGER VALUE FOR INT TYPE PROPERTY
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="propName"></param>
        /// <param name="propValue"></param>
        /// <param name="ExcludeFromIndex"></param>
        internal void setEntityIntValue(ref Entity entity, string propName, int propValue, bool ExcludeFromIndex)
        {

            if (propValue > 0)
            {
                entity[propName] = new Value()
                {
                    ExcludeFromIndexes = ExcludeFromIndex,
                    IntegerValue = propValue
                };
            }
            else
            {
                entity[propName] = new Value()
                {
                    ExcludeFromIndexes = ExcludeFromIndex,
                    IntegerValue = 0
                };
            }
        }

        internal void setEntityIntValue(ref Entity entity, string propName, long propValue, bool ExcludeFromIndex)
        {

            if (propValue > 0)
            {
                entity[propName] = new Value()
                {
                    ExcludeFromIndexes = ExcludeFromIndex,
                    IntegerValue = propValue
                };
            }
            else
            {
                entity[propName] = new Value()
                {
                    ExcludeFromIndexes = ExcludeFromIndex,
                    IntegerValue = 0
                };
            }
        }



        internal void setEntityIntValue(ref Entity entity, string propName, int? propValue, bool ExcludeFromIndex)
        {

            if (propValue != null && propValue > 0)
            {
                entity[propName] = new Value()
                {
                    ExcludeFromIndexes = ExcludeFromIndex,
                    IntegerValue = Convert.ToInt32(propValue)
                };
            }
            else
            {
                entity[propName] = new Value()
                {
                    ExcludeFromIndexes = ExcludeFromIndex,
                    NullValue = Google.Protobuf.WellKnownTypes.NullValue.NullValue
                };
            }
        }

        internal int GetInt32ValueFromEntity(Entity entity, string propName)
        {
            int valReaded = 0;

            if (entity != null && !string.IsNullOrEmpty(propName) && entity[propName] != null)
            {
                if (!entity[propName].IsNull)
                    valReaded = Convert.ToInt32(entity[propName].IntegerValue);
            }

            return valReaded;
        }

        internal Int64 GetInt64ValueFromEntity(Entity entity, string propName)
        {
            Int64 valReaded = 0;

            if (entity != null && !string.IsNullOrEmpty(propName) && entity[propName] != null)
            {
                if (!entity[propName].IsNull)
                    valReaded = entity[propName].IntegerValue;
            }

            return valReaded;
        }

        internal int? GetInt32ValueNullableFromEntity(Entity entity, string propName)
        {
            int? valReaded = null;

            if (entity != null && !string.IsNullOrEmpty(propName) && entity[propName] != null)
            {
                if (!entity[propName].IsNull)
                    valReaded = Convert.ToInt32(entity[propName].IntegerValue);
            }

            return valReaded;
        }


        internal bool? GetBooleanValueNullableFromEntity(Entity entity, string propName)
        {
            bool? valReaded = null;

            if (entity != null && !string.IsNullOrEmpty(propName) && entity[propName] != null)
            {
                if (!entity[propName].IsNull)
                    valReaded = entity[propName].BooleanValue;
            }

            return valReaded;
        }

        internal bool GetBooleanValueFromEntity(Entity entity, string propName)
        {
            bool valReaded = false;

            if (entity != null && !string.IsNullOrEmpty(propName) && entity[propName] != null)
            {
                if (!entity[propName].IsNull)
                    valReaded = entity[propName].BooleanValue;
            }
            return valReaded;
        }

        internal string GetStringValueFromEntity(Entity entity, string propName)
        {
            string valReaded = string.Empty;

            if (entity != null && !string.IsNullOrEmpty(propName) && entity[propName] != null)
            {
                if (!entity[propName].IsNull)
                    valReaded = entity[propName].StringValue;
            }
            return valReaded;
        }


        internal ArrayValue GetArrayValueFromEntity(Entity entity, string propName)
        {
            ArrayValue valReaded = null;

            if (entity != null && !string.IsNullOrEmpty(propName) && entity[propName] != null)
            {
                if (!entity[propName].IsNull)
                    valReaded = entity[propName].ArrayValue;
            }
            return valReaded;
        }

        internal string GetDateFormatStringValueFromEntity(Entity entity, string propName)
        {
            string valReaded = string.Empty;

            if (entity != null && !string.IsNullOrEmpty(propName) && entity[propName] != null)
            {
                if (!entity[propName].IsNull)
                    return Convert.ToDateTime(entity[propName]).ToUniversalTime().ToString("MM/dd/yyyy hh:mm:ss");
            }
            return valReaded;
        }


        internal string GetTimestampValueFromEntity(Entity entity, string propName)
        {
            string valReaded = string.Empty;

            if (entity != null && !string.IsNullOrEmpty(propName) && entity[propName] != null)
            {
                if (!entity[propName].IsNull)
                    valReaded = entity[propName].TimestampValue.ToDateTime().ToString("MM/dd/yyyy hh:mm:ss a");
            }
            return valReaded;
        }


        internal string GetKeyValueInEntityString(Entity entity)
        {

            string keyval = string.Empty;

            if (entity != null && entity.Key != null && entity.Key.Path.Count > 0)
                keyval = entity.Key.Path[0].Id.ToString();

            return keyval;

        }

        internal string GetKeyValueInEntityString(Key entityKey)
        {

            string keyval = string.Empty;

            if (entityKey != null && entityKey.Path.Count > 0)
                keyval = entityKey.Path[0].Id.ToString();

            return keyval;

        }

        internal Int64 GetKeyValueInEntityInt(Key entityKey)
        {
            Int64 keyval = 0;

            if (entityKey != null && entityKey.Path.Count > 0)
                keyval = entityKey.Path[0].Id;

            return keyval;

        }

        internal Int64 GetKeyValueInEntityInt(Entity entity)
        {
            Int64 keyval = 0;

            if (entity != null && entity.Key != null && entity.Key.Path.Count > 0)
                keyval = entity.Key.Path[0].Id;

            return keyval;

        }

        internal string GetCurrentUniversalDateTime()
        {
            return DateTime.Now.ToUniversalTime().ToString("MM/dd/yyyy hh:mm:ss");
        }

        #endregion


        #region"                METHOD TO CONVERT STRING PWD TO HASH DATA        "


        /// <summary>
        /// CONVERTING STRING TO HASH DATA
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        internal string GetHashData(string data)
        {
            StringBuilder hashRet = null;
            byte[] msgBytes = null;
            byte b = 0;
            byte[] hashBytes = null;
            try
            {
                // Convert the string to a unicode array of bytes.
                msgBytes = Encoding.Unicode.GetBytes(data);

                // Calculate a hash on the data.
                using (SHA1Managed sha1 = new SHA1Managed())
                {
                    hashBytes = sha1.ComputeHash(msgBytes);

                    // Use the string builder for increased speed.
                    hashRet = new StringBuilder("");

                    // Loop and convert each digit in the hash.

                    foreach (byte b_loopVariable in hashBytes)
                    {
                        b = b_loopVariable;
                        hashRet.AppendFormat("{0:X}", b);
                    }

                }

            }
            finally
            {
                msgBytes = null;
                b = 0;
                hashBytes = null;

            }
            // Return the hash.
            return hashRet.ToString();
        }

        #endregion


        public DateTime GetAdminDateTime()
        {
            return DateTime.Now;
        }

        public string GetAdminDateTime_String()
        {
            return DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss");
        }

        public DateTime GetAdminDateTime_UTC()
        {
            return DateTime.UtcNow;
        }

        public string GetAdminDateTime_String_UTC()
        {
            return DateTime.UtcNow.ToString("MM/dd/yyyy hh:mm:ss");
        }

        public Int64 GetAdminDateTime_Int_UTC()
        {
            return Convert.ToInt64(DateTime.UtcNow.ToString("MMddyyyyhhmmssfff"));
        }

        public string GetAdminDateTime_Str_UTC()
        {
            return DateTime.UtcNow.ToString("yyyyMMddhhmmssfff");
        }

        public string GetRandomNumber()
        {
            Random generator = new Random();
            String r = string.Empty;
            r = generator.Next(0, 99).ToString("D2");
            return r;
        }

        public long GetRandomNumber_DateUTC_Int()
        {
            string utcstr = GetAdminDateTime_Str_UTC();

            return Convert.ToInt64(utcstr + GetRandomNumber());
        }



        /// <summary>
        /// THIS METHOD IS USEFUL IN SETTING THE COMMON ENTITY PORPERTIES
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="loginModel"></param>
        /// <param name="currentDateTime"></param>
        /// <param name="isEditMode"></param>
        internal void setCommonEntityProperties(ref Entity entity, BaseModel loginModel, string currentDateTime, bool isEditMode)
        {
            try
            {
                if (entity == null || loginModel == null || loginModel.orgmodel == null) return;

                if (string.IsNullOrEmpty(currentDateTime) || string.IsNullOrWhiteSpace(currentDateTime))
                    currentDateTime = GetAdminDateTime_String();

                //setting the edit mode data only
                if (isEditMode)
                {
                    setEntityIntValue(ref entity, "ModfiedBy", loginModel.orgmodel.LoggedUserID, true);

                    // setEntityStringValue(ref entity, "ModfiedOn", new CommonDate(currentDateTime).DateTimeVal, true, true);

                    setEntityIntValue(ref entity, "ModfiedOnDateID", GetDateID(loginModel), true);

                    setEntityIntValue(ref entity, "ModfiedOnTimeID", GetTimeID(loginModel), true);

                    if (loginModel.orgmodel.clientsessioninfo != null)
                        setEntityIntValue(ref entity, "clientModifiedGDSUID", loginModel.orgmodel.clientsessioninfo.ClientSessionGDSUID, true);
                    else
                        setEntityIntValue(ref entity, "clientModifiedGDSUID", 0, true);
                }
                else
                {
                    setEntityIntValue(ref entity, "CreatedBy", loginModel.orgmodel.LoggedUserID, true);

                    //setEntityIntValue(ref entity, "CreatedOn", loginModel.orgmodel.LoggedUserID, true);

                    setEntityIntValue(ref entity, "CreatedOnDateID", GetDateID(loginModel), true);

                    setEntityIntValue(ref entity, "CreatedOnTimeID", GetTimeID(loginModel), true);

                    setEntityIntValue(ref entity, "ModfiedBy", 0, true);

                    setEntityStringValue(ref entity, "ModfiedOn", "", true, true);

                    setEntityIntValue(ref entity, "ModfiedOnDateID", 0, true);

                    setEntityIntValue(ref entity, "ModfiedOnTimeID", 0, true);

                    if (loginModel.orgmodel.clientsessioninfo != null)
                        setEntityIntValue(ref entity, "clientCreatedGDSUID", loginModel.orgmodel.clientsessioninfo.ClientSessionGDSUID, true);
                    else
                        setEntityIntValue(ref entity, "clientModifiedGDSUID", 0, true);
                }

            }
            finally
            {

            }
        }

        #region "**********************   CREATE DATE ID AND TIME ID *********************************   "

        public Int32 GetDateID(BaseModel loginModel)
        {
            ResponseModel response = null;
            DateIDsModel dateidsmodel = null;
            try
            {
                DateTime StartDate = new DateTime(1900, 1, 1, 1, 0, 0);

                StartDate = StartDate.ToUniversalTime();

                DateTime presentDate = DateTime.UtcNow;

                TimeSpan t = presentDate - StartDate;

                Int32 TotalNoOfDaysBetweenDates = Convert.ToInt32(t.TotalDays);

                dateidsmodel = new DateIDsModel();
                dateidsmodel.Date_UTC_ID = TotalNoOfDaysBetweenDates;
                dateidsmodel.Date_UTC = presentDate.ToString();
                dateidsmodel.orgmodel = loginModel.orgmodel;

                response = createDateIDAndInsertIntoDataTable(dateidsmodel);

                return dateidsmodel.Date_UTC_ID;

            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public Int32 GetDateIDWithParameter(BaseModel loginModel, DateTime InputDate)
        {
            ResponseModel response = null;
            DateIDsModel dateidsmodel = null;
            try
            {
                if (InputDate != null)
                {

                    DateTime StartDate = new DateTime(1900, 1, 1, 1, 0, 0);

                    StartDate = StartDate.ToUniversalTime();

                    DateTime presentDate = InputDate;

                    TimeSpan t = presentDate - StartDate;

                    Int32 TotalNoOfDaysBetweenDates = Convert.ToInt32(t.TotalDays);

                    dateidsmodel = new DateIDsModel();
                    dateidsmodel.Date_UTC_ID = TotalNoOfDaysBetweenDates;
                    dateidsmodel.Date_UTC = presentDate.ToString();
                    dateidsmodel.orgmodel = loginModel.orgmodel;

                    response = createDateIDAndInsertIntoDataTable(dateidsmodel);

                }

                return dateidsmodel.Date_UTC_ID;
            }
            catch (Exception ex)
            {

                throw;
            }
        }


        public ResponseModel createDateIDAndInsertIntoDataTable(DateIDsModel dateidsmodel)
        {
            ResponseModel response = null;
            DatastoreDb datastoreDb = null;
            string kindName = string.Empty;
            KeyFactory keyFactory = null;
            Entity entity = null;
            Boolean isEditMode = false;

            try
            {
                using (CommonBusinessAccess commobj = new CommonBusinessAccess())
                {
                    //create data store db instance
                    datastoreDb = commobj.BuildRequiredPropertiesForGoogleDataStore();

                    //get the kind name
                    kindName = commobj.GetKindNameBasedOnPracticeID(OASDataStoreKind.DateIDs, dateidsmodel.orgmodel.OrganizationID);

                    //creating the key factory instance to generate new key for kind entitty
                    keyFactory = datastoreDb.CreateKeyFactory(kindName);

                    //Query query = new Query(kindName)
                    //{
                    //    Filter = Filter.Equal("Status", (int)OASDataStatus.ActiveData),
                    //};

                    //List<Entity> list = datastoreDb.RunQuery(query).Entities.ToList();

                    //if (list != null && list.Count > 0)
                    //{
                    //    var isFound = false;

                    //    foreach (Entity itemEnt in list)
                    //    {
                    //        //setEntityIntValue(ref entity, "Status", (int)OASDataStatus.ActiveData, false)
                    //        if (commobj.GetBooleanValueFromEntity(itemEnt, "Status"))
                    //        {

                    //        }
                    //        else
                    //            isFound = true;

                    //        //if(commobj.GetInt32ValueFromEntity(itemEnt, OASDataStatus.ActiveData.ToString)
                    //    }

                    //    if (isFound)
                    //    {
                    //        response = new ResponseModel();
                    //        response.RequestExecutionStatus = -2;
                    //        response.ErrorMessage = "Date ID Already Exists";
                    //    }
                    //    else
                    //    {
                    //        entity = new Entity()
                    //        {

                    //        };
                    //        entity.Key = keyFactory.CreateIncompleteKey();
                    //    }
                    //}
                    //else
                    //{
                    //    entity = new Entity()
                    //    {

                    //    };
                    //    entity.Key = keyFactory.CreateIncompleteKey();
                    //}

                    Key keyToFind = keyFactory.CreateKey(dateidsmodel.Date_UTC_ID);

                    entity = new Entity()
                    {

                    };

                    entity.Key = keyToFind;

                    Entity entityPrevious = datastoreDb.Lookup(keyToFind);

                    if (entity != null && entityPrevious == null)
                    {

                        //Int64 FormID = commobj.GetAdminDateTime_Int_UTC();

                        //setting the values
                        commobj.setEntityIntValue(ref entity, "Date_utc_id", dateidsmodel.Date_UTC_ID, false);

                        commobj.setEntityStringValue(ref entity, "Date_utc", dateidsmodel.Date_UTC, true, true);

                        commobj.setEntityIntValue(ref entity, "Status", (int)OASDataStatus.ActiveData, false);

                        //commobj.setEntityBooleanValue(ref entity, "Inactive", false, false);

                        //setting the centralized log values
                        //commobj.setCommonEntityProperties(ref entity, (dateidsmodel as BaseModel), null, isEditMode);


                        List<Entity> listinsert = new List<Entity>();

                        listinsert.Add(entity);


                        using (GoogleDataStoreInputInfo info = new GoogleDataStoreInputInfo())
                        {

                            if (isEditMode)
                            {
                                IReadOnlyList<Key> listCol = commobj.Common_UpdateDataIntoDataStore(dateidsmodel, listinsert, datastoreDb, info, this);
                            }
                            else
                            {
                                IReadOnlyList<Key> listCol = commobj.Common_InsertDataIntoDataStore(dateidsmodel, listinsert, datastoreDb, info, this);
                            }

                        }
                    }
                }
            }
            finally
            {

            }
            return response;
        }

        public Int32 GetTimeID(BaseModel loginModel)
        {
            ResponseModel response = null;
            TimeIDsModel timeidsmodel = null;
            try
            {

                var dateTime = DateTime.Now;

                Int32 TimeId = (dateTime.Hour * 60 * 60) + (dateTime.Minute * 60) + (dateTime.Second);

                timeidsmodel = new TimeIDsModel();
                timeidsmodel.TimeID = TimeId;
                timeidsmodel.Time = dateTime.ToString("hh:mm:ss");
                timeidsmodel.orgmodel = loginModel.orgmodel;

                response = createTimeIDAndInsertIntoDataTable(timeidsmodel);

                return timeidsmodel.TimeID;
            }
            catch (Exception)
            {

                throw;
            }
        }

        public Int32 GetTimeIDWithParameter(BaseModel loginModel, DateTime InputDateTime)
        {
            ResponseModel response = null;
            TimeIDsModel timeidsmodel = null;
            try
            {
                if (InputDateTime != null)
                {
                    var dateTime = InputDateTime;

                    Int32 TimeId = (dateTime.Hour * 60 * 60) + (dateTime.Minute * 60) + (dateTime.Second);

                    timeidsmodel = new TimeIDsModel();
                    timeidsmodel.TimeID = TimeId;
                    timeidsmodel.Time = dateTime.ToString("hh:mm:ss");
                    timeidsmodel.orgmodel = loginModel.orgmodel;

                    response = createTimeIDAndInsertIntoDataTable(timeidsmodel);
                }

                return timeidsmodel.TimeID;
            }
            catch (Exception)
            {

                throw;
            }
        }


        public ResponseModel createTimeIDAndInsertIntoDataTable(TimeIDsModel timeidsmodel)
        {
            ResponseModel response = null;
            DatastoreDb datastoreDb = null;
            string kindName = string.Empty;
            KeyFactory keyFactory = null;
            Entity entity = null;
            Boolean isEditMode = false;

            try
            {
                using (CommonBusinessAccess commobj = new CommonBusinessAccess())
                {
                    //create data store db instance
                    datastoreDb = commobj.BuildRequiredPropertiesForGoogleDataStore();

                    //get the kind name
                    kindName = commobj.GetKindNameBasedOnPracticeID(OASDataStoreKind.TimeIDs, timeidsmodel.orgmodel.OrganizationID);

                    //creating the key factory instance to generate new key for kind entitty
                    keyFactory = datastoreDb.CreateKeyFactory(kindName);


                    //Query query = new Query(kindName)
                    //{
                    //    Filter = Filter.Equal("Status", (int)OASDataStatus.ActiveData),
                    //};

                    //List<Entity> list = datastoreDb.RunQuery(query).Entities.ToList();

                    //if (list != null && list.Count > 0)
                    //{
                    //    var isFound = false;

                    //    foreach (Entity itemEnt in list)
                    //    {
                    //        //setEntityIntValue(ref entity, "Status", (int)OASDataStatus.ActiveData, false)
                    //        if (commobj.GetBooleanValueFromEntity(itemEnt, "Status"))
                    //        {

                    //        }
                    //        else
                    //            isFound = true;

                    //        //if(commobj.GetInt32ValueFromEntity(itemEnt, OASDataStatus.ActiveData.ToString)
                    //    }

                    //    if (isFound)
                    //    {
                    //        response = new ResponseModel();
                    //        response.RequestExecutionStatus = -2;
                    //        response.ErrorMessage = "Time ID Already Exists";
                    //    }
                    //    else
                    //    {
                    //        entity = new Entity()
                    //        {

                    //        };
                    //        entity.Key = keyFactory.CreateIncompleteKey();
                    //    }
                    //}
                    //else
                    //{
                    //    entity = new Entity()
                    //    {

                    //    };
                    //    entity.Key = keyFactory.CreateIncompleteKey();
                    //}

                    Key keyToFind = keyFactory.CreateKey(timeidsmodel.TimeID);

                    entity = new Entity()
                    {

                    };

                    entity.Key = keyToFind;

                    Entity entityPrevious = datastoreDb.Lookup(keyToFind);



                    if (entity != null && entityPrevious == null)
                    {

                        //Int64 FormID = commobj.GetAdminDateTime_Int_UTC();

                        //setting the values
                        commobj.setEntityIntValue(ref entity, "TimeID", timeidsmodel.TimeID, false);

                        commobj.setEntityStringValue(ref entity, "Time", timeidsmodel.Time, true, true);

                        commobj.setEntityIntValue(ref entity, "Status", (int)OASDataStatus.ActiveData, false);

                        //commobj.setEntityBooleanValue(ref entity, "Inactive", false, false);

                        //setting the centralized log values
                        //commobj.setCommonEntityProperties(ref entity, (timeidsmodel as BaseModel), null, isEditMode);


                        List<Entity> listinsert = new List<Entity>();

                        listinsert.Add(entity);


                        using (GoogleDataStoreInputInfo info = new GoogleDataStoreInputInfo())
                        {

                            if (isEditMode)
                            {
                                IReadOnlyList<Key> listCol = commobj.Common_UpdateDataIntoDataStore(timeidsmodel, listinsert, datastoreDb, info, this);

                            }
                            else
                            {
                                IReadOnlyList<Key> listCol = commobj.Common_InsertDataIntoDataStore(timeidsmodel, listinsert, datastoreDb, info, this);
                            }

                        }
                    }
                }
            }
            finally
            {

            }
            return response;
        }
        #endregion




        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "

        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {

            }
        }

        #endregion



    }

    public class CommonDate : IDisposable
    {
        private string dateTimeAssigned = string.Empty;


        //default constructor
        public CommonDate(string _dateTimeAssigned)
        {
            dateTimeAssigned = _dateTimeAssigned;
        }

        //default constructor
        public CommonDate(DateTime _dateTimeAssigned)
        {
            dateTimeAssigned = _dateTimeAssigned.ToString("MM/dd/yyyy hh:mm:ss");
        }

        //public CommonDate()
        //{
        //    dateTimeAssigned = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss");
        //}

        public string DateVal
        {
            get
            {
                return GetDate();
            }
        }

        public string DateVal_UTC
        {
            get
            {
                return GetDate_UTC();
            }
        }

        public string DateTimeVal
        {
            get
            {
                return GetDateTime();
            }
        }

        public string DateTimeVal_UTC
        {
            get
            {
                return GetDateTime_UTC();
            }
        }
        public int DateVal_Int
        {
            get
            {
                return GetDateInt();
            }
        }

        public int DateVal_Int_UTC
        {
            get
            {
                return GetDateInt_UTC();
            }
        }

        public int Time_Int_UTC
        {
            get
            {
                return GetTimeInt_UTC();
            }
        }

        public int Time_Int
        {
            get
            {
                return GetTimeInt();
            }
        }

        public string GetDate()
        {
            if (string.IsNullOrEmpty(dateTimeAssigned))
            {
                throw new Exception("No Valid Date Found");
            }
            else
                return Convert.ToDateTime(dateTimeAssigned).ToString("MM/dd/yyyy");
        }

        public string GetDateTime()
        {
            if (string.IsNullOrEmpty(dateTimeAssigned))
            {
                throw new Exception("No Valid Date Found");
            }
            else
                return Convert.ToDateTime(dateTimeAssigned).ToString("MM/dd/yyyy hh:mm:ss");
        }

        private int GetDateInt()
        {
            if (string.IsNullOrEmpty(dateTimeAssigned))
            {
                throw new Exception("No Valid Date Found");
            }
            else
                return Convert.ToInt32(Convert.ToDateTime(dateTimeAssigned).ToString("MMddyyyy"));
        }

        private int GetTimeInt()
        {
            if (string.IsNullOrEmpty(dateTimeAssigned))
            {
                throw new Exception("No Valid Date Found");
            }
            else
                return Convert.ToInt32(Convert.ToDateTime(dateTimeAssigned).ToString("hhmmss"));
        }

        private string GetDate_UTC()
        {
            if (string.IsNullOrEmpty(dateTimeAssigned))
            {
                throw new Exception("No Valid Date Found");
            }
            else
                return Convert.ToDateTime(dateTimeAssigned).ToUniversalTime().ToString("MM/dd/yyyy");
        }

        public string GetDateTime_UTC()
        {
            if (string.IsNullOrEmpty(dateTimeAssigned))
            {
                throw new Exception("No Valid Date Found");
            }
            else
                return Convert.ToDateTime(dateTimeAssigned).ToUniversalTime().ToString("MM/dd/yyyy hh:mm:ss");
        }

        private int GetDateInt_UTC()
        {
            if (string.IsNullOrEmpty(dateTimeAssigned))
            {
                throw new Exception("No Valid Date Found");
            }
            else
                return Convert.ToInt32(Convert.ToDateTime(dateTimeAssigned).ToUniversalTime().ToString("MMddyyyy"));
        }


        private int GetTimeInt_UTC()
        {
            if (string.IsNullOrEmpty(dateTimeAssigned))
            {
                throw new Exception("No Valid Date Found");
            }
            else
                return Convert.ToInt32(Convert.ToDateTime(dateTimeAssigned).ToUniversalTime().ToString("hhmmss"));
        }




        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "

        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                dateTimeAssigned = string.Empty;
            }
        }

        #endregion
    }

    public class GoogleDataStoreInputInfo : IDisposable
    {


        public string MethodName { get; set; }


        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {

            }
        }
        #endregion


    }
}
