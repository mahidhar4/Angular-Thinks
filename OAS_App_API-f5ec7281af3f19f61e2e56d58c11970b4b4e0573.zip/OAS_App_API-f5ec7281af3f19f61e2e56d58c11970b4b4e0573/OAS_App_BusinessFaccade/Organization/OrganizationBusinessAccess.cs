﻿using Google.Cloud.Datastore.V1;
using OAS_App_BusinessFaccade.Common;
using OAS_App_Common;
using OAS_App_Common.Common;
using OAS_App_Common.Organization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OAS_App_BusinessFaccade.Organization
{
    public class OrganizationBusinessAccess : IDisposable
    {

        #region "     ADD OR UPDATE ORGANIZATION DETAILS       "
        /// <summary>
        /// THIS METHOD IS USEFUL IN INSERT OR UPDATE THE ORGANIZATION INFO
        /// </summary>
        /// <param name="loginModel"></param>
        /// <returns></returns>
        /// 
        public async Task<ResponseModel> SaveAndUpdateOrganizationInfo(OrganizationInfo organizationModel)
        {
            ResponseModel response = null;
            DatastoreDb datastoreDb = null;
            string kindName = string.Empty;
            KeyFactory keyFactory = null;
            Entity entity = null;
            Boolean isEditMode = false;

            try
            {
                using (CommonBusinessAccess commobj = new CommonBusinessAccess())
                {
                    //create data store db instance
                    datastoreDb = commobj.BuildRequiredPropertiesForGoogleDataStore();

                    //get the kind name
                    kindName = commobj.GetKindNameBasedOnPracticeID(OASDataStoreKind.OrganizationsInfo, organizationModel.orgmodel.OrganizationID);

                    //creating the key factory instance to generate new key for kind entitty
                    keyFactory = datastoreDb.CreateKeyFactory(kindName);

                    if (!string.IsNullOrEmpty(organizationModel.orggdsuid))
                    {
                        Key key = keyFactory.CreateKey(Convert.ToInt64(organizationModel.orggdsuid));

                        //looking or searching with key in kind
                        entity = await datastoreDb.LookupAsync(key);

                        isEditMode = true;
                    }
                    else
                    {
                        Query query = new Query(kindName)
                        {
                                Filter = Filter.And(Filter.Equal("OrganizationID", organizationModel.organizationid),
                                                    Filter.Equal("InActive", false))
                        };

                        List<Entity> list = datastoreDb.RunQuery(query).Entities.ToList();

                        if (list != null && list.Count > 0)
                        {
                            var isFound = false;

                            foreach (Entity itemEnt in list)
                            {
                                if (commobj.GetBooleanValueFromEntity(itemEnt, "InActive"))
                                {

                                }
                                else
                                    isFound = true;
                            }

                            if (isFound)
                            {
                                response = new ResponseModel();
                                response.RequestExecutionStatus = -2;
                                response.ErrorMessage = "Organization ID Already Exists";
                            }
                            else
                            {
                                entity = new Entity()
                                {

                                };
                                entity.Key = keyFactory.CreateIncompleteKey();
                            }
                        }
                        else
                        {
                            entity = new Entity()
                            {

                            };
                            entity.Key = keyFactory.CreateIncompleteKey();
                        }

                    }


                    if (entity != null)
                    {
                        //setting the values
                        commobj.setEntityIntValue(ref entity, "OrganizationID", organizationModel.organizationid, false);

                        commobj.setEntityStringValue(ref entity, "OrganizationName", organizationModel.organizationname, true, true);

                        commobj.setEntityStringValue(ref entity, "OrganizationAddress", organizationModel.organizationaddress, true, true);

                        commobj.setEntityBooleanValue(ref entity, "Inactive", false, false);

                        //setting the centralized log values
                        commobj.setCommonEntityProperties(ref entity, (organizationModel as BaseModel), null, isEditMode);


                        List<Entity> listinsert = new List<Entity>();

                        listinsert.Add(entity);


                        using (GoogleDataStoreInputInfo info = new GoogleDataStoreInputInfo())
                        {

                            if (isEditMode)
                            {
                                IReadOnlyList<Key> listCol = await commobj.Common_UpdateDataIntoDataStore_Async(organizationModel, listinsert, datastoreDb, info, this);

                                if (listCol != null && listCol.Count > 0)
                                {
                                    organizationModel.orggdsuid = commobj.GetKeyValueInEntityString(listCol[0]);
                                }

                            }
                            else
                            {
                                IReadOnlyList<Key> listCol = await commobj.Common_InsertDataIntoDataStore_Async(organizationModel, listinsert, datastoreDb, info, this);

                                if (listCol != null && listCol.Count > 0)
                                {
                                    organizationModel.orggdsuid = commobj.GetKeyValueInEntityString(listCol[0]);
                                }
                            }

                        }
                    }
                }
            }
            finally
            {

            }
            return response;
        }


        #endregion



        #region "     DELETE ORGANIZATION DETAILS       "
        /// <summary>
        /// THIS METHOD IS USEFUL IN DELETING THE ORGANIZATION DETAILS
        /// </summary>
        /// <param name="loginModel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> DeleteOrganizationDetails(OrganizationInfo organizationModel)
        {
            ResponseModel response = null;
            DatastoreDb datastoreDb = null;
            string kindName = string.Empty;
            KeyFactory keyFactory = null;


            try
            {
                using (CommonBusinessAccess commobj = new CommonBusinessAccess())
                {
                    //create data store db instance
                    datastoreDb = commobj.BuildRequiredPropertiesForGoogleDataStore();

                    //get the kind name
                    kindName = commobj.GetKindNameBasedOnPracticeID(OASDataStoreKind.OrganizationsInfo, organizationModel.orgmodel.OrganizationID);

                    //creating the key factory instance to generate new key for kind entitty
                    keyFactory = datastoreDb.CreateKeyFactory(kindName);

                    if (!string.IsNullOrEmpty(organizationModel.orggdsuid))
                    {

                        Key key = keyFactory.CreateKey(Convert.ToInt64(organizationModel.orggdsuid));

                        //looking or searching with key in kind
                        Entity entity = await datastoreDb.LookupAsync(key);

                        if (entity != null)
                        {
                            //setting the values
                            commobj.setEntityBooleanValue(ref entity, "Inactive", true, false);

                            //setting the centralized log values
                            commobj.setCommonEntityProperties(ref entity, (organizationModel as BaseModel), null, true);

                            using (GoogleDataStoreInputInfo info = new GoogleDataStoreInputInfo())
                            {
                                List<Entity> listinsert = new List<Entity>();

                                listinsert.Add(entity);
                                commobj.Common_UpdateDataIntoDataStore(organizationModel, listinsert, datastoreDb, info, this);
                            }
                        }
                    }
                }
            }
            finally
            {

            }
            return response;
        }
        #endregion


        #region "     ORGANZAITON DETAILS LIST          "
        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING   ORGANZAITON DETAILS LIST      
        /// </summary>
        /// <returns></returns>
        public async Task<OrganizationInfo> OASOrganizationList(OrganizationInfo organizationinfo)
        {
            OrganizationInfo responsemodel = null;
            DatastoreDb datastoredb = null;
            string KindName = string.Empty;

            try
            {
                //ehrcommondatastoremodel.emrwebexceptiontracelogmodel.AddToExecutionLog("EHRGoogleDataStore.BusinessAccess", "PracticeInfoConfigBusinessAccess", "AppServersList", "AppServersList Start", ExecutionLogType.Detail);

                using (CommonBusinessAccess commonbusinessaccess = new CommonBusinessAccess())
                {
                    //creating the data store db connection instance
                    datastoredb = commonbusinessaccess.BuildRequiredPropertiesForGoogleDataStore();

                    //getting the kind name
                    KindName = commonbusinessaccess.GetKindNameBasedOnPracticeID(OASDataStoreKind.OrganizationsInfo, organizationinfo.orgmodel.OrganizationID);

                    Query query = new Query(KindName)
                    {
                        Filter = Filter.Equal("Inactive", false)
                    };


                    //RUNNING THE QUERY IN DB AND GETTING THE RESULTING ENTITIES LIST
                    List<Entity> OutputEntity = datastoredb.RunQuery(query).Entities.ToList();

                    responsemodel = new OrganizationInfo();

                    responsemodel.organizationinfo = new OrganizationInfo();

                    responsemodel.organizationinfolist = new List<OrganizationInfo>();



                    //LOOPING ON ALL THE RESULTS AND FORMING THE REQUIRED LIST OBJECTS
                    foreach (Entity newentity in OutputEntity)
                    {
                        OrganizationInfo modelObj = new OrganizationInfo();


                        #region "   GETTING THE ENTITY VALUES GENERATED USING TOOL       "

                        modelObj.orggdsuid = commonbusinessaccess.GetKeyValueInEntityString(newentity);

                        modelObj.organizationid = commonbusinessaccess.GetInt32ValueFromEntity(newentity, "OrganizationID");

                        modelObj.organizationname = commonbusinessaccess.GetStringValueFromEntity(newentity, "OrganizationName");

                        modelObj.organizationaddress = commonbusinessaccess.GetStringValueFromEntity(newentity, "OrganizationAddress");
                        

                        #endregion

                        responsemodel.organizationinfolist.Add(modelObj);
                    }
                }
            }
            finally
            {

            }

            return responsemodel;
        }

        #endregion

        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {

            }
        }
        #endregion
    }
}
