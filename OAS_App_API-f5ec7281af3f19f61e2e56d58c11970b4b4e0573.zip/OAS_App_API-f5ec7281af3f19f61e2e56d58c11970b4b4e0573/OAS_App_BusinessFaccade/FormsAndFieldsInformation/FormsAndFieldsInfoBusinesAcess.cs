﻿using Google.Cloud.Datastore.V1;
using OAS_App_BusinessFaccade.Common;
using OAS_App_Common;
using OAS_App_Common.Common;
using OAS_App_Common.OASFormsAndFieldsInfo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OAS_App_BusinessFaccade.FormsAndFieldsInformation
{
    public class FormsAndFieldsInfoBusinesAcess : IDisposable
    {


        #region "     ADD OR UPDATE ORGANIZATION DETAILS       "
        /// <summary>
        /// THIS METHOD IS USEFUL IN INSERT OR UPDATE THE ORGANIZATION INFO
        /// </summary>
        /// <param name="loginModel"></param>
        /// <returns></returns>
        /// 
        public async Task<ResponseModel> SaveAndUpdateFormsInformation(OASFormsInfoModel oasformsinfomodel)
        {
            ResponseModel response = null;
            DatastoreDb datastoreDb = null;
            string kindName = string.Empty;
            KeyFactory keyFactory = null;
            Entity entity = null;
            Boolean isEditMode = false;

            try
            {
                using (CommonBusinessAccess commobj = new CommonBusinessAccess())
                {
                    //create data store db instance
                    datastoreDb = commobj.BuildRequiredPropertiesForGoogleDataStore();

                    //get the kind name
                    kindName = commobj.GetKindNameBasedOnPracticeID(OASDataStoreKind.OASFormsInfo, oasformsinfomodel.orgmodel.OrganizationID);

                    //creating the key factory instance to generate new key for kind entitty
                    keyFactory = datastoreDb.CreateKeyFactory(kindName);

                    if (!string.IsNullOrEmpty(oasformsinfomodel.OASFormNameInfoGUID))
                    {
                        Key key = keyFactory.CreateKey(Convert.ToInt64(oasformsinfomodel.OASFormNameInfoGUID));

                        //looking or searching with key in kind
                        entity = await datastoreDb.LookupAsync(key);

                        isEditMode = true;
                    }
                    else
                    {
                        Query query = new Query(kindName)
                        {
                            Filter = Filter.And(Filter.Equal("OASFormName", oasformsinfomodel.OASFormName),
                                                    Filter.Equal("Status", (int)OASDataStatus.ActiveData))
                        };

                        List<Entity> list = datastoreDb.RunQuery(query).Entities.ToList();

                        if (list != null && list.Count > 0)
                        {
                            var isFound = false;

                            foreach (Entity itemEnt in list)
                            {
                                //setEntityIntValue(ref entity, "Status", (int)OASDataStatus.ActiveData, false)
                                if (commobj.GetBooleanValueFromEntity(itemEnt, "Status"))
                                {

                                }
                                else
                                    isFound = true;

                                //if(commobj.GetInt32ValueFromEntity(itemEnt, OASDataStatus.ActiveData.ToString)
                            }

                            if (isFound)
                            {
                                response = new ResponseModel();
                                response.RequestExecutionStatus = -2;
                                response.ErrorMessage = "Form Name Already Exists";
                            }
                            else
                            {
                                entity = new Entity()
                                {

                                };
                                entity.Key = keyFactory.CreateIncompleteKey();
                            }
                        }
                        else
                        {
                            entity = new Entity()
                            {

                            };
                            entity.Key = keyFactory.CreateIncompleteKey();
                        }

                    }


                    if (entity != null)
                    {

                        Int64 FormID = commobj.GetAdminDateTime_Int_UTC();

                        //setting the values
                        commobj.setEntityStringValue(ref entity, "OASFormName", oasformsinfomodel.OASFormName, true, true);

                        commobj.setEntityStringValue(ref entity, "OASFormNameKindName", commobj.GetKindNameBasedOnPracticeID(OASDataStoreKind.DynamicForm, oasformsinfomodel.orgmodel.OrganizationID, FormID), true, true); // oasformsinfomodel.OASFormNameKindName

                        commobj.setEntityIntValue(ref entity, "OASFormNameTypeID", FormID, false);

                        commobj.setEntityIntValue(ref entity, "Status", (int)OASDataStatus.ActiveData, false);

                        //commobj.setEntityBooleanValue(ref entity, "Inactive", false, false);

                        //setting the centralized log values
                        commobj.setCommonEntityProperties(ref entity, (oasformsinfomodel as BaseModel), null, isEditMode);


                        List<Entity> listinsert = new List<Entity>();

                        listinsert.Add(entity);


                        using (GoogleDataStoreInputInfo info = new GoogleDataStoreInputInfo())
                        {

                            if (isEditMode)
                            {
                                IReadOnlyList<Key> listCol = await commobj.Common_UpdateDataIntoDataStore_Async(oasformsinfomodel, listinsert, datastoreDb, info, this);

                                if (listCol != null && listCol.Count > 0)
                                {
                                    oasformsinfomodel.OASFormNameInfoGUID = commobj.GetKeyValueInEntityString(listCol[0]);
                                }

                            }
                            else
                            {
                                IReadOnlyList<Key> listCol = await commobj.Common_InsertDataIntoDataStore_Async(oasformsinfomodel, listinsert, datastoreDb, info, this);

                                if (listCol != null && listCol.Count > 0)
                                {
                                    oasformsinfomodel.OASFormNameInfoGUID = commobj.GetKeyValueInEntityString(listCol[0]);
                                }
                            }

                        }
                    }
                }
            }
            finally
            {

            }
            return response;
        }


        #endregion



        #region "     DELETE ORGANIZATION DETAILS       "
        /// <summary>
        /// THIS METHOD IS USEFUL IN DELETING THE ORGANIZATION DETAILS
        /// </summary>
        /// <param name="loginModel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> DeleteFormsInfoDetails(OASFormsInfoModel oasformsinfomodel)
        {
            ResponseModel response = null;
            DatastoreDb datastoreDb = null;
            string kindName = string.Empty;
            KeyFactory keyFactory = null;


            try
            {
                using (CommonBusinessAccess commobj = new CommonBusinessAccess())
                {
                    //create data store db instance
                    datastoreDb = commobj.BuildRequiredPropertiesForGoogleDataStore();

                    //get the kind name
                    kindName = commobj.GetKindNameBasedOnPracticeID(OASDataStoreKind.OASFormsInfo, oasformsinfomodel.orgmodel.OrganizationID);

                    //creating the key factory instance to generate new key for kind entitty
                    keyFactory = datastoreDb.CreateKeyFactory(kindName);

                    if (!string.IsNullOrEmpty(oasformsinfomodel.OASFormNameInfoGUID))
                    {

                        Key key = keyFactory.CreateKey(Convert.ToInt64(oasformsinfomodel.OASFormNameInfoGUID));

                        //looking or searching with key in kind
                        Entity entity = await datastoreDb.LookupAsync(key);

                        if (entity != null)
                        {
                            //setting the values
                            commobj.setEntityIntValue(ref entity, "Status", (int)OASDataStatus.InactiveData, false);

                            //setting the centralized log values
                            commobj.setCommonEntityProperties(ref entity, (oasformsinfomodel as BaseModel), null, true);

                            using (GoogleDataStoreInputInfo info = new GoogleDataStoreInputInfo())
                            {
                                List<Entity> listinsert = new List<Entity>();

                                listinsert.Add(entity);
                                commobj.Common_UpdateDataIntoDataStore(oasformsinfomodel, listinsert, datastoreDb, info, this);
                            }
                        }
                    }
                }
            }
            finally
            {

            }
            return response;
        }
        #endregion


        #region "     ORGANZAITON DETAILS LIST          "
        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING   ORGANZAITON DETAILS LIST      
        /// </summary>
        /// <returns></returns>
        public async Task<OASFormsInfoModel> GetFormsInfoList(OASFormsInfoModel oasformsinfomodel)
        {
            OASFormsInfoModel responsemodel = null;
            DatastoreDb datastoredb = null;
            string KindName = string.Empty;

            try
            {
                //ehrcommondatastoremodel.emrwebexceptiontracelogmodel.AddToExecutionLog("EHRGoogleDataStore.BusinessAccess", "PracticeInfoConfigBusinessAccess", "AppServersList", "AppServersList Start", ExecutionLogType.Detail);

                using (CommonBusinessAccess commonbusinessaccess = new CommonBusinessAccess())
                {
                    //creating the data store db connection instance
                    datastoredb = commonbusinessaccess.BuildRequiredPropertiesForGoogleDataStore();

                    //getting the kind name
                    KindName = commonbusinessaccess.GetKindNameBasedOnPracticeID(OASDataStoreKind.OASFormsInfo, oasformsinfomodel.orgmodel.OrganizationID);

                    Query query = new Query(KindName)
                    {
                        Filter = Filter.Equal("Status", (int)OASDataStatus.ActiveData)
                    };


                    //RUNNING THE QUERY IN DB AND GETTING THE RESULTING ENTITIES LIST
                    List<Entity> OutputEntity = datastoredb.RunQuery(query).Entities.ToList();

                    responsemodel = new OASFormsInfoModel();

                    responsemodel.oasformsinfomodel = new OASFormsInfoModel();

                    responsemodel.oasformsinfomodelList = new List<OASFormsInfoModel>();



                    //LOOPING ON ALL THE RESULTS AND FORMING THE REQUIRED LIST OBJECTS
                    foreach (Entity newentity in OutputEntity)
                    {
                        OASFormsInfoModel modelObj = new OASFormsInfoModel();


                        #region "   GETTING THE ENTITY VALUES GENERATED USING TOOL       "

                        modelObj.OASFormNameInfoGUID = commonbusinessaccess.GetKeyValueInEntityString(newentity);

                        modelObj.OASFormName = commonbusinessaccess.GetStringValueFromEntity(newentity, "OASFormName");

                        modelObj.OASFormNameKindName = commonbusinessaccess.GetStringValueFromEntity(newentity, "OASFormNameKindName");

                        modelObj.OASFormNameTypeID = commonbusinessaccess.GetInt64ValueFromEntity(newentity, "OASFormNameTypeID");


                        #endregion

                        responsemodel.oasformsinfomodelList.Add(modelObj);
                    }
                }
            }
            finally
            {

            }

            return responsemodel;
        }

        #endregion


        #region "     ADD OR UPDATE ORGANIZATION DETAILS       "
        /// <summary>
        /// THIS METHOD IS USEFUL IN INSERT OR UPDATE THE ORGANIZATION INFO
        /// </summary>
        /// <param name="loginModel"></param>
        /// <returns></returns>
        /// 
        public async Task<ResponseModel> SaveAndUpdateFieldsInformation(OASFieldsInformationModel oasfieldsinformationmode)
        {
            ResponseModel response = null;
            DatastoreDb datastoreDb = null;
            string kindName = string.Empty;
            KeyFactory keyFactory = null;
            Entity entity = null;
            Boolean isEditMode = false;

            try
            {
                using (CommonBusinessAccess commobj = new CommonBusinessAccess())
                {
                    //create data store db instance
                    datastoreDb = commobj.BuildRequiredPropertiesForGoogleDataStore();

                    //get the kind name
                    kindName = commobj.GetKindNameBasedOnPracticeID(OASDataStoreKind.OASFieldsInformation, oasfieldsinformationmode.orgmodel.OrganizationID);

                    //creating the key factory instance to generate new key for kind entitty
                    keyFactory = datastoreDb.CreateKeyFactory(kindName);

                    if (!string.IsNullOrEmpty(oasfieldsinformationmode.OASFieldNameInfoGUID))
                    {
                        Key key = keyFactory.CreateKey(Convert.ToInt64(oasfieldsinformationmode.OASFieldNameInfoGUID));

                        //looking or searching with key in kind
                        entity = await datastoreDb.LookupAsync(key);

                        isEditMode = true;
                    }
                    else
                    {
                        Query query = new Query(kindName)
                        {
                            Filter = Filter.And(Filter.Equal("OASFiledName", oasfieldsinformationmode.OASFiledName),
                                                    Filter.Equal("Status", (int)OASDataStatus.ActiveData))
                        };

                        List<Entity> list = datastoreDb.RunQuery(query).Entities.ToList();

                        if (list != null && list.Count > 0)
                        {
                            var isFound = false;

                            foreach (Entity itemEnt in list)
                            {
                                if (commobj.GetBooleanValueFromEntity(itemEnt, "Status"))
                                {

                                }
                                else
                                    isFound = true;
                            }

                            if (isFound)
                            {
                                response = new ResponseModel();
                                response.RequestExecutionStatus = -2;
                                response.ErrorMessage = "Field Name Already Exists";
                            }
                            else
                            {
                                entity = new Entity()
                                {

                                };
                                entity.Key = keyFactory.CreateIncompleteKey();
                            }
                        }
                        else
                        {
                            entity = new Entity()
                            {

                            };
                            entity.Key = keyFactory.CreateIncompleteKey();
                        }

                    }


                    if (entity != null)
                    {
                        //setting the values
                        commobj.setEntityStringValue(ref entity, "OASFiledName", oasfieldsinformationmode.OASFiledName, true, true);

                        commobj.setEntityIntValue(ref entity, "OASFiledsGroupID", oasfieldsinformationmode.OASFiledsGroupID, false);

                        commobj.setEntityIntValue(ref entity, "OASFiledTypeID", commobj.GetAdminDateTime_Int_UTC(), false);

                        commobj.setEntityStringValue(ref entity, "OASFormNameInfoID", oasfieldsinformationmode.OASFormNameInfoID, false, false);

                        commobj.setEntityIntValue(ref entity, "Status", (int)OASDataStatus.ActiveData, false);
                        //commobj.setEntityBooleanValue(ref entity, "Inactive", false, false);

                        //setting the centralized log values
                        commobj.setCommonEntityProperties(ref entity, (oasfieldsinformationmode as BaseModel), null, isEditMode);


                        List<Entity> listinsert = new List<Entity>();

                        listinsert.Add(entity);


                        using (GoogleDataStoreInputInfo info = new GoogleDataStoreInputInfo())
                        {

                            if (isEditMode)
                            {
                                IReadOnlyList<Key> listCol = await commobj.Common_UpdateDataIntoDataStore_Async(oasfieldsinformationmode, listinsert, datastoreDb, info, this);

                                if (listCol != null && listCol.Count > 0)
                                {
                                    oasfieldsinformationmode.OASFieldNameInfoGUID = commobj.GetKeyValueInEntityString(listCol[0]);
                                }

                            }
                            else
                            {
                                IReadOnlyList<Key> listCol = await commobj.Common_InsertDataIntoDataStore_Async(oasfieldsinformationmode, listinsert, datastoreDb, info, this);

                                if (listCol != null && listCol.Count > 0)
                                {
                                    oasfieldsinformationmode.OASFieldNameInfoGUID = commobj.GetKeyValueInEntityString(listCol[0]);
                                }
                            }

                        }
                    }
                }
            }
            finally
            {

            }
            return response;
        }


        #endregion



        #region "     DELETE ORGANIZATION DETAILS       "
        /// <summary>
        /// THIS METHOD IS USEFUL IN DELETING THE ORGANIZATION DETAILS
        /// </summary>
        /// <param name="loginModel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> DeleteFieldsInfoDetails(OASFieldsInformationModel oasfieldsinformationmodel)
        {
            ResponseModel response = null;
            DatastoreDb datastoreDb = null;
            string kindName = string.Empty;
            KeyFactory keyFactory = null;


            try
            {
                using (CommonBusinessAccess commobj = new CommonBusinessAccess())
                {
                    //create data store db instance
                    datastoreDb = commobj.BuildRequiredPropertiesForGoogleDataStore();

                    //get the kind name
                    kindName = commobj.GetKindNameBasedOnPracticeID(OASDataStoreKind.OASFieldsInformation, oasfieldsinformationmodel.orgmodel.OrganizationID);

                    //creating the key factory instance to generate new key for kind entitty
                    keyFactory = datastoreDb.CreateKeyFactory(kindName);

                    if (!string.IsNullOrEmpty(oasfieldsinformationmodel.OASFieldNameInfoGUID))
                    {

                        Key key = keyFactory.CreateKey(Convert.ToInt64(oasfieldsinformationmodel.OASFieldNameInfoGUID));

                        //looking or searching with key in kind
                        Entity entity = await datastoreDb.LookupAsync(key);

                        if (entity != null)
                        {
                            //setting the values
                            commobj.setEntityIntValue(ref entity, "Status", (int)OASDataStatus.InactiveData, false);

                            //setting the centralized log values
                            commobj.setCommonEntityProperties(ref entity, (oasfieldsinformationmodel as BaseModel), null, true);

                            using (GoogleDataStoreInputInfo info = new GoogleDataStoreInputInfo())
                            {
                                List<Entity> listinsert = new List<Entity>();

                                listinsert.Add(entity);
                                commobj.Common_UpdateDataIntoDataStore(oasfieldsinformationmodel, listinsert, datastoreDb, info, this);
                            }
                        }
                    }
                }
            }
            finally
            {

            }
            return response;
        }
        #endregion


        #region "     ORGANZAITON DETAILS LIST          "
        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING   ORGANZAITON DETAILS LIST      
        /// </summary>
        /// <returns></returns>
        public async Task<OASFieldsInformationModel> GetFieldsInfoList(OASFieldsInformationModel oasfieldsinformationmodel)
        {
            OASFieldsInformationModel responsemodel = null;
            DatastoreDb datastoredb = null;
            string KindName = string.Empty;

            try
            {
                //ehrcommondatastoremodel.emrwebexceptiontracelogmodel.AddToExecutionLog("EHRGoogleDataStore.BusinessAccess", "PracticeInfoConfigBusinessAccess", "AppServersList", "AppServersList Start", ExecutionLogType.Detail);

                using (CommonBusinessAccess commonbusinessaccess = new CommonBusinessAccess())
                {
                    //creating the data store db connection instance
                    datastoredb = commonbusinessaccess.BuildRequiredPropertiesForGoogleDataStore();

                    //getting the kind name
                    KindName = commonbusinessaccess.GetKindNameBasedOnPracticeID(OASDataStoreKind.OASFieldsInformation, oasfieldsinformationmodel.orgmodel.OrganizationID);

                    Query query = new Query(KindName)
                    {
                        Filter = Filter.Equal("Status", (int)OASDataStatus.ActiveData)
                    };


                    if (!string.IsNullOrEmpty(oasfieldsinformationmodel.OASFormNameInfoID))
                    {
                        //query.Filter = Filter.And(Filter.Equal("Status", (int)OASDataStatus.ActiveData),
                        //    Filter.Equal("OASFormNameInfoID", Convert.ToInt64(oasfieldsinformationmodel.OASFormNameInfoID)));
                    }


                    //RUNNING THE QUERY IN DB AND GETTING THE RESULTING ENTITIES LIST
                    List<Entity> OutputEntity = datastoredb.RunQuery(query).Entities.ToList();

                    responsemodel = new OASFieldsInformationModel();

                    responsemodel.oasfieldsinformationmodel = new OASFieldsInformationModel();

                    responsemodel.oasfieldsinformationmodelList = new List<OASFieldsInformationModel>();



                    //LOOPING ON ALL THE RESULTS AND FORMING THE REQUIRED LIST OBJECTS
                    foreach (Entity newentity in OutputEntity)
                    {
                        OASFieldsInformationModel modelObj = new OASFieldsInformationModel();


                        #region "   GETTING THE ENTITY VALUES GENERATED USING TOOL       "

                        modelObj.OASFieldNameInfoGUID = commonbusinessaccess.GetKeyValueInEntityString(newentity);

                        modelObj.OASFiledName = commonbusinessaccess.GetStringValueFromEntity(newentity, "OASFiledName");

                        modelObj.OASFiledsGroupID = commonbusinessaccess.GetInt32ValueFromEntity(newentity, "OASFiledsGroupID");

                        modelObj.OASFiledTypeID = commonbusinessaccess.GetInt64ValueFromEntity(newentity, "OASFiledTypeID");

                        modelObj.OASFormNameInfoID = commonbusinessaccess.GetStringValueFromEntity(newentity, "OASFormNameInfoID");


                        #endregion

                        responsemodel.oasfieldsinformationmodelList.Add(modelObj);
                    }


                    if (!string.IsNullOrEmpty(oasfieldsinformationmodel.OASFormNameInfoID))
                    {
                        responsemodel.oasfieldsinformationmodelList = responsemodel.oasfieldsinformationmodelList.Where(item => item.OASFormNameInfoID == oasfieldsinformationmodel.OASFormNameInfoID).ToList();
                    }
                }
            }
            finally
            {

            }

            return responsemodel;
        }

        #endregion


        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {

            }
        }
        #endregion
    }
}
