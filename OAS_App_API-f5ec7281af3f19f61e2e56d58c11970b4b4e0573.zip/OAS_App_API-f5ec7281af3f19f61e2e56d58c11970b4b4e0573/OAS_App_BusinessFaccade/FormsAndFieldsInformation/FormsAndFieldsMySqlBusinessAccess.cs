﻿using OAS_App_Common.Common;
using OAS_App_Common.OASFormsAndFieldsInfo;
using OAS_App_DataAccess.formsandfields;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace OAS_App_BusinessFaccade.FormsAndFieldsInformation
{
    public class FormsAndFieldsMySqlBusinessAccess : IDisposable
    {

        #region "     FORMS DETAILS           "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="oasformsinfomodel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> SaveAndUpdateFormsInformation(OASFormsInfoModel oasformsinfomodel)
        {
            ResponseModel response = null;
            try
            {
                using (FormsAndFieldsDataAccess objAcces = new FormsAndFieldsDataAccess())
                {
                    response = await objAcces.SaveAndUpdateFormsInformation(oasformsinfomodel);
                }
            }
            finally
            {

            }

            return response;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="oasformsinfomodel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> DeleteFormInformation(OASFormsInfoModel oasformsinfomodel)
        {
            ResponseModel response = null;
            try
            {
                using (FormsAndFieldsDataAccess objAcces = new FormsAndFieldsDataAccess())
                {
                    response = await objAcces.DeleteFormInformation(oasformsinfomodel);
                }
            }
            finally
            {

            }

            return response;
        }



        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING   ORGANZAITON DETAILS LIST      
        /// </summary>
        /// <returns></returns>
        public async Task<OASFormsInfoModel> GetFormsInfoList(OASFormsInfoModel oasformsinfomodel)
        {
            OASFormsInfoModel response = null;

            try
            {
                using (FormsAndFieldsDataAccess objAcces = new FormsAndFieldsDataAccess())
                {
                    response = await objAcces.GetFormsInfoList(oasformsinfomodel);
                }
            }
            finally
            {

            }

            return response;
        }
        #endregion

        /// <summary>
        /// BusinessFacade layer to call DataAccess layer
        /// </summary>
        /// <param name="fieldsInformationModel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> SaveAndUpdateFieldsInformation(OASFieldsInformationModel fieldsInformationModel)
        {
            ResponseModel responce = null;

            try
            {
                using (FormsAndFieldsDataAccess objAccess = new FormsAndFieldsDataAccess())
                {
                    responce = await objAccess.SaveAndUpdateFieldsInformation(fieldsInformationModel);
                }
            }
            finally
            {

            }
            return responce;
        }

        /// <summary>
        /// BusinessFacade layer to call data access
        /// </summary>
        /// <param name="fieldsInformationModel"></param> 
        /// <returns></returns>
        public async Task<ResponseModel> DeleteFieldInformation(OASFieldsInformationModel fieldsInformationModel)
        {
            ResponseModel response = null;

            try
            {
                using (FormsAndFieldsDataAccess objAcces = new FormsAndFieldsDataAccess())
                {
                    response = await objAcces.DeleteFieldInformation(fieldsInformationModel);
                }
            }
            finally
            {

            }

            return response;
        }

        /// <summary>
        /// Method is used for getting fields list
        /// </summary>
        /// <param name="fieldsInformationModel"></param>
        /// <returns></returns>
        public async Task<OASFieldsInformationModel> GetFieldsInfoList(OASFieldsInformationModel fieldsInformationModel)
        {
            OASFieldsInformationModel responce = null;

            try
            {
                using (FormsAndFieldsDataAccess objAcces = new FormsAndFieldsDataAccess())
                {
                    responce = await objAcces.GetFieldsInfoList(fieldsInformationModel);
                }
            }
            finally
            {

            }
            return responce;
        }

        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {

            }
        }
        #endregion
    }
}
