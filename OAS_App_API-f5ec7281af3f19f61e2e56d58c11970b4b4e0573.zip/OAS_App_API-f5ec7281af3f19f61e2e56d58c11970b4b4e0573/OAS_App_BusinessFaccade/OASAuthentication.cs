﻿using Google.Cloud.Datastore.V1;

using Newtonsoft.Json;
using OAS_App_BusinessFaccade.Common;
using OAS_App_BusinessFaccade.FormsAndFieldsInformation;
using OAS_App_BusinessFaccade.Organization;
using OAS_App_Common;
using OAS_App_Common.Common;
using OAS_App_Common.Employee;
using OAS_App_Common.OASFormsAndFieldsInfo;
using OAS_App_Common.Organization;
using OAS_App_DataAccess.common;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OAS_App_BusinessFaccade
{
    public class OASAuthentication : IDisposable
    {





        /// <summary>
        /// *******PURPOSE: THIS METHOD IS USEFUL IN AUTHORIZING THE USER BY USER NAME AND PASSWORDS
        ///*******CREATED BY: MAHESH P
        ///*******CREATED DATE: 04/13/2018
        ///*******MODIFIED DEVELOPER: DATE - NAME - WHAT IS MODIFIED; *************************
        /// </summary>
        /// <param name="loginModel"></param>
        /// <returns></returns>
        public async Task<BaseModel> ValidateAuthentication(LoginModel loginModel)
        {
            BaseModel baseModel = null;
            DatastoreDb datastoredb = null;
            string KindName = string.Empty;

            try
            {
                //ehrcommondatastoremodel.emrwebexceptiontracelogmodel.AddToExecutionLog("EHRGoogleDataStore.BusinessAccess", "PracticeInfoConfigBusinessAccess", "AppServersList", "AppServersList Start", ExecutionLogType.Detail);


                baseModel = await GetEmpLoginInfo(loginModel);


                //using (CommonBusinessAccess commonbusinessaccess = new CommonBusinessAccess())
                //{
                //    //creating the data store db connection instance
                //    datastoredb = commonbusinessaccess.BuildRequiredPropertiesForGoogleDataStore();

                //    //getting the kind name
                //    KindName = commonbusinessaccess.GetKindNameBasedOnPracticeID(OASDataStoreKind.UsersLoginsInfo, loginModel.orgmodel.OrganizationID);

                //    //usernameoremailid,password,organizationid,organizationuniqueid,employeeuniqueid,inactive                    

                //    Query query = new Query(KindName)
                //    {
                //        Filter = Filter.Equal("Inactive", false)
                //    };

                //    //RUNNING THE QUERY IN DB AND GETTING THE RESULTING ENTITIES LIST
                //    List<Entity> OutputEntity = datastoredb.RunQuery(query).Entities.ToList();

                //    if (OutputEntity != null && OutputEntity.Count > 0)
                //    {
                //        List<LoginEmployeeInfo> orgslist = new List<LoginEmployeeInfo>();

                //        foreach (Entity newentity in OutputEntity)
                //        {
                //            orgslist.Add(new LoginEmployeeInfo
                //            {
                //                usernameoremailid = commonbusinessaccess.GetStringValueFromEntity(newentity, "UsernameOrEmailid"),
                //                password = commonbusinessaccess.GetStringValueFromEntity(newentity, "Password"),
                //                organizationid = commonbusinessaccess.GetInt32ValueFromEntity(newentity, "OrganizationID"),
                //                organizationgdsuid = commonbusinessaccess.GetStringValueFromEntity(newentity, "OrganizationGDSUID"),
                //                employeegdsuid = commonbusinessaccess.GetStringValueFromEntity(newentity, "EmployeeGDSUID"),
                //                employeeid = commonbusinessaccess.GetInt32ValueFromEntity(newentity, "EmployeeId"),
                //                UserType = commonbusinessaccess.GetInt32ValueFromEntity(newentity, "UserType")
                //            });
                //        }

                //        //checking for the user existence 
                //        orgslist = orgslist.Where(item =>
                //                                        item.usernameoremailid.ToLower() == loginModel.loggeduseremailid.ToLower()
                //                                 //&& item.password == loginModel.loggeduserpassword
                //                                 ).ToList();

                //        //whenever the user has found in the list and is active
                //        if (orgslist != null && orgslist.Count > 0)
                //        {
                //            baseModel = new BaseModel();
                //            baseModel.orgmodel = new OrgModel();
                //            baseModel.orgmodel.LoggedUserID = orgslist[0].employeeid;
                //            baseModel.orgmodel.OrganizationID = orgslist[0].organizationid;
                //            baseModel.orgmodel.LoggedUserEmailAddress = orgslist[0].usernameoremailid;
                //            baseModel.orgmodel.loggedusergdsuid = orgslist[0].employeegdsuid;
                //            baseModel.orgmodel.LoggedUserType = orgslist[0].UserType;

                //            using (OrganizationBusinessAccess orgBusinessAccess = new OrganizationBusinessAccess())
                //            {
                //                using (OrganizationInfo objOrganizationInfo = new OrganizationInfo())
                //                {
                //                    objOrganizationInfo.orgmodel = baseModel.orgmodel;

                //                    OrganizationInfo objOrganizationInfores = await orgBusinessAccess.OASOrganizationList(objOrganizationInfo);

                //                    if (objOrganizationInfores != null && objOrganizationInfores.organizationinfolist != null && objOrganizationInfores.organizationinfolist.Count > 0)
                //                    {
                //                        if (!string.IsNullOrEmpty(baseModel.orgmodel.orggdsuid))
                //                        {
                //                            objOrganizationInfores.organizationinfolist = objOrganizationInfores.organizationinfolist.Where(item =>
                //                                             item.organizationid == baseModel.orgmodel.OrganizationID
                //                                             || item.orggdsuid == baseModel.orgmodel.orggdsuid).ToList();
                //                        }
                //                        else
                //                        {
                //                            objOrganizationInfores.organizationinfolist = objOrganizationInfores.organizationinfolist.Where(item =>
                //                                          item.organizationid == baseModel.orgmodel.OrganizationID).ToList();
                //                        }


                //                        if (objOrganizationInfores.organizationinfolist != null && objOrganizationInfores.organizationinfolist.Count > 0)
                //                        {

                //                            if (objOrganizationInfores.organizationinfolist.Count == 1)
                //                            {
                //                                baseModel.orgmodel.OrganizationName = objOrganizationInfores.organizationinfolist[0].organizationname;
                //                                baseModel.orgmodel.orggdsuid = objOrganizationInfores.organizationinfolist[0].orggdsuid;
                //                            }
                //                            else
                //                            {
                //                                baseModel.orgmodel.OrganizationName = objOrganizationInfores.organizationinfolist[0].organizationname;
                //                                baseModel.orgmodel.orggdsuid = objOrganizationInfores.organizationinfolist[0].orggdsuid;
                //                            }
                //                        }
                //                        else
                //                        {
                //                            baseModel = new BaseModel();
                //                            baseModel.RequestExecutionStatus = -2;
                //                            baseModel.ErrorMessage = "Please Contact Support team.!";
                //                        }
                //                    }
                //                }
                //            }

                //            if (baseModel.RequestExecutionStatus == null || baseModel.RequestExecutionStatus == 0)
                //            {
                //                EmployeeInfo emp = new EmployeeInfo();
                //                emp.orgmodel = baseModel.orgmodel;

                //                EmployeeInfo empresult = await GetEmployeeInfo(emp);

                //                if (empresult != null)
                //                {
                //                    //checking whether the password is correct or not
                //                    if (empresult.password == commonbusinessaccess.GetHashData(loginModel.loggeduserpassword))
                //                    {
                //                        baseModel.orgmodel.LoggedUserEmailAddress = empresult.emailaddress;
                //                        baseModel.orgmodel.LoggedUserName = empresult.empname;
                //                        baseModel.orgmodel.LoggedUserID = empresult.userid;
                //                        baseModel.orgmodel.clientsessioninfo = loginModel.orgmodel.clientsessioninfo;

                //                        baseModel = insertAndGetClientUniqueInformationAsync(baseModel);

                //                        //baseModel.orgmodel.clientsessioninfo.ClientExternalIPAddress = 
                //                    }
                //                    else
                //                    {
                //                        baseModel = new BaseModel();
                //                        baseModel.RequestExecutionStatus = -2;
                //                        baseModel.ErrorMessage = "Please Enter Valid Password";
                //                    }
                //                }
                //                else
                //                {
                //                    baseModel = new BaseModel();
                //                    baseModel.RequestExecutionStatus = -2;
                //                    baseModel.ErrorMessage = "Please Enter Valid Credentials";
                //                }
                //            }
                //        }

                //    }
                //}
            }
            finally
            {

            }



            return baseModel;
        }



        /// <summary>
        /// *******PURPOSE: THIS METHOD IS USEFUL IN AUTHORIZING THE USER BY USER ID
        ///*******CREATED BY: MAHESH P
        ///*******CREATED DATE: 04/13/2018
        ///*******MODIFIED DEVELOPER: DATE - NAME - WHAT IS MODIFIED; *************************
        /// </summary>
        /// <param name="loginModel"></param>
        /// <returns></returns>
        public async Task<BaseModel> ValidateAuthenticationByUserID(LoginModel loginModel)
        {
            BaseModel baseModel = null;

            try
            {

                using (EmployeeAuthorization EmployeeAuthorizationObj = new EmployeeAuthorization())
                {
                    baseModel = await EmployeeAuthorizationObj.GetEmployeeInfoByUserId(loginModel);
                }

            }
            finally
            {

            }

            return baseModel;
        }



        #region "     EMPLOYEES DETAILS LIST          "
        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING   APPSERVERS DETAILS LIST      
        /// </summary>
        /// <returns></returns>
        public async Task<EmployeeInfo> GetEmployeeInfo(EmployeeInfo employeeinfo)
        {
            EmployeeInfo responsemodel = null;
            DatastoreDb datastoredb = null;
            string KindName = string.Empty;
            KeyFactory keyFactory = null;

            try
            {
                using (CommonBusinessAccess commonbusinessaccess = new CommonBusinessAccess())
                {
                    //creating the data store db connection instance
                    datastoredb = commonbusinessaccess.BuildRequiredPropertiesForGoogleDataStore();

                    //getting the kind name
                    KindName = commonbusinessaccess.GetKindNameBasedOnPracticeID(OASDataStoreKind.EmployeesInfo, employeeinfo.orgmodel.OrganizationID);

                    keyFactory = datastoredb.CreateKeyFactory(KindName);

                    Entity newentity = await datastoredb.LookupAsync(keyFactory.CreateKey(Convert.ToInt64(employeeinfo.orgmodel.loggedusergdsuid)));

                    if (newentity != null)
                    {
                        if (!commonbusinessaccess.GetBooleanValueFromEntity(newentity, "inactive"))
                        {
                            responsemodel = new EmployeeInfo();


                            #region "   GETTING THE ENTITY VALUES GENERATED USING TOOL       "

                            responsemodel.empgdsuid = commonbusinessaccess.GetKeyValueInEntityString(newentity);

                            responsemodel.userid = commonbusinessaccess.GetInt32ValueFromEntity(newentity, "EmployeeId");

                            responsemodel.empname = commonbusinessaccess.GetStringValueFromEntity(newentity, "EmployeeName");

                            responsemodel.emailaddress = commonbusinessaccess.GetStringValueFromEntity(newentity, "EmailAddress");

                            responsemodel.gender = commonbusinessaccess.GetInt32ValueFromEntity(newentity, "Gender");

                            responsemodel.dob = commonbusinessaccess.GetStringValueFromEntity(newentity, "DOB");

                            responsemodel.password = commonbusinessaccess.GetStringValueFromEntity(newentity, "Password");

                            #endregion

                        }
                    }
                }
            }
            finally
            {

            }

            return responsemodel;
        }

        #endregion





        /// <summary>
        /// THIS METHOD IS USEFUL IN SAVING OR UPDATING THE META DETAILS OF THE FORM
        /// </summary>
        /// <param name="commonsavingmodel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> SaveFormData(CommonSavingModel commonsavingmodel)
        {
            ResponseModel responsemodel = null;
            DatastoreDb datastoredb = null;
            string KindName = string.Empty;
            KeyFactory keyFactory = null;
            KeyFactory keyFactory_Hx = null;
            long currentRecordID = 0;
            try
            {

                using (CommonBusinessAccess commonbusinessaccess = new CommonBusinessAccess())
                {
                    //creating the data store db connection instance
                    datastoredb = commonbusinessaccess.BuildRequiredPropertiesForGoogleDataStore();

                    //getting the kind name
                    KindName = commonbusinessaccess.GetKindNameBasedOnPracticeID(OASDataStoreKind.DynamicForm,
                                                        commonsavingmodel.orgmodel.OrganizationID,
                                                       Convert.ToInt64(commonsavingmodel.FormID));

                    //creating the factory for the normal kind
                    keyFactory = datastoredb.CreateKeyFactory(KindName);

                    //creating the factory for the normal kind_hx
                    keyFactory_Hx = datastoredb.CreateKeyFactory(KindName + "_Hx");

                    //creating the list need to insert in the normal kind
                    List<Entity> entitiesToInsert = new List<Entity>();

                    //creating the list need to insert in the normal kind_hx
                    List<Entity> entitiesToInsert_Hx = new List<Entity>();

                    if (commonsavingmodel != null && commonsavingmodel.CommonSavingRowData != null && commonsavingmodel.CommonSavingRowData.CommonSavingFieldsData.Count > 0)
                    {

                        currentRecordID = 0;

                        //looping on all the saving input dat to form saving entities list
                        foreach (CommonSavingFieldsModel itemToInsert in commonsavingmodel.CommonSavingRowData.CommonSavingFieldsData)
                        {
                            //creating the entity instance to insert in the list
                            Entity entity = new Entity();

                            //instance for previous data key
                            Key keyStateMaintained = null;

                            //checking for the previous key
                            if (itemToInsert.RecordKeyGDSUID > 0)
                            {
                                //checking for the previous existence of th entity
                                keyStateMaintained = keyFactory.CreateKey(itemToInsert.RecordKeyGDSUID);

                                //setting the key as previous one
                                entity.Key = keyStateMaintained;

                                //getting the 
                                Entity entityPrevious = await datastoredb.LookupAsync(keyStateMaintained);

                                //adding to the hx list to maintain the HX
                                if (entityPrevious != null)
                                {
                                    //setting the got value from data store 
                                    entity = entityPrevious.Clone();

                                    //creationg the new key for HX record
                                    entityPrevious.Key = keyFactory_Hx.CreateIncompleteKey();

                                    //adding the data to the HX
                                    entitiesToInsert_Hx.Add(entityPrevious);
                                }
                                else//if the key was not found in the list means that the data has corrupted
                                    continue;
                            }
                            else
                            {  //getting the current Record ID
                                currentRecordID = commonbusinessaccess.GetRandomNumber_DateUTC_Int();
                                //creating the key for the current entity field data
                                entity.Key = keyFactory.CreateIncompleteKey();
                            }

                            //setting the current inserting the record id 
                            itemToInsert.RecordID = itemToInsert.RecordID > 0 ? itemToInsert.RecordID : currentRecordID;

                            //setting one record value, if there are multiple fields
                            commonbusinessaccess.setEntityIntValue(ref entity, "RecordID", itemToInsert.RecordID, false);

                            //setting the field id
                            commonbusinessaccess.setEntityIntValue(ref entity, "FieldID", itemToInsert.FieldID, false);

                            //setting the field value based on data type
                            if (itemToInsert.FieldValue != null)
                            {
                                string dataType = itemToInsert.FieldValue.GetType().ToString().ToLower();

                                if (dataType.IndexOf("int") > -1)
                                {
                                    commonbusinessaccess.setEntityIntValue(ref entity, "FieldValue", Convert.ToInt64(itemToInsert.FieldValue), false);
                                }
                                else if (dataType.IndexOf("bool") > -1)
                                {
                                    commonbusinessaccess.setEntityIntValue(ref entity, "FieldValue", Convert.ToBoolean(itemToInsert.FieldValue) ? 0 : 1, false);
                                }
                                else if (dataType.IndexOf("string") > -1)
                                {
                                    commonbusinessaccess.setEntityStringValue(ref entity, "FieldValue", Convert.ToString(itemToInsert.FieldValue), true, false);
                                }
                                else
                                    commonbusinessaccess.setEntityStringValue(ref entity, "FieldValue", Convert.ToString(itemToInsert.FieldValue), true, false);
                            }
                            else
                                commonbusinessaccess.setEntityStringValue(ref entity, "FieldValue", null, true, false);

                            //setting the rownumber of the field
                            commonbusinessaccess.setEntityIntValue(ref entity, "RowNumber", itemToInsert.RowNumber, false);

                            //setting the column number of the field
                            commonbusinessaccess.setEntityIntValue(ref entity, "ColumnNumber", itemToInsert.ColumnNumber, false);

                            //setting the group id of the field
                            commonbusinessaccess.setEntityIntValue(ref entity, "FieldGroupID", itemToInsert.FieldGroupID, false);

                            //setting the status of the data
                            commonbusinessaccess.setEntityIntValue(ref entity, "Staus", (int)OASDataStatus.ActiveData, false);

                            //setting the common log data here
                            commonbusinessaccess.setCommonEntityProperties(ref entity, (commonsavingmodel as BaseModel), null, itemToInsert.RecordKeyGDSUID > 0);

                            //adding the field data to list to save in data store
                            entitiesToInsert.Add(entity);
                        }
                    }

                    //creating the transaction 
                    using (DatastoreTransaction transaction = await datastoredb.BeginTransactionAsync())
                    {
                        //inserting or updating the data 
                        if (entitiesToInsert != null && entitiesToInsert.Count > 0)
                        {
                            transaction.Upsert(entitiesToInsert);
                        }

                        if (entitiesToInsert_Hx != null && entitiesToInsert_Hx.Count > 0)
                            transaction.Insert(entitiesToInsert_Hx);

                        await transaction.CommitAsync();
                    }

                }
            }
            finally
            {

            }
            return responsemodel;
        }




        /// <summary>
        /// THIS METHOD IS USEFUL IN SAVING OR UPDATING THE META DETAILS OF THE FORM
        /// </summary>
        /// <param name="commonsavingmodel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> SaveFormData_bkp(CommonSavingModel commonsavingmodel)
        {
            ResponseModel responsemodel = null;
            DatastoreDb datastoredb = null;
            string KindName = string.Empty;
            KeyFactory keyFactory = null;
            KeyFactory keyFactory_Hx = null;
            try
            {


                using (CommonBusinessAccess commonbusinessaccess = new CommonBusinessAccess())
                {
                    //creating the data store db connection instance
                    datastoredb = commonbusinessaccess.BuildRequiredPropertiesForGoogleDataStore();

                    //getting the kind name
                    KindName = commonbusinessaccess.GetKindNameBasedOnPracticeID(OASDataStoreKind.DynamicForm,
                                                        commonsavingmodel.orgmodel.OrganizationID,
                                                       Convert.ToInt64(commonsavingmodel.FormID));

                    keyFactory = datastoredb.CreateKeyFactory(KindName);

                    keyFactory_Hx = datastoredb.CreateKeyFactory(KindName + "_Hx");

                    List<Entity> entitiesToInsert = new List<Entity>();
                    List<Entity> entitiesToInsert_Hx = new List<Entity>();

                    if (commonsavingmodel != null && commonsavingmodel.CommonSavingFieldsData != null && commonsavingmodel.CommonSavingFieldsData.Count > 0)
                    {
                        Int64 groupNumberRow = commonbusinessaccess.GetAdminDateTime_Int_UTC();

                        foreach (CommonSavingFieldsModel itemToInsert in commonsavingmodel.CommonSavingFieldsData)
                        {
                            Entity entity = new Entity();
                            Key keyStateMaintained = null;

                            if (!string.IsNullOrEmpty(itemToInsert.RecordGDSUID))
                            {
                                keyStateMaintained = keyFactory.CreateKey(Convert.ToInt64(itemToInsert.RecordGDSUID));

                                entity.Key = keyStateMaintained;

                                Entity entityPrevious = await datastoredb.LookupAsync(keyStateMaintained);

                                //adding to the hx list to maintain the HX
                                if (entityPrevious != null)
                                {
                                    entity = entityPrevious;
                                    entityPrevious.Key = keyFactory_Hx.CreateIncompleteKey();
                                    entitiesToInsert_Hx.Add(entityPrevious);
                                }
                                else
                                    continue;
                            }
                            else
                                entity.Key = keyFactory.CreateIncompleteKey();

                            commonbusinessaccess.setEntityIntValue(ref entity, "FieldID", itemToInsert.FieldID, false);
                            //commonbusinessaccess.setEntityStringValue(ref entity, "FieldValue", itemToInsert.FieldValue, true, false);

                            commonbusinessaccess.setEntityIntValue(ref entity, "FieldGroupID", itemToInsert.FieldGroupID > 0 ? itemToInsert.FieldGroupID : groupNumberRow, false);


                            commonbusinessaccess.setEntityIntValue(ref entity, "FieldSeqNumber", itemToInsert.FieldSeqNumber, false);
                            commonbusinessaccess.setEntityIntValue(ref entity, "Staus", (int)OASDataStatus.ActiveData, false);

                            if (itemToInsert.RecordID > 0)
                                commonbusinessaccess.setEntityIntValue(ref entity, "RecordID", itemToInsert.RecordID, false);
                            else
                                commonbusinessaccess.setEntityIntValue(ref entity, "RecordID", commonbusinessaccess.GetAdminDateTime_Int_UTC(), false);

                            commonbusinessaccess.setCommonEntityProperties(ref entity, (commonsavingmodel as BaseModel), null, !string.IsNullOrEmpty(itemToInsert.RecordGDSUID));

                            entitiesToInsert.Add(entity);
                        }
                    }

                    if (entitiesToInsert != null && entitiesToInsert.Count > 0)
                    {
                        using (DatastoreTransaction transaction = await datastoredb.BeginTransactionAsync())
                        {
                            transaction.Upsert(entitiesToInsert);

                            if (entitiesToInsert_Hx != null && entitiesToInsert_Hx.Count > 0)
                                transaction.Insert(entitiesToInsert_Hx);

                            await transaction.CommitAsync();
                        }
                    }

                }
            }
            finally
            {

            }
            return responsemodel;
        }

        /// <summary>
        /// THIS METHOD IS USEFUL IN DELETING THE FORM DATA
        /// </summary>
        /// <param name="commonsavingmodel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> DeleteFormData_bkp(CommonSavingModel commonsavingmodel)
        {
            ResponseModel responsemodel = null;
            DatastoreDb datastoredb = null;
            string KindName = string.Empty;
            KeyFactory keyFactory = null;

            try
            {


                using (CommonBusinessAccess commonbusinessaccess = new CommonBusinessAccess())
                {
                    //creating the data store db connection instance
                    datastoredb = commonbusinessaccess.BuildRequiredPropertiesForGoogleDataStore();

                    //getting the kind name
                    KindName = commonbusinessaccess.GetKindNameBasedOnPracticeID(OASDataStoreKind.DynamicForm,
                                                        commonsavingmodel.orgmodel.OrganizationID,
                                                        Convert.ToInt64(commonsavingmodel.FormID));

                    keyFactory = datastoredb.CreateKeyFactory(KindName);

                    List<Entity> entitiesToInsert = new List<Entity>();

                    if (commonsavingmodel != null && commonsavingmodel.CommonFilterFieldsData != null && commonsavingmodel.CommonFilterFieldsData.FieldGroupID > 0)
                    {

                        Query query = new Query(KindName)
                        {

                        };

                        query.Filter = Filter.And(Filter.Equal("Staus", (int)OASDataStatus.ActiveData),
                                                Filter.Equal("FieldGroupID", commonsavingmodel.CommonFilterFieldsData.FieldGroupID));


                        List<Entity> EntityListResult = datastoredb.RunQueryAsync(query).Result.Entities.ToList();


                        foreach (Entity entityLoop in EntityListResult)
                        {
                            //Entity entity = await datastoredb.LookupAsync(keyFactory.CreateKey(itemToInsert.RecordGDSUID));

                            Entity entity = entityLoop;

                            if (entity != null)
                            {
                                commonbusinessaccess.setEntityIntValue(ref entity, "Staus", (int)OASDataStatus.InactiveData, false);

                                commonbusinessaccess.setCommonEntityProperties(ref entity, (commonsavingmodel as BaseModel), null, true);

                                entitiesToInsert.Add(entity);
                            }
                        }
                    }

                    if (entitiesToInsert != null && entitiesToInsert.Count > 0)
                    {
                        using (DatastoreTransaction transaction = await datastoredb.BeginTransactionAsync())
                        {
                            transaction.Upsert(entitiesToInsert);

                            await transaction.CommitAsync();
                        }
                    }

                }
            }
            finally
            {

            }
            return responsemodel;
        }


        public async Task<ResponseModel> DeleteFormData(CommonSavingModel commonsavingmodel)
        {
            ResponseModel responsemodel = null;
            DatastoreDb datastoredb = null;
            string KindName = string.Empty;
            KeyFactory keyFactory = null;

            try
            {


                using (CommonBusinessAccess commonbusinessaccess = new CommonBusinessAccess())
                {
                    //creating the data store db connection instance
                    datastoredb = commonbusinessaccess.BuildRequiredPropertiesForGoogleDataStore();

                    //getting the kind name
                    KindName = commonbusinessaccess.GetKindNameBasedOnPracticeID(OASDataStoreKind.DynamicForm,
                                                        commonsavingmodel.orgmodel.OrganizationID,
                                                        Convert.ToInt64(commonsavingmodel.FormID));

                    keyFactory = datastoredb.CreateKeyFactory(KindName);

                    List<Entity> entitiesToInsert = new List<Entity>();

                    if (commonsavingmodel != null && commonsavingmodel.CommonSavingRowData != null && commonsavingmodel.CommonSavingRowData.RecordID > 0)
                    {

                        Query query = new Query(KindName)
                        {

                        };

                        query.Filter = Filter.And(Filter.Equal("Staus", (int)OASDataStatus.ActiveData),
                                                Filter.Equal("RecordID", commonsavingmodel.CommonSavingRowData.RecordID));


                        List<Entity> EntityListResult = datastoredb.RunQueryAsync(query).Result.Entities.ToList();


                        foreach (Entity entityLoop in EntityListResult)
                        {
                            //Entity entity = await datastoredb.LookupAsync(keyFactory.CreateKey(itemToInsert.RecordGDSUID));

                            Entity entity = entityLoop;

                            if (entity != null)
                            {
                                commonbusinessaccess.setEntityIntValue(ref entity, "Staus", (int)OASDataStatus.InactiveData, false);

                                commonbusinessaccess.setCommonEntityProperties(ref entity, (commonsavingmodel as BaseModel), null, true);

                                entitiesToInsert.Add(entity);
                            }
                        }
                    }

                    if (entitiesToInsert != null && entitiesToInsert.Count > 0)
                    {
                        using (DatastoreTransaction transaction = await datastoredb.BeginTransactionAsync())
                        {
                            transaction.Update(entitiesToInsert);

                            await transaction.CommitAsync();
                        }
                    }

                }
            }
            finally
            {

            }
            return responsemodel;
        }

        /// <summary>
        ///  THIS METHOD IS USEFUL GETTING THE LIST DATA TO SHOW IN THE VIEW
        /// </summary>
        /// <param name="commonsavingmodel"></param>
        /// <returns></returns>
        public async Task<CommonSavingModel> GetFormData_List_bkp(CommonSavingModel commonsavingmodel)
        {
            CommonSavingModel responsemodel = null;
            DatastoreDb datastoredb = null;
            string KindName = string.Empty;
            StringBuilder sbReportData = null;
            StringBuilder sbReportColumnsData = null;
            StringWriter swReportData = null;
            OASFieldsInformationModel oasfieldsinformationmodelres = null;
            DataTable dataTableReports = null;
            DataTable dataTable = null;
            try
            {

                using (CommonBusinessAccess commonbusinessaccess = new CommonBusinessAccess())
                {
                    //creating the data store db connection instance
                    datastoredb = commonbusinessaccess.BuildRequiredPropertiesForGoogleDataStore();

                    //getting the kind name
                    KindName = commonbusinessaccess.GetKindNameBasedOnPracticeID(OASDataStoreKind.DynamicForm,
                                                        commonsavingmodel.orgmodel.OrganizationID,
                                                      Convert.ToInt64(commonsavingmodel.FormID));

                    using (FormsAndFieldsInfoBusinesAcess FormsAndFieldsInfoBusinesAcessObj = new FormsAndFieldsInfoBusinesAcess())
                    {
                        using (OASFieldsInformationModel oasfieldsinformationmodel = new OASFieldsInformationModel())
                        {
                            oasfieldsinformationmodel.orgmodel = commonsavingmodel.orgmodel;
                            oasfieldsinformationmodel.OASFormNameInfoID = commonsavingmodel.FormID;
                            oasfieldsinformationmodelres = await FormsAndFieldsInfoBusinesAcessObj.GetFieldsInfoList(oasfieldsinformationmodel);
                        }
                    }



                    KeyFactory keyFactory = datastoredb.CreateKeyFactory(KindName);

                    Query query = new Query(KindName)
                    {

                    };

                    if (commonsavingmodel.CommonFilterFieldsData != null)
                    {
                        if (!string.IsNullOrEmpty(commonsavingmodel.CommonFilterFieldsData.RecordGDSUID))
                        {
                            query.Filter = Filter.And(Filter.Equal("Staus", (int)OASDataStatus.ActiveData),
                                Filter.Equal("__key__", keyFactory.CreateKey(Convert.ToInt64(commonsavingmodel.CommonFilterFieldsData.RecordGDSUID))));
                        }
                    }
                    else
                        query.Filter = Filter.And(Filter.Equal("Staus", (int)OASDataStatus.ActiveData));


                    List<Entity> entitiesResult = datastoredb.RunQueryAsync(query).Result.Entities.ToList();

                    if (entitiesResult != null && entitiesResult.Count > 0)
                    {
                        responsemodel = new CommonSavingModel();
                        responsemodel.CommonSavingFieldsData = new List<CommonSavingFieldsModel>();

                        sbReportData = new StringBuilder();
                        //sb.Append("{");
                        swReportData = new StringWriter(sbReportData);

                        dataTable = new DataTable();
                        dataTable.Columns.Add("FieldID");
                        dataTable.Columns.Add("FieldValue");
                        dataTable.Columns.Add("FieldGroupID");
                        dataTable.Columns.Add("FieldSeqNumber");
                        dataTable.Columns.Add("RecordID");
                        dataTable.Columns.Add("RecordGDSUID");



                        using (JsonWriter jsonWriter = new JsonTextWriter(swReportData))
                        {
                            jsonWriter.WriteStartArray();

                            foreach (Entity Entityitem in entitiesResult)
                            {
                                DataRow dataRow = dataTable.NewRow();

                                CommonSavingFieldsModel commonSavingFieldsModel = new CommonSavingFieldsModel();

                                commonSavingFieldsModel.FieldID = commonbusinessaccess.GetInt64ValueFromEntity(Entityitem, "FieldID");
                                commonSavingFieldsModel.FieldValue = commonbusinessaccess.GetStringValueFromEntity(Entityitem, "FieldValue");
                                commonSavingFieldsModel.FieldGroupID = commonbusinessaccess.GetInt64ValueFromEntity(Entityitem, "FieldGroupID");
                                commonSavingFieldsModel.FieldSeqNumber = commonbusinessaccess.GetInt32ValueFromEntity(Entityitem, "FieldSeqNumber");
                                commonSavingFieldsModel.RecordID = commonbusinessaccess.GetInt64ValueFromEntity(Entityitem, "RecordID");
                                commonSavingFieldsModel.RecordGDSUID = commonbusinessaccess.GetKeyValueInEntityString(Entityitem);

                                dataRow["FieldID"] = commonSavingFieldsModel.FieldID;
                                dataRow["FieldValue"] = commonSavingFieldsModel.FieldValue;
                                dataRow["FieldGroupID"] = commonSavingFieldsModel.FieldGroupID;
                                dataRow["FieldSeqNumber"] = commonSavingFieldsModel.FieldSeqNumber;
                                dataRow["RecordID"] = commonSavingFieldsModel.RecordID;
                                dataRow["RecordGDSUID"] = commonSavingFieldsModel.RecordGDSUID;

                                dataTable.Rows.Add(dataRow);

                                responsemodel.CommonSavingFieldsData.Add(commonSavingFieldsModel);

                            }

                            dataTable.AcceptChanges();


                            dataTableReports = new DataTable();


                            if (oasfieldsinformationmodelres != null
                                && oasfieldsinformationmodelres.oasfieldsinformationmodelList != null
                                && oasfieldsinformationmodelres.oasfieldsinformationmodelList.Count > 0)
                            {

                                sbReportColumnsData = new StringBuilder();

                                using (JsonWriter jsonWriterCols = new JsonTextWriter(new StringWriter(sbReportColumnsData)))
                                {
                                    jsonWriterCols.WriteStartArray();
                                    foreach (var item in oasfieldsinformationmodelres.oasfieldsinformationmodelList)
                                    {
                                        jsonWriterCols.WriteStartObject();

                                        dataTableReports.Columns.Add("c_" + item.OASFieldNameInfoGUID.ToString());

                                        jsonWriterCols.WritePropertyName("data");//  { data: 'organizationid', width: '200px', title: 'Organization ID' },
                                        jsonWriterCols.WriteValue("c_" + item.OASFieldNameInfoGUID.ToString());

                                        jsonWriterCols.WritePropertyName("title");//  { data: 'organizationid', width: '200px', title: 'Organization ID' },
                                        jsonWriterCols.WriteValue(item.OASFiledName);


                                        jsonWriterCols.WriteEndObject();
                                    }
                                    jsonWriterCols.WriteEndArray();
                                }

                                DataTable uniqueCols = dataTable.DefaultView.ToTable(true, "FieldGroupID");

                                foreach (DataRow itemCurrentUniqueRow in uniqueCols.Rows)
                                {
                                    DataRow[] dataRowCollectionFilteredForCurrentRow = dataTable.Select("FieldGroupID='" + itemCurrentUniqueRow[0] + "'");

                                    DataRow targetRow = dataTableReports.NewRow();

                                    jsonWriter.WriteStartObject();


                                    jsonWriter.WritePropertyName("FieldGroupID");

                                    jsonWriter.WriteValue(itemCurrentUniqueRow[0].ToString());


                                    foreach (DataRow itemCurrentRowData in dataRowCollectionFilteredForCurrentRow)
                                    {
                                        targetRow["c_" + itemCurrentRowData["FieldID"].ToString()] = itemCurrentRowData["FieldValue"];

                                        jsonWriter.WritePropertyName("c_" + itemCurrentRowData["FieldID"].ToString());

                                        jsonWriter.WriteValue(itemCurrentRowData["FieldValue"].ToString());

                                    }

                                    jsonWriter.WriteEndObject();

                                    dataTableReports.Rows.Add(targetRow);
                                }

                                dataTableReports.AcceptChanges();
                            }

                            jsonWriter.WriteEndArray();
                        }

                        //responsemodel.CommonSavingFieldsData = responsemodel.CommonSavingFieldsData.OrderBy(item => item.RecordID).ToList();

                        responsemodel.gridData = sbReportData.ToString();

                        responsemodel.columnsData = sbReportColumnsData.ToString();//  { data: 'organizationid', width: '200px', title: 'Organization ID' },

                        responsemodel.CommonSavingFieldsData = null;

                    }

                }
            }
            finally
            {
                sbReportData = null;
                swReportData = null;
                sbReportColumnsData = null;
                if (dataTable != null)
                    dataTable.Dispose();

                if (dataTableReports != null)
                    dataTableReports.Dispose();

            }
            return responsemodel;
        }


        /// <summary>
        /// THIS METHOD IS USEFUL IN SEARCHING THE ENTITIES WITH FILTERS DATA
        /// </summary>
        /// <param name="commonsavingmodel"></param>
        /// <param name="KindName"></param>
        /// <param name="datastoredb"></param>
        /// <param name="listEntityResult"></param>
        /// <param name="index"></param>
        /// <returns></returns>
        public async Task<List<Entity>> GetEntitiesByApplyingFilters(CommonSavingModel commonsavingmodel,
            string KindName, DatastoreDb datastoredb, List<Entity> listEntityResult, int index)
        {
            try
            {
                //checking for the filters list
                if (commonsavingmodel.CommonSearchFilterFieldsData != null
                        && commonsavingmodel.CommonSearchFilterFieldsData.Count > 0
                        && commonsavingmodel.CommonSearchFilterFieldsData.Count > index)
                {
                    if (commonsavingmodel.CommonSearchFilterFieldsData[index].FieldValue != null)
                    {
                        Query query = new Query(KindName)
                        {

                        };

                        if ((FilterMode)commonsavingmodel.CommonSearchFilterFieldsData[index].FilterMode == FilterMode.EQUALS)
                        {
                            query.Filter = Filter.And(Filter.Equal("Staus", (int)OASDataStatus.ActiveData),
                                        Filter.Equal("FieldID", commonsavingmodel.CommonSearchFilterFieldsData[index].FieldID),
                                        Filter.Equal("FieldValue", commonsavingmodel.CommonSearchFilterFieldsData[index].FieldValue.ToString()));

                        }
                        else if ((FilterMode)commonsavingmodel.CommonSearchFilterFieldsData[index].FilterMode == FilterMode.STARTSWITH)
                        {
                            query.Filter = Filter.And(Filter.Equal("Staus", (int)OASDataStatus.ActiveData),
                                                      Filter.Equal("FieldID", commonsavingmodel.CommonSearchFilterFieldsData[index].FieldID),
                                                      Filter.GreaterThanOrEqual("FieldValue", commonsavingmodel.CommonSearchFilterFieldsData[index].FieldValue.ToString()));
                        }

                        List<Entity> entitiesResult = datastoredb.RunQueryAsync(query).Result.Entities.ToList();

                        if (entitiesResult != null && entitiesResult.Count > 0)
                        {
                            listEntityResult = listEntityResult.Concat(entitiesResult).ToList();
                        }

                        await GetEntitiesByApplyingFilters(commonsavingmodel, KindName, datastoredb, listEntityResult, index + 1);
                    }
                    else
                        await GetEntitiesByApplyingFilters(commonsavingmodel, KindName, datastoredb, listEntityResult, index + 1);
                }
                else if (commonsavingmodel.CommonSearchFilterFieldsData != null
                        && commonsavingmodel.CommonSearchFilterFieldsData.Count > 0
                        && commonsavingmodel.CommonSearchFilterFieldsData.Count <= index)
                {
                    //when all search filters completed



                }
                else
                {
                    Query query = new Query(KindName)
                    {

                    };

                    query.Filter = Filter.And(Filter.Equal("Staus", (int)OASDataStatus.ActiveData));

                    List<Entity> entitiesResult = datastoredb.RunQueryAsync(query).Result.Entities.ToList();

                    if (entitiesResult != null && entitiesResult.Count > 0)
                    {
                        listEntityResult = listEntityResult.Concat(entitiesResult).ToList();
                    }
                }
            }
            finally
            {

            }

            return listEntityResult;
        }



        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING THE FORMS LIST
        /// </summary>
        /// <param name="commonsavingmodel"></param>
        /// <returns></returns>
        public async Task<CommonSavingModel> GetFormData_List(CommonSavingModel commonsavingmodel)
        {
            CommonSavingModel responsemodel = null;
            DatastoreDb datastoredb = null;
            string KindName = string.Empty;
            StringBuilder sbReportData = null;
            StringBuilder sbReportColumnsData = null;
            StringWriter swReportData = null;
            OASFieldsInformationModel oasfieldsinformationmodelres = null;
            DataTable dataTableReports = null;
            DataTable dataTable = null;
            try
            {

                using (CommonBusinessAccess commonbusinessaccess = new CommonBusinessAccess())
                {
                    //creating the data store db connection instance
                    datastoredb = commonbusinessaccess.BuildRequiredPropertiesForGoogleDataStore();

                    //getting the kind name
                    KindName = commonbusinessaccess.GetKindNameBasedOnPracticeID(OASDataStoreKind.DynamicForm,
                                                        commonsavingmodel.orgmodel.OrganizationID,
                                                      Convert.ToInt64(commonsavingmodel.FormID));

                    using (FormsAndFieldsInfoBusinesAcess FormsAndFieldsInfoBusinesAcessObj = new FormsAndFieldsInfoBusinesAcess())
                    {
                        using (OASFieldsInformationModel oasfieldsinformationmodel = new OASFieldsInformationModel())
                        {
                            oasfieldsinformationmodel.orgmodel = commonsavingmodel.orgmodel;
                            oasfieldsinformationmodel.OASFormNameInfoID = commonsavingmodel.FormID;
                            oasfieldsinformationmodelres = await FormsAndFieldsInfoBusinesAcessObj.GetFieldsInfoList(oasfieldsinformationmodel);
                        }
                    }



                    //KeyFactory keyFactory = datastoredb.CreateKeyFactory(KindName);

                    //Query query = new Query(KindName)
                    //{

                    //};

                    //if (commonsavingmodel.CommonFilterFieldsData != null)
                    //{
                    //    if (commonsavingmodel.CommonFilterFieldsData.RecordKeyGDSUID > 0)
                    //    {
                    //        query.Filter = Filter.And(Filter.Equal("Staus", (int)OASDataStatus.ActiveData),
                    //            Filter.Equal("__key__", keyFactory.CreateKey(commonsavingmodel.CommonFilterFieldsData.RecordKeyGDSUID)));
                    //    }

                    //}
                    //else if (commonsavingmodel.CommonSearchFilterFieldsData != null
                    //    && commonsavingmodel.CommonSearchFilterFieldsData.Count > 0)
                    //{

                    //    if (commonsavingmodel.CommonSearchFilterFieldsData[0].FieldValue != null)
                    //    {

                    //        query.Filter = Filter.And(Filter.Equal("Staus", (int)OASDataStatus.ActiveData),
                    //            Filter.Equal("FieldID", commonsavingmodel.CommonSearchFilterFieldsData[0].FieldID),
                    //            Filter.GreaterThanOrEqual("FieldValue", commonsavingmodel.CommonSearchFilterFieldsData[0].FieldValue.ToString()));

                    //    }
                    //}

                    //else
                    //    query.Filter = Filter.And(Filter.Equal("Staus", (int)OASDataStatus.ActiveData));


                    //List<Entity> entitiesResult = datastoredb.RunQueryAsync(query).Result.Entities.ToList();

                    List<Entity> entitiesResult = new List<Entity>();

                    entitiesResult = await GetEntitiesByApplyingFilters(commonsavingmodel, KindName, datastoredb, entitiesResult, 0);

                    if (entitiesResult != null && entitiesResult.Count > 0)
                    {
                        responsemodel = new CommonSavingModel();
                        responsemodel.CommonSavingFieldsData = new List<CommonSavingFieldsModel>();

                        sbReportData = new StringBuilder();
                        //sb.Append("{");
                        swReportData = new StringWriter(sbReportData);

                        dataTable = new DataTable();
                        dataTable.Columns.Add("FieldID");
                        dataTable.Columns.Add("FieldValue");
                        dataTable.Columns.Add("FieldGroupID");
                        dataTable.Columns.Add("RowNumber");
                        dataTable.Columns.Add("ColumnNumber");
                        dataTable.Columns.Add("RecordID");
                        dataTable.Columns.Add("RecordKeyGDSUID");



                        using (JsonWriter jsonWriter = new JsonTextWriter(swReportData))
                        {
                            jsonWriter.WriteStartArray();

                            foreach (Entity Entityitem in entitiesResult)
                            {
                                DataRow dataRow = dataTable.NewRow();

                                CommonSavingFieldsModel commonSavingFieldsModel = new CommonSavingFieldsModel();

                                commonSavingFieldsModel.FieldID = commonbusinessaccess.GetInt64ValueFromEntity(Entityitem, "FieldID");
                                commonSavingFieldsModel.FieldValue = commonbusinessaccess.GetStringValueFromEntity(Entityitem, "FieldValue");
                                commonSavingFieldsModel.FieldGroupID = commonbusinessaccess.GetInt64ValueFromEntity(Entityitem, "FieldGroupID");
                                commonSavingFieldsModel.ColumnNumber = commonbusinessaccess.GetInt64ValueFromEntity(Entityitem, "RowNumber");
                                commonSavingFieldsModel.RowNumber = commonbusinessaccess.GetInt64ValueFromEntity(Entityitem, "ColumnNumber");
                                commonSavingFieldsModel.RecordID = commonbusinessaccess.GetInt64ValueFromEntity(Entityitem, "RecordID");
                                commonSavingFieldsModel.RecordGDSUID = commonbusinessaccess.GetKeyValueInEntityString(Entityitem);
                                commonSavingFieldsModel.RecordKeyGDSUID = commonbusinessaccess.GetKeyValueInEntityInt(Entityitem);

                                dataRow["FieldID"] = commonSavingFieldsModel.FieldID;
                                dataRow["FieldValue"] = commonSavingFieldsModel.FieldValue;
                                dataRow["FieldGroupID"] = commonSavingFieldsModel.FieldGroupID;
                                dataRow["ColumnNumber"] = commonSavingFieldsModel.ColumnNumber;
                                dataRow["RowNumber"] = commonSavingFieldsModel.RowNumber;
                                dataRow["RecordID"] = commonSavingFieldsModel.RecordID;
                                dataRow["RecordKeyGDSUID"] = commonSavingFieldsModel.RecordGDSUID;

                                dataTable.Rows.Add(dataRow);

                                responsemodel.CommonSavingFieldsData.Add(commonSavingFieldsModel);

                            }

                            dataTable.AcceptChanges();


                            dataTableReports = new DataTable();


                            if (oasfieldsinformationmodelres != null
                                && oasfieldsinformationmodelres.oasfieldsinformationmodelList != null
                                && oasfieldsinformationmodelres.oasfieldsinformationmodelList.Count > 0)
                            {

                                sbReportColumnsData = new StringBuilder();

                                using (JsonWriter jsonWriterCols = new JsonTextWriter(new StringWriter(sbReportColumnsData)))
                                {
                                    jsonWriterCols.WriteStartArray();
                                    foreach (var item in oasfieldsinformationmodelres.oasfieldsinformationmodelList)
                                    {
                                        jsonWriterCols.WriteStartObject();

                                        dataTableReports.Columns.Add("c_" + item.OASFieldNameInfoGUID.ToString());

                                        jsonWriterCols.WritePropertyName("data");//  { data: 'organizationid', width: '200px', title: 'Organization ID' },
                                        jsonWriterCols.WriteValue("c_" + item.OASFieldNameInfoGUID.ToString());

                                        jsonWriterCols.WritePropertyName("title");//  { data: 'organizationid', width: '200px', title: 'Organization ID' },
                                        jsonWriterCols.WriteValue(item.OASFiledName);


                                        jsonWriterCols.WriteEndObject();
                                    }
                                    jsonWriterCols.WriteEndArray();
                                }

                                DataTable uniqueCols = dataTable.DefaultView.ToTable(true, "RecordID");

                                foreach (DataRow itemCurrentUniqueRow in uniqueCols.Rows)
                                {
                                    DataRow[] dataRowCollectionFilteredForCurrentRow = dataTable.Select("RecordID='" + itemCurrentUniqueRow[0] + "'");

                                    DataRow targetRow = dataTableReports.NewRow();

                                    jsonWriter.WriteStartObject();

                                    jsonWriter.WritePropertyName("RecordID");

                                    jsonWriter.WriteValue(itemCurrentUniqueRow[0].ToString());

                                    foreach (DataRow itemCurrentRowData in dataRowCollectionFilteredForCurrentRow)
                                    {
                                        targetRow["c_" + itemCurrentRowData["FieldID"].ToString()] = itemCurrentRowData["FieldValue"];

                                        jsonWriter.WritePropertyName("c_" + itemCurrentRowData["FieldID"].ToString());

                                        jsonWriter.WriteValue(itemCurrentRowData["FieldValue"].ToString());

                                    }

                                    jsonWriter.WriteEndObject();

                                    dataTableReports.Rows.Add(targetRow);
                                }

                                dataTableReports.AcceptChanges();
                            }

                            jsonWriter.WriteEndArray();
                        }

                        //responsemodel.CommonSavingFieldsData = responsemodel.CommonSavingFieldsData.OrderBy(item => item.RecordID).ToList();

                        responsemodel.gridData = sbReportData.ToString();

                        responsemodel.columnsData = sbReportColumnsData.ToString();//  { data: 'organizationid', width: '200px', title: 'Organization ID' },

                        responsemodel.CommonSavingFieldsData = null;

                    }

                }
            }
            finally
            {
                sbReportData = null;
                swReportData = null;
                sbReportColumnsData = null;
                if (dataTable != null)
                    dataTable.Dispose();

                if (dataTableReports != null)
                    dataTableReports.Dispose();

            }
            return responsemodel;
        }

        /// <summary>
        ///  THIS METHOD IS USEFUL IN GETTING THE STATE MAINTAIN MODE INFORMATION
        /// </summary>
        /// <param name="commonsavingmodel"></param>
        /// <returns></returns>
        public async Task<CommonSavingModel> GetFormData_List_EditMode_bkp(CommonSavingModel commonsavingmodel)
        {
            CommonSavingModel responsemodel = null;
            DatastoreDb datastoredb = null;
            string KindName = string.Empty;

            try
            {

                using (CommonBusinessAccess commonbusinessaccess = new CommonBusinessAccess())
                {
                    //creating the data store db connection instance
                    datastoredb = commonbusinessaccess.BuildRequiredPropertiesForGoogleDataStore();

                    //getting the kind name
                    KindName = commonbusinessaccess.GetKindNameBasedOnPracticeID(OASDataStoreKind.DynamicForm,
                                                        commonsavingmodel.orgmodel.OrganizationID,
                                                       Convert.ToInt64(commonsavingmodel.FormID));

                    KeyFactory keyFactory = datastoredb.CreateKeyFactory(KindName);

                    Query query = new Query(KindName)
                    {

                    };

                    if (commonsavingmodel.CommonFilterFieldsData != null)
                    {
                        if (commonsavingmodel.CommonFilterFieldsData.FieldGroupID > 0)
                        {
                            query.Filter = Filter.And(Filter.Equal("Staus", (int)OASDataStatus.ActiveData),
                                Filter.Equal("FieldGroupID", commonsavingmodel.CommonFilterFieldsData.FieldGroupID)
                                /*Filter.Equal("__key__", keyFactory.CreateKey(commonsavingmodel.CommonFilterFieldsData.RecordGDSUID))*/);
                        }
                    }
                    else
                        query.Filter = Filter.And(Filter.Equal("Staus", (int)OASDataStatus.ActiveData));


                    List<Entity> entitiesResult = datastoredb.RunQueryAsync(query).Result.Entities.ToList();

                    if (entitiesResult != null && entitiesResult.Count > 0)
                    {
                        responsemodel = new CommonSavingModel();
                        responsemodel.CommonSavingFieldsData = new List<CommonSavingFieldsModel>();

                        foreach (Entity Entityitem in entitiesResult)
                        {

                            CommonSavingFieldsModel commonSavingFieldsModel = new CommonSavingFieldsModel();

                            commonSavingFieldsModel.FieldID = commonbusinessaccess.GetInt64ValueFromEntity(Entityitem, "FieldID");
                            commonSavingFieldsModel.FieldValue = commonbusinessaccess.GetStringValueFromEntity(Entityitem, "FieldValue");
                            commonSavingFieldsModel.FieldGroupID = commonbusinessaccess.GetInt64ValueFromEntity(Entityitem, "FieldGroupID");
                            commonSavingFieldsModel.FieldSeqNumber = commonbusinessaccess.GetInt32ValueFromEntity(Entityitem, "FieldSeqNumber");
                            commonSavingFieldsModel.RecordID = commonbusinessaccess.GetInt64ValueFromEntity(Entityitem, "RecordID");
                            commonSavingFieldsModel.RecordGDSUID = commonbusinessaccess.GetKeyValueInEntityString(Entityitem);

                            responsemodel.CommonSavingFieldsData.Add(commonSavingFieldsModel);
                        }

                        responsemodel.CommonSavingFieldsData = responsemodel.CommonSavingFieldsData.OrderBy(item => item.RecordID).ToList();
                    }

                }
            }
            finally
            {

            }
            return responsemodel;
        }




        public async Task<CommonSavingModel> GetFormData_List_EditMode(CommonSavingModel commonsavingmodel)
        {
            CommonSavingModel responsemodel = null;
            DatastoreDb datastoredb = null;
            string KindName = string.Empty;

            try
            {

                using (CommonBusinessAccess commonbusinessaccess = new CommonBusinessAccess())
                {
                    //creating the data store db connection instance
                    datastoredb = commonbusinessaccess.BuildRequiredPropertiesForGoogleDataStore();

                    //getting the kind name
                    KindName = commonbusinessaccess.GetKindNameBasedOnPracticeID(OASDataStoreKind.DynamicForm,
                                                        commonsavingmodel.orgmodel.OrganizationID,
                                                       Convert.ToInt64(commonsavingmodel.FormID));

                    KeyFactory keyFactory = datastoredb.CreateKeyFactory(KindName);

                    Query query = new Query(KindName)
                    {

                    };

                    if (commonsavingmodel.CommonFilterFieldsData != null)
                    {
                        if (commonsavingmodel.CommonFilterFieldsData.RecordID > 0)
                        {
                            query.Filter = Filter.And(Filter.Equal("Staus", (int)OASDataStatus.ActiveData),
                                Filter.Equal("RecordID", commonsavingmodel.CommonFilterFieldsData.RecordID)
                                /*Filter.Equal("__key__", keyFactory.CreateKey(commonsavingmodel.CommonFilterFieldsData.RecordGDSUID))*/);
                        }
                    }
                    else
                        query.Filter = Filter.And(Filter.Equal("Staus", (int)OASDataStatus.ActiveData));


                    List<Entity> entitiesResult = datastoredb.RunQueryAsync(query).Result.Entities.ToList();

                    if (entitiesResult != null && entitiesResult.Count > 0)
                    {
                        responsemodel = new CommonSavingModel();
                        //responsemodel.CommonSavingFieldsData = new List<CommonSavingFieldsModel>();

                        responsemodel.CommonSavingRowData = new CommonSavingRowsFieldsModel();

                        responsemodel.CommonSavingRowData.CommonSavingFieldsData = new List<CommonSavingFieldsModel>();

                        foreach (Entity Entityitem in entitiesResult)
                        {

                            CommonSavingFieldsModel commonSavingFieldsModel = new CommonSavingFieldsModel();

                            commonSavingFieldsModel.FieldID = commonbusinessaccess.GetInt64ValueFromEntity(Entityitem, "FieldID");
                            commonSavingFieldsModel.FieldValue = commonbusinessaccess.GetStringValueFromEntity(Entityitem, "FieldValue");
                            commonSavingFieldsModel.FieldGroupID = commonbusinessaccess.GetInt64ValueFromEntity(Entityitem, "FieldGroupID");
                            commonSavingFieldsModel.RowNumber = commonbusinessaccess.GetInt32ValueFromEntity(Entityitem, "RowNumber");
                            commonSavingFieldsModel.ColumnNumber = commonbusinessaccess.GetInt32ValueFromEntity(Entityitem, "ColumnNumber");
                            commonSavingFieldsModel.RecordID = commonbusinessaccess.GetInt64ValueFromEntity(Entityitem, "RecordID");
                            commonSavingFieldsModel.RecordGDSUID = commonbusinessaccess.GetKeyValueInEntityString(Entityitem);
                            commonSavingFieldsModel.RecordKeyGDSUID = commonbusinessaccess.GetKeyValueInEntityInt(Entityitem);

                            responsemodel.CommonSavingRowData.CommonSavingFieldsData.Add(commonSavingFieldsModel);
                        }

                        responsemodel.CommonSavingRowData.CommonSavingFieldsData = responsemodel.CommonSavingRowData.CommonSavingFieldsData.OrderBy(item => item.RecordID).ToList();
                    }

                }
            }
            finally
            {

            }
            return responsemodel;
        }



        public async Task<ResponseModel> UpdateFormData(CommonSavingModel commonsavingmodel)
        {
            ResponseModel responsemodel = null;
            DatastoreDb datastoredb = null;
            string KindName = string.Empty;
            KeyFactory keyFactory = null;

            try
            {


                using (CommonBusinessAccess commonbusinessaccess = new CommonBusinessAccess())
                {
                    //creating the data store db connection instance
                    datastoredb = commonbusinessaccess.BuildRequiredPropertiesForGoogleDataStore();

                    //getting the kind name
                    KindName = commonbusinessaccess.GetKindNameBasedOnPracticeID(OASDataStoreKind.DynamicForm,
                                                        commonsavingmodel.orgmodel.OrganizationID,
                                                        Convert.ToInt64(commonsavingmodel.FormID));

                    keyFactory = datastoredb.CreateKeyFactory(KindName);

                    List<Entity> entitiesToInsert = new List<Entity>();

                    if (commonsavingmodel != null && commonsavingmodel.CommonSavingFieldsData != null && commonsavingmodel.CommonSavingFieldsData.Count > 0)
                    {
                        foreach (CommonSavingFieldsModel itemToInsert in commonsavingmodel.CommonSavingFieldsData)
                        {
                            Entity entity = new Entity();

                            entity.Key = keyFactory.CreateKey(Convert.ToInt64(itemToInsert.RecordGDSUID));

                            commonbusinessaccess.setEntityIntValue(ref entity, "FieldID", itemToInsert.FieldID, false);
                            //commonbusinessaccess.setEntityStringValue(ref entity, "FieldValue", itemToInsert.FieldValue, true, false);
                            commonbusinessaccess.setEntityIntValue(ref entity, "FieldGroupID", itemToInsert.FieldGroupID, false);
                            commonbusinessaccess.setEntityIntValue(ref entity, "FieldSeqNumber", itemToInsert.FieldSeqNumber, false);
                            commonbusinessaccess.setEntityIntValue(ref entity, "Staus", (int)OASDataStatus.ActiveData, false);

                            if (itemToInsert.RecordID > 0)
                                commonbusinessaccess.setEntityIntValue(ref entity, "RecordID", itemToInsert.RecordID, false);
                            else
                                commonbusinessaccess.setEntityIntValue(ref entity, "RecordID", commonbusinessaccess.GetAdminDateTime_Int_UTC(), false);

                            commonbusinessaccess.setCommonEntityProperties(ref entity, (commonsavingmodel as BaseModel), null, true);

                            entitiesToInsert.Add(entity);
                        }
                    }

                    if (entitiesToInsert != null && entitiesToInsert.Count > 0)
                    {
                        using (DatastoreTransaction transaction = await datastoredb.BeginTransactionAsync())
                        {
                            transaction.Upsert(entitiesToInsert);

                            await transaction.CommitAsync();
                        }
                    }

                }
            }
            finally
            {

            }
            return responsemodel;
        }





        internal BaseModel insertAndGetClientUniqueInformationAsync(BaseModel loginModel)
        {

            DatastoreDb datastoredb = null;
            string KindName = string.Empty;
            KeyFactory keyFactory = null;

            try
            {
                using (CommonBusinessAccess commonbusinessaccess = new CommonBusinessAccess())
                {

                    if (loginModel != null && loginModel.orgmodel != null && loginModel.orgmodel.clientsessioninfo != null
                        && (!string.IsNullOrEmpty(loginModel.orgmodel.clientsessioninfo.ClientLocalIPAddress)
                        || !string.IsNullOrEmpty(loginModel.orgmodel.clientsessioninfo.ClientExternalIPAddress)))
                    {

                        //creating the data store db connection instance
                        datastoredb = commonbusinessaccess.BuildRequiredPropertiesForGoogleDataStore();

                        //getting the kind name
                        KindName = commonbusinessaccess.GetKindNameBasedOnPracticeID(OASDataStoreKind.ClientSessionsIPInfo, 0);

                        //creating the key factory in the kind to genearate new keys
                        keyFactory = datastoredb.CreateKeyFactory(KindName);

                        Entity entity = new Entity();

                        if (loginModel.orgmodel.clientsessioninfo.ClientSessionGDSUID > 0)
                        {
                            entity.Key = keyFactory.CreateKey(loginModel.orgmodel.clientsessioninfo.ClientSessionGDSUID);
                        }
                        else
                            entity.Key = keyFactory.CreateIncompleteKey();

                        Int64 objectInsertedId = 0;

                        if (loginModel.orgmodel.clientsessioninfo.ClientSessionInfoID > 0)
                            objectInsertedId = loginModel.orgmodel.clientsessioninfo.ClientSessionInfoID;
                        else
                            objectInsertedId = commonbusinessaccess.GetAdminDateTime_Int_UTC();

                        commonbusinessaccess.setEntityStringValue(ref entity, "ClientLocalIPAddress", loginModel.orgmodel.clientsessioninfo.ClientLocalIPAddress, true, false);
                        commonbusinessaccess.setEntityStringValue(ref entity, "ClientExternalIPAddress", loginModel.orgmodel.clientsessioninfo.ClientExternalIPAddress, false, false);
                        commonbusinessaccess.setEntityStringValue(ref entity, "ClientAspLocalIPAddress", loginModel.orgmodel.clientsessioninfo.ClientAspLocalIPAddress, false, false);
                        commonbusinessaccess.setEntityIntValue(ref entity, "ClientSessionInfoID", objectInsertedId, false);

                        //setting the common properties with add/edit mode
                        commonbusinessaccess.setCommonEntityProperties(ref entity, loginModel, null, loginModel.orgmodel.clientsessioninfo.ClientSessionGDSUID > 0);

                        List<Entity> entityList = new List<Entity>();
                        entityList.Add(entity);


                        using (GoogleDataStoreInputInfo input = new GoogleDataStoreInputInfo())
                        {
                            input.MethodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
                            commonbusinessaccess.Common_UpdateDataIntoDataStore(loginModel, entityList, datastoredb, input, this);
                        }


                        loginModel.orgmodel.clientsessioninfo.ClientSessionGDSUID = commonbusinessaccess.GetKeyValueInEntityInt(entity);
                        loginModel.orgmodel.clientsessioninfo.ClientSessionInfoID = objectInsertedId;

                    }
                }
            }
            finally
            {

            }

            return loginModel;
        }




        /// <summary>
        /// 
        /// </summary>
        /// <param name="baseModel"></param>
        /// <returns></returns>
        public async Task<BaseModel> GetEmpLoginInfo(LoginModel baseModel)
        {
            BaseModel responseModel = null;

            try
            {
                using (CommonDataAccess common = new CommonDataAccess())
                {
                    responseModel = await common.GetEmployeeInfo(baseModel);
                }
            }
            finally
            {

            }

            return responseModel;
        }


        #region "     NAV MENUS LIST     "
        /// <summary>
        /// THIS METHOD IS USEFUL GETTING THE LIST DATA TO NAV MENUS
        /// </summary>
        /// <param name="commonsavingmodel"></param>
        /// <returns></returns>
        public async Task<List<NavMenusModel>> GetNavMenus_List(NavMenusModel navmenusmodel)
        {
            List<NavMenusModel> responseModelList = null;
            var modeltoReturn = new List<NavMenusModel>();
            try
            {
                using (CommonDataAccess common = new CommonDataAccess())
                {
                    responseModelList = await common.GetNavMenus_List(navmenusmodel);

                    modeltoReturn = new List<NavMenusModel>();

                    if (navmenusmodel.IsFromQuickAdd == false)
                    {

                        if (responseModelList != null && responseModelList.Count > 0)
                        {
                            modeltoReturn = (from item in responseModelList where item.MenuParentInfoID == -1 || item.MenuParentInfoID == 0 && item.MenuPosition != 2 select item).ToList();

                            for (int index = 0; index < modeltoReturn.Count; index++)
                            {
                                var childlist = new List<NavMenusModel>();

                                childlist = (from item in responseModelList where item.MenuParentInfoID == modeltoReturn[index].MenuInfoID select item).ToList();

                                if (childlist != null && childlist.Count > 0)
                                {
                                    modeltoReturn[index].NavMenusSubModelsList = childlist;
                                    //modeltoReturn[index].MenuComponentName = childlist[0].MenuComponentName;
                                    //modeltoReturn[index].MenuName = childlist[0].MenuName;
                                    //Assigning the first dash board sub menu route name to parent route name
                                    //modeltoReturn[index].routename = childlist[0].routename;
                                }

                            }
                        }
                    }
                    else
                    {
                        if (responseModelList != null && responseModelList.Count > 0)
                        {
                            modeltoReturn = (from item in responseModelList where item.MenuParentInfoID > 0 && item.MenuPosition != 1 select item).ToList();

                            for (int index = 0; index < modeltoReturn.Count; index++)
                            {
                                var childlist = new List<NavMenusModel>();

                                childlist = (from item in responseModelList where item.MenuParentInfoID == modeltoReturn[index].MenuInfoID select item).ToList();

                                if (childlist != null && childlist.Count > 0)
                                {
                                    modeltoReturn[index].NavMenusSubModelsList = childlist;
                                    //modeltoReturn[index].MenuComponentName = childlist[0].MenuComponentName;
                                    //modeltoReturn[index].MenuName = childlist[0].MenuName;
                                    //Assigning the first dash board sub menu route name to parent route name
                                    //modeltoReturn[index].routename = childlist[0].routename;
                                }

                            }
                        }
                    }

                }
            }
            finally
            {

            }

            return modeltoReturn;
        }

        #endregion

        #region "     NAV MENUS LIST     "
        /// <summary>
        /// THIS METHOD IS USEFUL GETTING THE LIST DATA TO NAV MENUS
        /// </summary>
        /// <param name="commonsavingmodel"></param>
        /// <returns></returns>
        public async Task<List<NavMenusModel>> GetNavMenusInfoList(NavMenusModel navmenusmodel)
        {
            List<NavMenusModel> responseModelList = null;
            var modeltoReturn = new List<NavMenusModel>();
            try
            {
                using (CommonDataAccess common = new CommonDataAccess())
                {
                    navmenusmodel.IsFromCustomization = true;
                    responseModelList = await common.GetNavMenus_List(navmenusmodel);
                    if (navmenusmodel.IsFromAddEditMenusInfo == true)
                    {
                        if (responseModelList != null && responseModelList.Count > 0)
                        {
                            responseModelList = (from item in responseModelList where item.MenuParentInfoID == -1 || item.MenuParentInfoID == 0 select item).ToList();
                        }
                    }
                }
            }
            finally
            {

            }

            return responseModelList;
        }

        #endregion

        #region "     ADD OR UPDATE MENUS INFORMATION     "
        /// <summary>
        /// THIS METHOD IS USEFUL IN ADDING OR UPDATING MENUS INFORMATION    
        /// </summary>
        /// <param name="ehrcommondatastoremodel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> SaveAndUpdateMenusInformation(NavMenusModel navmenusmodel)
        {
            ResponseModel response = null;
            try
            {
                using (CommonDataAccess common = new CommonDataAccess())
                {
                    response = await common.SaveAndUpdateMenusInformation(navmenusmodel);
                }
            }
            finally
            {

            }

            return response;
        }
        #endregion

        #region "     DELETE MENUS INFORMATION     "
        /// <summary>
        /// THIS METHOD IS USEFUL IN ADDING OR UPDATING MENUS INFORMATION    
        /// </summary>
        /// <param name="ehrcommondatastoremodel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> DeleteMenusInformation(NavMenusModel navmenusmodel)
        {
            ResponseModel response = null;
            try
            {
                using (CommonDataAccess common = new CommonDataAccess())
                {
                    response = await common.DeleteMenusInformation(navmenusmodel);
                }
            }
            finally
            {

            }

            return response;
        }
        #endregion



        #region "   GET LINKED NAV MENUS LIST     "
        /// <summary>
        /// THIS METHOD IS USEFUL TO GET LINKED NAV MENUS LIST
        /// </summary>
        /// <param name="commonsavingmodel"></param>
        /// <returns></returns>
        public async Task<List<UserCustomizationNavMenusModel>> GetUserLinkedNavMenus_List(UserCustomizationNavMenusModel usercustomizationnavmenusmodel)
        {
            List<UserCustomizationNavMenusModel> responseModelList = null;
            var modeltoReturn = new List<UserCustomizationNavMenusModel>();
            try
            {
                using (CommonDataAccess common = new CommonDataAccess())
                {
                    responseModelList = await common.GetUserLinkedNavMenus_List(usercustomizationnavmenusmodel);

                }
            }
            finally
            {

            }

            return responseModelList;
        }

        #endregion

        #region "     ADD OR UPDATE CUSTOMIZED MENUS INFORMATION     "
        /// <summary>
        /// THIS METHOD IS USEFUL IN ADDING OR UPDATING MENUS INFORMATION    
        /// </summary>
        /// <param name="ehrcommondatastoremodel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> SaveAndUpdateCustomizedMenusInformation(UserCustomizationNavMenusModel usercustomizationnavmenusmodel)
        {
            ResponseModel response = null;
            try
            {
                using (CommonDataAccess common = new CommonDataAccess())
                {
                    response = await common.SaveAndUpdateCustomizedMenusInformation(usercustomizationnavmenusmodel);
                }
            }
            finally
            {

            }

            return response;
        }
        #endregion


        #region "    GET PROJECTS STATUS LIST INFORMATION     "
        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING PROJECTS STATUS LIST INFORMATION
        /// </summary>
        /// <param name="ehrcommondatastoremodel"></param>
        /// <returns></returns>
        public async Task<List<ProjectsStatusModel>> GetProjectsStausList(ProjectsStatusModel projectsstatusmodel)
        {
            List<ProjectsStatusModel> responseModelList = null;
            var modeltoReturn = new List<UserCustomizationNavMenusModel>();
            try
            {
                using (CommonDataAccess common = new CommonDataAccess())
                {
                    responseModelList = await common.GetProjectsStausList(projectsstatusmodel);

                }
            }
            finally
            {

            }

            return responseModelList;
        }

        #endregion

        #region "   GET LINKED NAV MENUS LIST BASED ON ROLE    "
        /// <summary>
        /// THIS METHOD IS USEFUL TO GET LINKED NAV MENUS LIST
        /// </summary>
        /// <param name="commonsavingmodel"></param>
        /// <returns></returns>
        public async Task<List<UserCustomizationNavMenusModel>> GetNavMenusListBasedonRole(UserCustomizationNavMenusModel usercustomizationnavmenusmodel)
        {
            List<UserCustomizationNavMenusModel> responseModelList = null;
            var modeltoReturn = new List<UserCustomizationNavMenusModel>();
            try
            {
                using (CommonDataAccess common = new CommonDataAccess())
                {
                    responseModelList = await common.GetUserLinkedNavMenus_List(usercustomizationnavmenusmodel);

                    modeltoReturn = new List<UserCustomizationNavMenusModel>();

                    if (usercustomizationnavmenusmodel.IsFromQuickAdd == false)
                    {

                        if (responseModelList != null && responseModelList.Count > 0)
                        {
                            modeltoReturn = (from item in responseModelList where item.MenuParentInfoID == -1 || item.MenuParentInfoID == 0 && item.MenuPosition != 2 select item).ToList();

                            for (int index = 0; index < modeltoReturn.Count; index++)
                            {
                                var childlist = new List<UserCustomizationNavMenusModel>();

                                childlist = (from item in responseModelList where item.MenuParentInfoID == modeltoReturn[index].MenuInfoID select item).ToList();

                                if (childlist != null && childlist.Count > 0)
                                {
                                    modeltoReturn[index].NavMenusSubModelsList = childlist;
                                    //modeltoReturn[index].MenuComponentName = childlist[0].MenuComponentName;
                                    //modeltoReturn[index].MenuName = childlist[0].MenuName;
                                    //Assigning the first dash board sub menu route name to parent route name
                                    //modeltoReturn[index].routename = childlist[0].routename;
                                }

                            }
                        }
                    }
                    else
                    {
                        if (responseModelList != null && responseModelList.Count > 0)
                        {
                            modeltoReturn = (from item in responseModelList where item.MenuParentInfoID == -1 || item.MenuParentInfoID == 0 && item.MenuPosition != 1 select item).ToList();

                            for (int index = 0; index < modeltoReturn.Count; index++)
                            {
                                var childlist = new List<UserCustomizationNavMenusModel>();

                                childlist = (from item in responseModelList where item.MenuParentInfoID == modeltoReturn[index].MenuInfoID select item).ToList();

                                if (childlist != null && childlist.Count > 0)
                                {
                                    modeltoReturn[index].NavMenusSubModelsList = childlist;
                                    //modeltoReturn[index].MenuComponentName = childlist[0].MenuComponentName;
                                    //modeltoReturn[index].MenuName = childlist[0].MenuName;
                                    //Assigning the first dash board sub menu route name to parent route name
                                    //modeltoReturn[index].routename = childlist[0].routename;
                                }

                            }
                        }
                    }
                }
            }
            finally
            {

            }

            return responseModelList;
        }

        #endregion


        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {

            }
        }
        #endregion
    }
}
