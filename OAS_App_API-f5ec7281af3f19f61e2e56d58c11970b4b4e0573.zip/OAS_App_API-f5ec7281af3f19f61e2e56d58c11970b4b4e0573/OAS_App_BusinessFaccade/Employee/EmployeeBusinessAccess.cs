﻿using Google.Cloud.Datastore.V1;
using OAS_App_BusinessFaccade.Common;
using OAS_App_Common;
using OAS_App_Common.Common;
using OAS_App_Common.Employee;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;

namespace OAS_App_BusinessFaccade.Employee
{

    public class EmployeeBusinessAccess : IDisposable
    {

        #region "    ADD OR EDIT EMPLOYEE INFO               "
        /// <summary>
        /// THIS METHOD IS USEFUL IN INSERT OR UPDATE THE EMPLOYEE
        /// </summary>
        /// <param name="loginModel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> AddEditEmployee(EmployeeInfo loginModel)
        {
            ResponseModel response = null;
            DatastoreDb datastoreDb = null;
            string kindName = string.Empty;
            KeyFactory keyFactory = null;
            Entity entity = null;
            Boolean isEditMode = false;

            try
            {
                using (CommonBusinessAccess commobj = new CommonBusinessAccess())
                {
                    //create data store db instance
                    datastoreDb = commobj.BuildRequiredPropertiesForGoogleDataStore();


                    #region "Employee Basic Information"

                    //get the kind name
                    kindName = commobj.GetKindNameBasedOnPracticeID(OASDataStoreKind.EmployeesInfo, loginModel.orgmodel.OrganizationID);

                    //creating the key factory instance to generate new key for kind entitty
                    keyFactory = datastoreDb.CreateKeyFactory(kindName);



                    if (!string.IsNullOrEmpty(loginModel.empgdsuid))
                    {
                        Key keyfound = keyFactory.CreateKey(Convert.ToInt64(loginModel.empgdsuid));

                        entity = await datastoreDb.LookupAsync(keyfound);

                        isEditMode = true;
                    }
                    else
                    {
                        Query query = new Query(kindName)
                        {
                            Filter = Filter.Equal("EmployeeId", loginModel.userid)
                        };

                        List<Entity> list = datastoreDb.RunQuery(query).Entities.ToList();

                        if (list != null && list.Count > 0)
                        {
                            var isFound = false;

                            foreach (Entity itemEnt in list)
                            {
                                if (commobj.GetBooleanValueFromEntity(itemEnt, "InActive"))
                                {

                                }
                                else
                                    isFound = true;
                            }

                            if (isFound)
                            {
                                response = new ResponseModel();
                                response.RequestExecutionStatus = -2;
                                response.ErrorMessage = "User ID Already Exists";
                            }
                            else
                            {
                                entity = new Entity()
                                {

                                };
                                entity.Key = keyFactory.CreateIncompleteKey();
                            }
                        }
                        else
                        {
                            entity = new Entity()
                            {

                            };
                            entity.Key = keyFactory.CreateIncompleteKey();
                        }

                    }


                    if (entity != null)
                    {
                        //setting the values
                        commobj.setEntityIntValue(ref entity, "EmployeeId", loginModel.userid, false);

                        commobj.setEntityStringValue(ref entity, "EmployeeName", loginModel.empname, true, true);

                        commobj.setEntityStringValue(ref entity, "EmailAddress", loginModel.emailaddress, false, false);

                        commobj.setEntityIntValue(ref entity, "Gender", loginModel.gender, false);

                        commobj.setEntityStringValue(ref entity, "employeephonenumber", loginModel.employeephonenumber, false, true);

                        commobj.setEntityStringValue(ref entity, "DOB", loginModel.dob, true, true);

                        commobj.setEntityStringValue(ref entity, "Password", commobj.GetHashData(loginModel.password), false, true);

                        commobj.setEntityIntValue(ref entity, "MaritalStatus", loginModel.employeemaritalstatus, true);

                        commobj.setEntityStringValue(ref entity, "EmployeeAddress", loginModel.employeeaddress, false, true);

                        commobj.setEntityStringValue(ref entity, "EmployeeTags", loginModel.employeetags, false, true);

                        commobj.setEntityIntValue(ref entity, "EmployeeDepartment", loginModel.employeedepartment, true);

                        commobj.setEntityIntValue(ref entity, "EmployeeReportingTo", loginModel.employeereportingto, true);

                        commobj.setEntityIntValue(ref entity, "EmployeeSourceofHire", loginModel.employeesourceofhire, true);

                        commobj.setEntityIntValue(ref entity, "EmployeeType", loginModel.employeetype, true);



                        commobj.setEntityIntValue(ref entity, "EmployeeDesignation", loginModel.employeedesignation, true);

                        commobj.setEntityStringValue(ref entity, "EmployeeWorkNumber", loginModel.employeeworknumber, false, true);

                        commobj.setEntityStringValue(ref entity, "employeejobdescription", loginModel.employeejobdescription, false, true);

                        commobj.setEntityStringValue(ref entity, "DateofExit", loginModel.dateofexit, true, true);


                        commobj.setEntityBooleanValue(ref entity, "Inactive", false, false);


                        commobj.setEntityIntValue(ref entity, "UserType", Convert.ToInt32(UserTypes.Employee), false);



                        //SETTING THE COMMON ENTITY PROPERTIES FOR LOGGING PURPOSE
                        commobj.setCommonEntityProperties(ref entity, (loginModel as BaseModel), null, isEditMode);

                        List<Entity> listinsert = new List<Entity>();

                        listinsert.Add(entity);

                        using (GoogleDataStoreInputInfo info = new GoogleDataStoreInputInfo())
                        {

                            if (isEditMode)
                            {
                                IReadOnlyList<Key> listCol = await commobj.Common_UpdateDataIntoDataStore_Async(loginModel, listinsert, datastoreDb, info, this);

                                if (listCol != null && listCol.Count > 0)
                                {
                                    loginModel.empgdsuid = commobj.GetKeyValueInEntityString(listCol[0]);

                                    response = await AddEmployeeToCentralized(loginModel);

                                    response = await InserEmployeeWorkExperianceInfo(loginModel);

                                    response = await InserEmployeeEducationInfo(loginModel);
                                }

                                //using (EmployeeBusinessAccess employeebusinessaccess = new EmployeeBusinessAccess())
                                //{
                                //    response = await employeebusinessaccess.InserEmployeeWorkExperianceInfo(loginModel);

                                //    response = await employeebusinessaccess.InserEmployeeEducationInfo(loginModel);
                                //}


                            }
                            else
                            {
                                IReadOnlyList<Key> listCol = await commobj.Common_InsertDataIntoDataStore_Async(loginModel, listinsert, datastoreDb, info, this);

                                if (listCol != null && listCol.Count > 0)
                                {
                                    loginModel.empgdsuid = commobj.GetKeyValueInEntityString(listCol[0]);

                                    response = await AddEmployeeToCentralized(loginModel);

                                    response = await InserEmployeeWorkExperianceInfo(loginModel);

                                    response = await InserEmployeeEducationInfo(loginModel);
                                }


                                //using (EmployeeBusinessAccess employeebusinessaccess = new EmployeeBusinessAccess())
                                //{
                                //    response = await employeebusinessaccess.InserEmployeeWorkExperianceInfo(loginModel);

                                //    response = await employeebusinessaccess.InserEmployeeEducationInfo(loginModel);
                                //}
                            }

                        }
                    }
                    #endregion


                    #region "    Employee work experiance info                  "



                    #endregion
                }
            }
            finally
            {

            }
            return response;
        }
        #endregion 


        #region "    INSERT EMPLOYEE WORK EXPERIANCE INFO             "
        /// <summary>
        /// THIS METHOD IS USEFUL IN INSERT OR UPDATE THE EMPLOYEE
        /// </summary>
        /// <param name="loginModel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> InserEmployeeWorkExperianceInfo(EmployeeInfo loginModel)
        {
            ResponseModel response = null;
            DatastoreDb datastoreDb = null;
            string kindName = string.Empty;
            KeyFactory keyFactory = null;
            Entity entity = null;
            Boolean isEditMode = false;

            try
            {
                using (CommonBusinessAccess commobj = new CommonBusinessAccess())
                {
                    //create data store db instance
                    datastoreDb = commobj.BuildRequiredPropertiesForGoogleDataStore();


                    #region "Employee Basic Information"

                    //get the kind name
                    kindName = commobj.GetKindNameBasedOnPracticeID(OASDataStoreKind.EmployeeWorkExperianceInfo, loginModel.orgmodel.OrganizationID);

                    //creating the key factory instance to generate new key for kind entitty
                    keyFactory = datastoreDb.CreateKeyFactory(kindName);



                    if (!string.IsNullOrEmpty(loginModel.empgdsuid))
                    {
                        Key keyfound = keyFactory.CreateKey(Convert.ToInt64(loginModel.empgdsuid));

                        entity = await datastoreDb.LookupAsync(keyfound);

                        isEditMode = true;
                    }
                    else
                    {
                        Query query = new Query(kindName)
                        {
                        };

                        List<Entity> list = datastoreDb.RunQuery(query).Entities.ToList();

                        if (list != null && list.Count > 0)
                        {
                            var isFound = false;

                            foreach (Entity itemEnt in list)
                            {
                                if (commobj.GetBooleanValueFromEntity(itemEnt, "InActive"))
                                {

                                }
                                else
                                    isFound = true;
                            }

                            if (isFound)
                            {
                                response = new ResponseModel();
                                response.RequestExecutionStatus = -2;
                                response.ErrorMessage = "User ID Already Exists";
                            }
                            else
                            {
                                entity = new Entity()
                                {

                                };
                                entity.Key = keyFactory.CreateIncompleteKey();
                            }
                        }
                        else
                        {
                            entity = new Entity()
                            {

                            };
                            entity.Key = keyFactory.CreateIncompleteKey();
                        }

                    }

                    if (loginModel.employeeworkexperiancemodellist != null)
                    {
                        for (int i = 0; i < loginModel.employeeworkexperiancemodellist.Count; i++)
                        {
                            if (entity != null)
                            {
                                //setting the values
                                commobj.setEntityIntValue(ref entity, "EmployeeId", loginModel.userid, false);

                                //setting the gds uid
                                commobj.setEntityStringValue(ref entity, "EmployeeGDSUID", loginModel.empgdsuid, false, true);

                                //setting the values
                                commobj.setEntityIntValue(ref entity, "employeeworkexperianceid", loginModel.employeeworkexperiancemodellist[i].employeeworkexperianceid, false);

                                commobj.setEntityStringValue(ref entity, "PreviousCompanyName", loginModel.employeeworkexperiancemodellist[i].prevcompanyname, false, true);

                                commobj.setEntityStringValue(ref entity, "JobTitle", loginModel.employeeworkexperiancemodellist[i].jobtitle, false, true);

                                commobj.setEntityStringValue(ref entity, "ExperienceFromDate", loginModel.employeeworkexperiancemodellist[i].fromdate, true, true);

                                commobj.setEntityStringValue(ref entity, "ExperienceToDate", loginModel.employeeworkexperiancemodellist[i].todate, true, true);

                                commobj.setEntityStringValue(ref entity, "JobDescription", loginModel.employeeworkexperiancemodellist[i].jobdescription, false, true);

                                commobj.setEntityBooleanValue(ref entity, "Inactive", false, false);



                                //SETTING THE COMMON ENTITY PROPERTIES FOR LOGGING PURPOSE
                                commobj.setCommonEntityProperties(ref entity, (loginModel as BaseModel), null, isEditMode);

                                List<Entity> listinsert = new List<Entity>();

                                listinsert.Add(entity);

                                using (GoogleDataStoreInputInfo info = new GoogleDataStoreInputInfo())
                                {

                                    if (isEditMode)
                                    {
                                        IReadOnlyList<Key> listCol = await commobj.Common_UpdateDataIntoDataStore_Async(loginModel, listinsert, datastoreDb, info, this);

                                        if (listCol != null && listCol.Count > 0)
                                        {
                                            response = new ResponseModel();
                                            response.MultipleResponse = commobj.GetKeyValueInEntityString(listCol[0]);
                                        }

                                    }
                                    else
                                    {
                                        IReadOnlyList<Key> listCol = await commobj.Common_InsertDataIntoDataStore_Async(loginModel, listinsert, datastoreDb, info, this);

                                        if (listCol != null && listCol.Count > 0)
                                        {
                                            response = new ResponseModel();
                                            response.MultipleResponse = commobj.GetKeyValueInEntityString(listCol[0]);
                                        }
                                    }

                                }
                            }
                        }
                    }


                    #endregion

                }
            }
            finally
            {

            }
            return response;
        }
        #endregion 


        #region "    INSERT EMPLOYEE EDUCATIONAL INFO             "
        /// <summary>
        /// THIS METHOD IS USEFUL IN INSERT OR UPDATE THE EMPLOYEE
        /// </summary>
        /// <param name="loginModel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> InserEmployeeEducationInfo(EmployeeInfo loginModel)
        {
            ResponseModel response = null;
            DatastoreDb datastoreDb = null;
            string kindName = string.Empty;
            KeyFactory keyFactory = null;
            Entity entity = null;
            Boolean isEditMode = false;

            try
            {
                using (CommonBusinessAccess commobj = new CommonBusinessAccess())
                {
                    //create data store db instance
                    datastoreDb = commobj.BuildRequiredPropertiesForGoogleDataStore();


                    #region "Employee Basic Information"

                    //get the kind name
                    kindName = commobj.GetKindNameBasedOnPracticeID(OASDataStoreKind.EmployeeEducationInfo, loginModel.orgmodel.OrganizationID);

                    //creating the key factory instance to generate new key for kind entitty
                    keyFactory = datastoreDb.CreateKeyFactory(kindName);



                    if (!string.IsNullOrEmpty(loginModel.empgdsuid))
                    {
                        Key keyfound = keyFactory.CreateKey(Convert.ToInt64(loginModel.empgdsuid));

                        entity = await datastoreDb.LookupAsync(keyfound);

                        isEditMode = true;
                    }
                    else
                    {
                        Query query = new Query(kindName)
                        {
                        };

                        List<Entity> list = datastoreDb.RunQuery(query).Entities.ToList();

                        if (list != null && list.Count > 0)
                        {
                            var isFound = false;

                            foreach (Entity itemEnt in list)
                            {
                                if (commobj.GetBooleanValueFromEntity(itemEnt, "InActive"))
                                {

                                }
                                else
                                    isFound = true;
                            }

                            if (isFound)
                            {
                                response = new ResponseModel();
                                response.RequestExecutionStatus = -2;
                                response.ErrorMessage = "User ID Already Exists";
                            }
                            else
                            {
                                entity = new Entity()
                                {

                                };
                                entity.Key = keyFactory.CreateIncompleteKey();
                            }
                        }
                        else
                        {
                            entity = new Entity()
                            {

                            };
                            entity.Key = keyFactory.CreateIncompleteKey();
                        }

                    }

                    if (loginModel.employeeeducationinfomodellist != null)
                    {
                        for (int i = 0; i < loginModel.employeeeducationinfomodellist.Count; i++)
                        {
                            if (entity != null)
                            {
                                //setting the values
                                commobj.setEntityIntValue(ref entity, "EmployeeId", loginModel.userid, false);

                                //setting the gds uid
                                commobj.setEntityStringValue(ref entity, "EmployeeGDSUID", loginModel.empgdsuid, false, true);

                                //setting the values
                                commobj.setEntityIntValue(ref entity, "employeeeducationinfoid", loginModel.employeeeducationinfomodellist[i].employeeeducationinfoid, false);

                                commobj.setEntityStringValue(ref entity, "Schoolorcollegename", loginModel.employeeeducationinfomodellist[i].Schoolorcollegename, false, true);

                                commobj.setEntityStringValue(ref entity, "degreeordiploma", loginModel.employeeeducationinfomodellist[i].degreeordiploma, false, true);

                                commobj.setEntityStringValue(ref entity, "fieldofstudy", loginModel.employeeeducationinfomodellist[i].fieldofstudy, true, true);

                                commobj.setEntityStringValue(ref entity, "dateofcompletion", loginModel.employeeeducationinfomodellist[i].dateofcompletion, true, true);

                                commobj.setEntityStringValue(ref entity, "additionalnotes", loginModel.employeeeducationinfomodellist[i].additionalnotes, false, true);

                                commobj.setEntityStringValue(ref entity, "interests", loginModel.employeeeducationinfomodellist[i].interests, false, true);

                                commobj.setEntityBooleanValue(ref entity, "Inactive", false, false);



                                //SETTING THE COMMON ENTITY PROPERTIES FOR LOGGING PURPOSE
                                commobj.setCommonEntityProperties(ref entity, (loginModel as BaseModel), null, isEditMode);

                                List<Entity> listinsert = new List<Entity>();

                                listinsert.Add(entity);

                                using (GoogleDataStoreInputInfo info = new GoogleDataStoreInputInfo())
                                {

                                    if (isEditMode)
                                    {
                                        IReadOnlyList<Key> listCol = await commobj.Common_UpdateDataIntoDataStore_Async(loginModel, listinsert, datastoreDb, info, this);

                                        if (listCol != null && listCol.Count > 0)
                                        {
                                            response = new ResponseModel();
                                            response.MultipleResponse = commobj.GetKeyValueInEntityString(listCol[0]);
                                        }

                                    }
                                    else
                                    {
                                        IReadOnlyList<Key> listCol = await commobj.Common_InsertDataIntoDataStore_Async(loginModel, listinsert, datastoreDb, info, this);

                                        if (listCol != null && listCol.Count > 0)
                                        {
                                            response = new ResponseModel();
                                            response.MultipleResponse = commobj.GetKeyValueInEntityString(listCol[0]);
                                        }
                                    }

                                }
                            }
                        }
                    }


                    #endregion

                }
            }
            finally
            {

            }
            return response;
        }
        #endregion 


        #region "    INSERT EMPLOYEE DEPENDENTS INFO             "
        /// <summary>
        /// THIS METHOD IS USEFUL IN INSERT OR UPDATE THE EMPLOYEE
        /// </summary>
        /// <param name="loginModel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> InserEmployeeDependentsInfo(EmployeeInfo loginModel)
        {
            ResponseModel response = null;
            DatastoreDb datastoreDb = null;
            string kindName = string.Empty;
            KeyFactory keyFactory = null;
            Entity entity = null;
            Boolean isEditMode = false;

            try
            {
                using (CommonBusinessAccess commobj = new CommonBusinessAccess())
                {
                    //create data store db instance
                    datastoreDb = commobj.BuildRequiredPropertiesForGoogleDataStore();


                    #region "Employee Basic Information"

                    //get the kind name
                    kindName = commobj.GetKindNameBasedOnPracticeID(OASDataStoreKind.EmployeeDependentsInfo, loginModel.orgmodel.OrganizationID);

                    //creating the key factory instance to generate new key for kind entitty
                    keyFactory = datastoreDb.CreateKeyFactory(kindName);



                    if (!string.IsNullOrEmpty(loginModel.empgdsuid))
                    {
                        Key keyfound = keyFactory.CreateKey(Convert.ToInt64(loginModel.empgdsuid));

                        entity = await datastoreDb.LookupAsync(keyfound);

                        isEditMode = true;
                    }
                    else
                    {
                        Query query = new Query(kindName)
                        {
                        };

                        List<Entity> list = datastoreDb.RunQuery(query).Entities.ToList();

                        if (list != null && list.Count > 0)
                        {
                            var isFound = false;

                            foreach (Entity itemEnt in list)
                            {
                                if (commobj.GetBooleanValueFromEntity(itemEnt, "InActive"))
                                {

                                }
                                else
                                    isFound = true;
                            }

                            if (isFound)
                            {
                                response = new ResponseModel();
                                response.RequestExecutionStatus = -2;
                                response.ErrorMessage = "User ID Already Exists";
                            }
                            else
                            {
                                entity = new Entity()
                                {

                                };
                                entity.Key = keyFactory.CreateIncompleteKey();
                            }
                        }
                        else
                        {
                            entity = new Entity()
                            {

                            };
                            entity.Key = keyFactory.CreateIncompleteKey();
                        }

                    }

                    if (loginModel.employeedependentinfolist != null)
                    {
                        for (int i = 0; i < loginModel.employeedependentinfolist.Count; i++)
                        {
                            if (entity != null)
                            {
                                //setting the values
                                commobj.setEntityIntValue(ref entity, "EmployeeId", loginModel.userid, false);

                                //setting the gds uid
                                commobj.setEntityStringValue(ref entity, "EmployeeGDSUID", loginModel.empgdsuid, false, true);

                                //setting the values
                                commobj.setEntityIntValue(ref entity, "employeeDependentinfoid", loginModel.employeedependentinfolist[i].employeeDependentinfoid, false);

                                commobj.setEntityStringValue(ref entity, "dependentname", loginModel.employeedependentinfolist[i].dependentname, false, true);

                                commobj.setEntityStringValue(ref entity, "dependentrelation", loginModel.employeedependentinfolist[i].dependentrelation, false, true);

                                commobj.setEntityStringValue(ref entity, "dependentdateofbirth", loginModel.employeedependentinfolist[i].dependentdateofbirth, true, true);                               

                                commobj.setEntityBooleanValue(ref entity, "Inactive", false, false);



                                //SETTING THE COMMON ENTITY PROPERTIES FOR LOGGING PURPOSE
                                commobj.setCommonEntityProperties(ref entity, (loginModel as BaseModel), null, isEditMode);

                                List<Entity> listinsert = new List<Entity>();

                                listinsert.Add(entity);

                                using (GoogleDataStoreInputInfo info = new GoogleDataStoreInputInfo())
                                {

                                    if (isEditMode)
                                    {
                                        IReadOnlyList<Key> listCol = await commobj.Common_UpdateDataIntoDataStore_Async(loginModel, listinsert, datastoreDb, info, this);

                                        if (listCol != null && listCol.Count > 0)
                                        {
                                            response = new ResponseModel();
                                            response.MultipleResponse = commobj.GetKeyValueInEntityString(listCol[0]);
                                        }

                                    }
                                    else
                                    {
                                        IReadOnlyList<Key> listCol = await commobj.Common_InsertDataIntoDataStore_Async(loginModel, listinsert, datastoreDb, info, this);

                                        if (listCol != null && listCol.Count > 0)
                                        {
                                            response = new ResponseModel();
                                            response.MultipleResponse = commobj.GetKeyValueInEntityString(listCol[0]);
                                        }
                                    }

                                }
                            }
                        }
                    }


                    #endregion

                }
            }
            finally
            {

            }
            return response;
        }
        #endregion 


        #region "    ADD EMPLOYEE TO CENTRALIZED          "
        /// <summary>
        /// THIS METHOD IS USEFUL IN INSERT OR UPDATE THE EMPLOYEE
        /// </summary>
        /// <param name="loginModel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> AddEmployeeToCentralized(EmployeeInfo loginModel)
        {
            ResponseModel response = null;
            DatastoreDb datastoreDb = null;
            string kindName = string.Empty;
            KeyFactory keyFactory = null;
            Entity entity = null;
            Boolean isEditMode = false;
            string currentDateTime = string.Empty;

            try
            {
                using (CommonBusinessAccess commobj = new CommonBusinessAccess())
                {
                    //create data store db instance
                    datastoreDb = commobj.BuildRequiredPropertiesForGoogleDataStore();

                    //get the kind name
                    kindName = commobj.GetKindNameBasedOnPracticeID(OASDataStoreKind.UsersLoginsInfo, loginModel.orgmodel.OrganizationID);

                    //creating the key factory instance to generate new key for kind entitty
                    keyFactory = datastoreDb.CreateKeyFactory(kindName);


                    //checking if it is Edit mode or not 
                    if (!string.IsNullOrEmpty(loginModel.empgdsuid) && !string.IsNullOrEmpty(loginModel.orgmodel.orggdsuid))
                    {
                        Key key = keyFactory.CreateKey(Convert.ToInt64(loginModel.empgdsuid));

                        //looking or searching with key in kind
                        entity = await datastoreDb.LookupAsync(key);

                        Query query = new Query(kindName)
                        {
                            //Filter = Filter.And(Filter.Equal("OrganizationGDSUID", loginModel.orgmodel.orggdsuid),
                            //            Filter.Equal("EmployeeGDSUID", loginModel.empgdsuid),
                            //             Filter.Equal("Inactive", false))

                        };

                        List<Entity> listQuery = datastoreDb.RunQuery(query).Entities.ToList();

                        if (listQuery != null && listQuery.Count > 0)
                        {
                            if (listQuery.Count == 1)
                            {
                                entity = listQuery[0];
                            }
                            else
                                entity = listQuery[0];

                            isEditMode = true;
                        }
                    }


                    if (entity != null)
                    {
                        entity = new Entity()
                        {
                            Key = keyFactory.CreateIncompleteKey()
                        };
                    }


                    if (entity != null)
                    {
                        currentDateTime = commobj.GetAdminDateTime_String();

                        //setting the values
                        commobj.setEntityIntValue(ref entity, "EmployeeId", loginModel.userid, false);

                        commobj.setEntityStringValue(ref entity, "EmployeeGDSUID", loginModel.empgdsuid, false, false);

                        commobj.setEntityStringValue(ref entity, "UsernameOrEmailid", loginModel.emailaddress, false, false);

                        commobj.setEntityIntValue(ref entity, "OrganizationID", loginModel.orgmodel.OrganizationID, false);

                        commobj.setEntityStringValue(ref entity, "OrganizationGDSUID", loginModel.orgmodel.orggdsuid, false, false);

                        commobj.setEntityStringValue(ref entity, "Password", loginModel.password, false, false);

                        commobj.setEntityIntValue(ref entity, "UserType", Convert.ToInt32(UserTypes.Employee), false);

                        commobj.setEntityBooleanValue(ref entity, "Inactive", false, false);



                        //SETTING THE COMMON ENTITY PROPERTIES FOR LOGGING PURPOSE
                        commobj.setCommonEntityProperties(ref entity, (loginModel as BaseModel), currentDateTime, isEditMode);

                        List<Entity> listinsert = new List<Entity>();

                        listinsert.Add(entity);

                        using (GoogleDataStoreInputInfo info = new GoogleDataStoreInputInfo())
                        {
                            IReadOnlyList<Key> listCol = await commobj.Common_UpdateDataIntoDataStore_Async(loginModel, listinsert, datastoreDb, info, this);

                            if (listCol != null && listCol.Count > 0)
                            {
                                response = new ResponseModel();
                                response.MultipleResponse = commobj.GetKeyValueInEntityString(listCol[0]);
                            }
                        }
                    }
                }
            }
            finally
            {

            }
            return response;
        }
        #endregion



        #region "    DELETE EMPLOYEE INFO          "
        /// <summary>
        /// THIS METHOD IS USEFUL IN DELETING THE EMPLOYEE
        /// </summary>
        /// <param name="loginModel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> DeleteEmployee(EmployeeInfo loginModel)
        {
            ResponseModel response = null;
            DatastoreDb datastoreDb = null;
            string kindName = string.Empty;
            KeyFactory keyFactory = null;


            try
            {
                using (CommonBusinessAccess commobj = new CommonBusinessAccess())
                {
                    //create data store db instance
                    datastoreDb = commobj.BuildRequiredPropertiesForGoogleDataStore();

                    //get the kind name
                    kindName = commobj.GetKindNameBasedOnPracticeID(OASDataStoreKind.EmployeesInfo, loginModel.orgmodel.OrganizationID);

                    //creating the key factory instance to generate new key for kind entitty
                    keyFactory = datastoreDb.CreateKeyFactory(kindName);

                    if (!string.IsNullOrEmpty(loginModel.empgdsuid))
                    {

                        Key key = keyFactory.CreateKey(Convert.ToInt64(loginModel.empgdsuid));

                        //looking or searching with key in kind
                        Entity entity = await datastoreDb.LookupAsync(key);

                        if (entity != null)
                        {
                            //setting the values
                            commobj.setEntityBooleanValue(ref entity, "Inactive", true, false);

                            List<Entity> listinsert = new List<Entity>();

                            listinsert.Add(entity);

                            using (GoogleDataStoreInputInfo info = new GoogleDataStoreInputInfo())
                            {
                                commobj.Common_UpdateDataIntoDataStore(loginModel, listinsert, datastoreDb, info, this);
                            }
                        }
                    }
                }
            }
            finally
            {

            }
            return response;
        }
        #endregion


        #region "     EMPLOYEES DETAILS LIST          "
        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING   APPSERVERS DETAILS LIST      
        /// </summary>
        /// <returns></returns>
        public async Task<EmployeeInfo> oasEmployeesList(EmployeeInfo employeeinfo)
        {
            EmployeeInfo responsemodel = null;
            DatastoreDb datastoredb = null;
            string KindName = string.Empty;

            try
            {
                //ehrcommondatastoremodel.emrwebexceptiontracelogmodel.AddToExecutionLog("EHRGoogleDataStore.BusinessAccess", "PracticeInfoConfigBusinessAccess", "AppServersList", "AppServersList Start", ExecutionLogType.Detail);

                using (CommonBusinessAccess commonbusinessaccess = new CommonBusinessAccess())
                {
                    //creating the data store db connection instance
                    datastoredb = commonbusinessaccess.BuildRequiredPropertiesForGoogleDataStore();

                    //getting the kind name
                    KindName = commonbusinessaccess.GetKindNameBasedOnPracticeID(OASDataStoreKind.EmployeesInfo, employeeinfo.orgmodel.OrganizationID);

                    Query query = new Query(KindName)
                    {

                    };


                    //RUNNING THE QUERY IN DB AND GETTING THE RESULTING ENTITIES LIST
                    List<Entity> OutputEntity = datastoredb.RunQuery(query).Entities.ToList();

                    responsemodel = new EmployeeInfo();

                    responsemodel.employeeinfo = new EmployeeInfo();

                    responsemodel.employeeinfolist = new List<EmployeeInfo>();



                    //LOOPING ON ALL THE RESULTS AND FORMING THE REQUIRED LIST OBJECTS
                    foreach (Entity newentity in OutputEntity)
                    {
                        EmployeeInfo modelObj = new EmployeeInfo();


                        #region "   GETTING THE ENTITY VALUES GENERATED USING TOOL       "

                        modelObj.empgdsuid = commonbusinessaccess.GetKeyValueInEntityString(newentity);

                        modelObj.userid = commonbusinessaccess.GetInt32ValueFromEntity(newentity, "EmployeeId");

                        modelObj.empname = commonbusinessaccess.GetStringValueFromEntity(newentity, "EmployeeName");

                        modelObj.emailaddress = commonbusinessaccess.GetStringValueFromEntity(newentity, "EmailAddress");

                        modelObj.gender = commonbusinessaccess.GetInt32ValueFromEntity(newentity, "Gender");

                        if (modelObj.gender == 1)
                        {
                            modelObj.genderName = "Male";
                        }
                        else if (modelObj.gender == 2)
                        {
                            modelObj.genderName = "Female";
                        }

                        modelObj.dob = commonbusinessaccess.GetStringValueFromEntity(newentity, "DOB");

                        modelObj.employeemaritalstatus = commonbusinessaccess.GetInt32ValueFromEntity(newentity, "MaritalStatus");

                        modelObj.employeeaddress = commonbusinessaccess.GetStringValueFromEntity(newentity, "EmployeeAddress");

                        modelObj.employeetags = commonbusinessaccess.GetStringValueFromEntity(newentity, "EmployeeTags");

                        modelObj.password = commonbusinessaccess.GetStringValueFromEntity(newentity, "Password");

                        modelObj.isactive = commonbusinessaccess.GetBooleanValueFromEntity(newentity, "Inactive");

                        modelObj.employeedepartment = commonbusinessaccess.GetInt32ValueFromEntity(newentity, "EmployeeDepartment");

                        modelObj.employeereportingto = commonbusinessaccess.GetInt32ValueFromEntity(newentity, "EmployeeReportingTo");

                        modelObj.employeesourceofhire = commonbusinessaccess.GetInt32ValueFromEntity(newentity, "EmployeeSourceofHire");

                        modelObj.employeetype = commonbusinessaccess.GetInt32ValueFromEntity(newentity, "EmployeeType");

                        modelObj.employeedesignation = commonbusinessaccess.GetInt32ValueFromEntity(newentity, "EmployeeDesignation");

                        modelObj.employeeworknumber = commonbusinessaccess.GetStringValueFromEntity(newentity, "EmployeeWorkNumber");

                        modelObj.employeejobdescription = commonbusinessaccess.GetStringValueFromEntity(newentity, "employeejobdescription");

                        modelObj.dateofexit = commonbusinessaccess.GetStringValueFromEntity(newentity, "DateofExit");

                        modelObj.prevcompanyname = commonbusinessaccess.GetStringValueFromEntity(newentity, "PreviousCompanyName");

                        modelObj.jobtitle = commonbusinessaccess.GetStringValueFromEntity(newentity, "JobTitle");

                        modelObj.fromdate = commonbusinessaccess.GetStringValueFromEntity(newentity, "ExperienceFromDate");

                        modelObj.todate = commonbusinessaccess.GetStringValueFromEntity(newentity, "ExperienceToDate");

                        modelObj.jobdescription = commonbusinessaccess.GetStringValueFromEntity(newentity, "JobDescription");

                        modelObj.isactive = commonbusinessaccess.GetBooleanValueFromEntity(newentity, "Inactive");


                        #endregion

                        responsemodel.employeeinfolist.Add(modelObj);
                    }



                    ////filtering the list
                    //if (ehrcommondatastoremodel.EHRAppServersInfoContainerObj != null &&
                    //    ehrcommondatastoremodel.EHRAppServersInfoContainerObj.EHRAppServersInfoObj != null)
                    //{

                    //    if (!string.IsNullOrEmpty(ehrcommondatastoremodel.EHRAppServersInfoContainerObj.EHRAppServersInfoObj.EMRApplicationServerName))
                    //        responsemodel.EHRAppServersInfoContainerObj.EHRAppServersInfoList = responsemodel.EHRAppServersInfoContainerObj.EHRAppServersInfoList.Where(item => item.EMRApplicationServerName.ToLower().Contains(ehrcommondatastoremodel.EHRAppServersInfoContainerObj.EHRAppServersInfoObj.EMRApplicationServerName.ToLower())).ToList();

                    //    if (!string.IsNullOrEmpty(ehrcommondatastoremodel.EHRAppServersInfoContainerObj.EHRAppServersInfoObj.EMRApplicationServerMacAddress))
                    //        responsemodel.EHRAppServersInfoContainerObj.EHRAppServersInfoList = responsemodel.EHRAppServersInfoContainerObj.EHRAppServersInfoList.Where(item => item.EMRApplicationServerMacAddress.ToLower().Contains(ehrcommondatastoremodel.EHRAppServersInfoContainerObj.EHRAppServersInfoObj.EMRApplicationServerMacAddress.ToLower())).ToList();


                    //}


                    //sorting the items
                    //responsemodel.employeeInfolist = responsemodel.employeeInfolist.Where(item => item.WindowsUserName.ToLower().Contains(ehrcommondatastoremodel.practiceswindowusernamesinfomodelObj.practiceswindowusernamesinfoobjectmodel.WindowsUserName.ToLower())).ToList();

                }

                //ehrcommondatastoremodel.emrwebexceptiontracelogmodel.AddToExecutionLog("EHRGoogleDataStore.BusinessAccess", "PracticeInfoConfigBusinessAccess", "AppServersList", "AppServersList End", ExecutionLogType.Detail);

            }
            finally
            {

            }

            return responsemodel;
        }

        #endregion



        #region "     EMPLOYEES WORK EXPERIANCE LIST SP  "
        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING   APPSERVERS DETAILS LIST      
        /// </summary>
        /// <returns></returns>
        public async Task<EmployeeInfo> oasEmployeesWorkExperianceInfoList(EmployeeInfo employeeinfo)
        {
            EmployeeInfo responsemodel = null;
            DatastoreDb datastoredb = null;
            string KindName = string.Empty;

            try
            {
                //ehrcommondatastoremodel.emrwebexceptiontracelogmodel.AddToExecutionLog("EHRGoogleDataStore.BusinessAccess", "PracticeInfoConfigBusinessAccess", "AppServersList", "AppServersList Start", ExecutionLogType.Detail);

                using (CommonBusinessAccess commonbusinessaccess = new CommonBusinessAccess())
                {
                    //creating the data store db connection instance
                    datastoredb = commonbusinessaccess.BuildRequiredPropertiesForGoogleDataStore();

                    //getting the kind name
                    KindName = commonbusinessaccess.GetKindNameBasedOnPracticeID(OASDataStoreKind.EmployeeWorkExperianceInfo, employeeinfo.orgmodel.OrganizationID);

                    Query query = new Query(KindName)
                    {
                        Filter = Filter.Equal("Inactive", false)
                    };


                    //RUNNING THE QUERY IN DB AND GETTING THE RESULTING ENTITIES LIST
                    List<Entity> OutputEntity = datastoredb.RunQuery(query).Entities.ToList();

                    responsemodel = new EmployeeInfo();

                    responsemodel.employeeworkexperiancemodel = new EmployeeWorkExperianceModel();

                    responsemodel.employeeworkexperiancemodellist = new List<EmployeeWorkExperianceModel>();



                    //LOOPING ON ALL THE RESULTS AND FORMING THE REQUIRED LIST OBJECTS
                    foreach (Entity newentity in OutputEntity)
                    {
                        EmployeeWorkExperianceModel modelObj = new EmployeeWorkExperianceModel();


                        #region "   GETTING THE ENTITY VALUES GENERATED USING TOOL       "

                        modelObj.empgdsuid = commonbusinessaccess.GetStringValueFromEntity(newentity, "EmployeeGDSUID");

                        modelObj.userid = commonbusinessaccess.GetInt32ValueFromEntity(newentity, "EmployeeId");

                        modelObj.employeeworkexperianceid = commonbusinessaccess.GetInt32ValueFromEntity(newentity, "employeeworkexperianceid");

                        modelObj.prevcompanyname = commonbusinessaccess.GetStringValueFromEntity(newentity, "PreviousCompanyName");

                        modelObj.jobtitle = commonbusinessaccess.GetStringValueFromEntity(newentity, "JobTitle");

                        modelObj.fromdate = commonbusinessaccess.GetStringValueFromEntity(newentity, "ExperienceFromDate");

                        modelObj.todate = commonbusinessaccess.GetStringValueFromEntity(newentity, "ExperienceToDate");

                        modelObj.jobdescription = commonbusinessaccess.GetStringValueFromEntity(newentity, "JobDescription");

                        modelObj.isinactive = commonbusinessaccess.GetBooleanValueFromEntity(newentity, "Inactive");


                        #endregion

                        responsemodel.employeeworkexperiancemodellist.Add(modelObj);
                    }

                }

                //ehrcommondatastoremodel.emrwebexceptiontracelogmodel.AddToExecutionLog("EHRGoogleDataStore.BusinessAccess", "PracticeInfoConfigBusinessAccess", "AppServersList", "AppServersList End", ExecutionLogType.Detail);

            }
            finally
            {

            }

            return responsemodel;
        }

        #endregion


        #region "     EMPLOYEES EDUCATIONAL INFO LIST SP  "
        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING   APPSERVERS DETAILS LIST      
        /// </summary>
        /// <returns></returns>
        public async Task<EmployeeInfo> oasEmployeesEducationInfoList(EmployeeInfo employeeinfo)
        {
            EmployeeInfo responsemodel = null;
            DatastoreDb datastoredb = null;
            string KindName = string.Empty;

            try
            {
                //ehrcommondatastoremodel.emrwebexceptiontracelogmodel.AddToExecutionLog("EHRGoogleDataStore.BusinessAccess", "PracticeInfoConfigBusinessAccess", "AppServersList", "AppServersList Start", ExecutionLogType.Detail);

                using (CommonBusinessAccess commonbusinessaccess = new CommonBusinessAccess())
                {
                    //creating the data store db connection instance
                    datastoredb = commonbusinessaccess.BuildRequiredPropertiesForGoogleDataStore();

                    //getting the kind name
                    KindName = commonbusinessaccess.GetKindNameBasedOnPracticeID(OASDataStoreKind.EmployeeEducationInfo, employeeinfo.orgmodel.OrganizationID);

                    Query query = new Query(KindName)
                    {
                        Filter = Filter.Equal("Inactive", false)
                    };


                    //RUNNING THE QUERY IN DB AND GETTING THE RESULTING ENTITIES LIST
                    List<Entity> OutputEntity = datastoredb.RunQuery(query).Entities.ToList();

                    responsemodel = new EmployeeInfo();

                    responsemodel.employeeeducationinfomodel = new EmployeeEducationInfoModel();

                    responsemodel.employeeeducationinfomodellist = new List<EmployeeEducationInfoModel>();



                    //LOOPING ON ALL THE RESULTS AND FORMING THE REQUIRED LIST OBJECTS
                    foreach (Entity newentity in OutputEntity)
                    {
                        EmployeeEducationInfoModel modelObj = new EmployeeEducationInfoModel();


                        #region "   GETTING THE ENTITY VALUES GENERATED USING TOOL       "

                        modelObj.empgdsuid = commonbusinessaccess.GetStringValueFromEntity(newentity, "EmployeeGDSUID");

                        modelObj.userid = commonbusinessaccess.GetInt32ValueFromEntity(newentity, "EmployeeId");

                        modelObj.employeeeducationinfoid = commonbusinessaccess.GetInt32ValueFromEntity(newentity, "employeeeducationinfoid");

                        modelObj.Schoolorcollegename = commonbusinessaccess.GetStringValueFromEntity(newentity, "Schoolorcollegename");

                        modelObj.degreeordiploma = commonbusinessaccess.GetStringValueFromEntity(newentity, "degreeordiploma");

                        modelObj.fieldofstudy = commonbusinessaccess.GetStringValueFromEntity(newentity, "fieldofstudy");

                        modelObj.dateofcompletion = commonbusinessaccess.GetStringValueFromEntity(newentity, "dateofcompletion");

                        modelObj.additionalnotes = commonbusinessaccess.GetStringValueFromEntity(newentity, "additionalnotes");

                        modelObj.interests = commonbusinessaccess.GetStringValueFromEntity(newentity, "interests");

                        modelObj.isinactive = commonbusinessaccess.GetBooleanValueFromEntity(newentity, "Inactive");


                        #endregion

                        responsemodel.employeeeducationinfomodellist.Add(modelObj);
                    }

                }

                //ehrcommondatastoremodel.emrwebexceptiontracelogmodel.AddToExecutionLog("EHRGoogleDataStore.BusinessAccess", "PracticeInfoConfigBusinessAccess", "AppServersList", "AppServersList End", ExecutionLogType.Detail);

            }
            finally
            {

            }

            return responsemodel;
        }

        #endregion




        #region "    ADD OR EDIT DEPARTMENT INFO               "
        /// <summary>
        /// THIS METHOD IS USEFUL IN INSERT OR UPDATE THE EMPLOYEE
        /// </summary>
        /// <param name="loginModel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> AddEditDepartmentInfo(DepartmentsInfoModel inputmodel)
        {
            ResponseModel response = null;
            DatastoreDb datastoreDb = null;
            string kindName = string.Empty;
            KeyFactory keyFactory = null;
            Entity entity = null;
            Boolean isEditMode = false;

            try
            {
                using (CommonBusinessAccess commobj = new CommonBusinessAccess())
                {
                    //create data store db instance
                    datastoreDb = commobj.BuildRequiredPropertiesForGoogleDataStore();

                    //get the kind name
                    kindName = commobj.GetKindNameBasedOnPracticeID(OASDataStoreKind.DepartmentsInfo, inputmodel.orgmodel.OrganizationID);

                    //creating the key factory instance to generate new key for kind entitty
                    keyFactory = datastoreDb.CreateKeyFactory(kindName);



                    if (!string.IsNullOrEmpty(inputmodel.departmentgdsuid))
                    {
                        Key keyfound = keyFactory.CreateKey(Convert.ToInt64(inputmodel.departmentgdsuid));

                        entity = await datastoreDb.LookupAsync(keyfound);

                        isEditMode = true;
                    }
                    else
                    {
                        Query query = new Query(kindName)
                        {
                            Filter = Filter.And(Filter.Equal("DepartmentID", inputmodel.departmentid),
                                                Filter.Equal("InActive", false))
                        };

                        List<Entity> list = datastoreDb.RunQuery(query).Entities.ToList();

                        if (list != null && list.Count > 0)
                        {
                            var isFound = false;

                            foreach (Entity itemEnt in list)
                            {
                                if (commobj.GetBooleanValueFromEntity(itemEnt, "InActive"))
                                {

                                }
                                else
                                    isFound = true;
                            }

                            if (isFound)
                            {
                                response = new ResponseModel();
                                response.RequestExecutionStatus = -2;
                                response.ErrorMessage = "Department ID Already Exists";
                            }
                            else
                            {
                                entity = new Entity()
                                {

                                };
                                entity.Key = keyFactory.CreateIncompleteKey();
                            }
                        }
                        else
                        {
                            entity = new Entity()
                            {

                            };
                            entity.Key = keyFactory.CreateIncompleteKey();
                        }

                    }


                    if (entity != null)
                    {
                        //setting the values
                        commobj.setEntityIntValue(ref entity, "DepartmentID", inputmodel.departmentid, false);

                        commobj.setEntityStringValue(ref entity, "DepartmentName", inputmodel.departmentname, true, true);

                        commobj.setEntityStringValue(ref entity, "DepartmentMailAlias", inputmodel.departmentmailalias, true, true);

                        commobj.setEntityStringValue(ref entity, "DepartmentLead", inputmodel.departmentlead, true, true);

                        commobj.setEntityStringValue(ref entity, "DepartmentParentDept", inputmodel.departmentparentdept, true, true);

                        commobj.setEntityBooleanValue(ref entity, "Inactive", false, false);


                        //SETTING THE COMMON ENTITY PROPERTIES FOR LOGGING PURPOSE
                        commobj.setCommonEntityProperties(ref entity, (inputmodel as BaseModel), null, isEditMode);

                        List<Entity> listinsert = new List<Entity>();

                        listinsert.Add(entity);

                        using (GoogleDataStoreInputInfo info = new GoogleDataStoreInputInfo())
                        {
                            if (isEditMode)
                            {
                                IReadOnlyList<Key> listCol = await commobj.Common_UpdateDataIntoDataStore_Async(inputmodel, listinsert, datastoreDb, info, this);

                                if (listCol != null && listCol.Count > 0)
                                {
                                    inputmodel.departmentgdsuid = commobj.GetKeyValueInEntityString(listCol[0]);
                                }

                            }
                            else
                            {
                                IReadOnlyList<Key> listCol = await commobj.Common_InsertDataIntoDataStore_Async(inputmodel, listinsert, datastoreDb, info, this);

                                if (listCol != null && listCol.Count > 0)
                                {
                                    inputmodel.departmentgdsuid = commobj.GetKeyValueInEntityString(listCol[0]);
                                }
                            }
                        }
                    }
                }
            }
            finally
            {

            }
            return response;
        }
        #endregion 

        #region "     DEPARTMENTS DETAILS LIST          "
        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING   APPSERVERS DETAILS LIST      
        /// </summary>
        /// <returns></returns>
        public async Task<DepartmentsInfoModel> GetDepartmentsList(DepartmentsInfoModel inputmodel)
        {
            DepartmentsInfoModel responsemodel = null;
            DatastoreDb datastoredb = null;
            string KindName = string.Empty;

            try
            {
                //ehrcommondatastoremodel.emrwebexceptiontracelogmodel.AddToExecutionLog("EHRGoogleDataStore.BusinessAccess", "PracticeInfoConfigBusinessAccess", "AppServersList", "AppServersList Start", ExecutionLogType.Detail);

                using (CommonBusinessAccess commonbusinessaccess = new CommonBusinessAccess())
                {
                    //creating the data store db connection instance
                    datastoredb = commonbusinessaccess.BuildRequiredPropertiesForGoogleDataStore();

                    //getting the kind name
                    KindName = commonbusinessaccess.GetKindNameBasedOnPracticeID(OASDataStoreKind.DepartmentsInfo, inputmodel.orgmodel.OrganizationID);

                    Query query = new Query(KindName)
                    {
                        Filter = Filter.Equal("Inactive", false)
                    };


                    //RUNNING THE QUERY IN DB AND GETTING THE RESULTING ENTITIES LIST
                    List<Entity> OutputEntity = datastoredb.RunQuery(query).Entities.ToList();

                    responsemodel = new DepartmentsInfoModel();

                    responsemodel.departmentsinfomodel = new DepartmentsInfoModel();

                    responsemodel.departmentsinfomodellist = new List<DepartmentsInfoModel>();



                    //LOOPING ON ALL THE RESULTS AND FORMING THE REQUIRED LIST OBJECTS
                    foreach (Entity newentity in OutputEntity)
                    {
                        DepartmentsInfoModel modelObj = new DepartmentsInfoModel();


                        #region "   GETTING THE ENTITY VALUES GENERATED USING TOOL       "

                        modelObj.departmentgdsuid = commonbusinessaccess.GetKeyValueInEntityString(newentity);

                        modelObj.departmentid = commonbusinessaccess.GetInt32ValueFromEntity(newentity, "DepartmentID");

                        modelObj.departmentname = commonbusinessaccess.GetStringValueFromEntity(newentity, "DepartmentName");

                        modelObj.departmentmailalias = commonbusinessaccess.GetStringValueFromEntity(newentity, "DepartmentMailAlias");

                        modelObj.departmentlead = commonbusinessaccess.GetStringValueFromEntity(newentity, "DepartmentLead");

                        modelObj.departmentparentdept = commonbusinessaccess.GetStringValueFromEntity(newentity, "DepartmentParentDept");

                        modelObj.isinactive = commonbusinessaccess.GetBooleanValueFromEntity(newentity, "Inactive");

                        #endregion

                        responsemodel.departmentsinfomodellist.Add(modelObj);
                    }



                    ////filtering the list
                    //if (ehrcommondatastoremodel.EHRAppServersInfoContainerObj != null &&
                    //    ehrcommondatastoremodel.EHRAppServersInfoContainerObj.EHRAppServersInfoObj != null)
                    //{

                    //    if (!string.IsNullOrEmpty(ehrcommondatastoremodel.EHRAppServersInfoContainerObj.EHRAppServersInfoObj.EMRApplicationServerName))
                    //        responsemodel.EHRAppServersInfoContainerObj.EHRAppServersInfoList = responsemodel.EHRAppServersInfoContainerObj.EHRAppServersInfoList.Where(item => item.EMRApplicationServerName.ToLower().Contains(ehrcommondatastoremodel.EHRAppServersInfoContainerObj.EHRAppServersInfoObj.EMRApplicationServerName.ToLower())).ToList();

                    //    if (!string.IsNullOrEmpty(ehrcommondatastoremodel.EHRAppServersInfoContainerObj.EHRAppServersInfoObj.EMRApplicationServerMacAddress))
                    //        responsemodel.EHRAppServersInfoContainerObj.EHRAppServersInfoList = responsemodel.EHRAppServersInfoContainerObj.EHRAppServersInfoList.Where(item => item.EMRApplicationServerMacAddress.ToLower().Contains(ehrcommondatastoremodel.EHRAppServersInfoContainerObj.EHRAppServersInfoObj.EMRApplicationServerMacAddress.ToLower())).ToList();


                    //}


                    //sorting the items
                    //responsemodel.employeeInfolist = responsemodel.employeeInfolist.Where(item => item.WindowsUserName.ToLower().Contains(ehrcommondatastoremodel.practiceswindowusernamesinfomodelObj.practiceswindowusernamesinfoobjectmodel.WindowsUserName.ToLower())).ToList();

                }

                //ehrcommondatastoremodel.emrwebexceptiontracelogmodel.AddToExecutionLog("EHRGoogleDataStore.BusinessAccess", "PracticeInfoConfigBusinessAccess", "AppServersList", "AppServersList End", ExecutionLogType.Detail);

            }
            finally
            {

            }

            return responsemodel;
        }

        #endregion

        #region "    DELETE DEPARTMENT INFO          "
        /// <summary>
        /// THIS METHOD IS USEFUL IN DELETING THE EMPLOYEE
        /// </summary>
        /// <param name="loginModel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> DeleteDepartmentInfo(DepartmentsInfoModel inputmodel)
        {
            ResponseModel response = null;
            DatastoreDb datastoreDb = null;
            string kindName = string.Empty;
            KeyFactory keyFactory = null;


            try
            {
                using (CommonBusinessAccess commobj = new CommonBusinessAccess())
                {
                    //create data store db instance
                    datastoreDb = commobj.BuildRequiredPropertiesForGoogleDataStore();

                    //get the kind name
                    kindName = commobj.GetKindNameBasedOnPracticeID(OASDataStoreKind.DepartmentsInfo, inputmodel.orgmodel.OrganizationID);

                    //creating the key factory instance to generate new key for kind entitty
                    keyFactory = datastoreDb.CreateKeyFactory(kindName);

                    if (!string.IsNullOrEmpty(inputmodel.departmentgdsuid))
                    {

                        Key key = keyFactory.CreateKey(Convert.ToInt64(inputmodel.departmentgdsuid));

                        //looking or searching with key in kind
                        Entity entity = await datastoreDb.LookupAsync(key);

                        if (entity != null)
                        {
                            //setting the values
                            commobj.setEntityBooleanValue(ref entity, "Inactive", true, false);

                            List<Entity> listinsert = new List<Entity>();

                            listinsert.Add(entity);

                            using (GoogleDataStoreInputInfo info = new GoogleDataStoreInputInfo())
                            {
                                commobj.Common_UpdateDataIntoDataStore(inputmodel, listinsert, datastoreDb, info, this);
                            }
                        }
                    }
                }
            }
            finally
            {

            }
            return response;
        }
        #endregion

        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {

            }
        }
        #endregion

    }
}






