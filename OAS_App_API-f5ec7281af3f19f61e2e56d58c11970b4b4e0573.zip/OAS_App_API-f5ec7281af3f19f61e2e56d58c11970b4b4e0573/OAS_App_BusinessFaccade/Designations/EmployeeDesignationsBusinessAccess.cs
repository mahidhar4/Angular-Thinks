﻿using Google.Cloud.Datastore.V1;
using OAS_App_BusinessFaccade.Common;
using OAS_App_Common;
using OAS_App_Common.Common;
using OAS_App_Common.Employee;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;

namespace OAS_App_BusinessFaccade.Designations
{
  public  class EmployeeDesignationsBusinessAccess:IDisposable
    {






        #region "    ADD OR EDIT DESIGNATIONS INFO               "
        /// <summary>
        /// THIS METHOD IS USEFUL IN INSERT OR UPDATE THE EMPLOYEE
        /// </summary>
        /// <param name="loginModel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> AddEditDesignations(DesignationsInfoModel inputmodel)
        {
            ResponseModel response = null;
            DatastoreDb datastoreDb = null;
            string kindName = string.Empty;
            KeyFactory keyFactory = null;
            Entity entity = null;
            Boolean isEditMode = false;

            try
            {
                using (CommonBusinessAccess commobj = new CommonBusinessAccess())
                {
                    //create data store db instance
                    datastoreDb = commobj.BuildRequiredPropertiesForGoogleDataStore();

                    //get the kind name
                    kindName = commobj.GetKindNameBasedOnPracticeID(OASDataStoreKind.DesignationsInfo, inputmodel.orgmodel.OrganizationID);

                    //creating the key factory instance to generate new key for kind entitty
                    keyFactory = datastoreDb.CreateKeyFactory(kindName);



                    if (!string.IsNullOrEmpty(inputmodel.designationsgdsuid))
                    {
                        Key keyfound = keyFactory.CreateKey(Convert.ToInt64(inputmodel.designationsgdsuid));

                        entity = await datastoreDb.LookupAsync(keyfound);

                        isEditMode = true;
                    }
                    else
                    {
                        Query query = new Query(kindName)
                        {
                            Filter = Filter.And(Filter.Equal("DesignationID", inputmodel.designationid),
                                                Filter.Equal("InActive", false))
                        };

                        List<Entity> list = datastoreDb.RunQuery(query).Entities.ToList();

                        if (list != null && list.Count > 0)
                        {
                            var isFound = false;

                            foreach (Entity itemEnt in list)
                            {
                                if (commobj.GetBooleanValueFromEntity(itemEnt, "InActive"))
                                {

                                }
                                else
                                    isFound = true;
                            }

                            if (isFound)
                            {
                                response = new ResponseModel();
                                response.RequestExecutionStatus = -2;
                                response.ErrorMessage = "Designation ID Already Exists";
                            }
                            else
                            {
                                entity = new Entity()
                                {

                                };
                                entity.Key = keyFactory.CreateIncompleteKey();
                            }
                        }
                        else
                        {
                            entity = new Entity()
                            {

                            };
                            entity.Key = keyFactory.CreateIncompleteKey();
                        }

                    }


                    if (entity != null)
                    {
                        //setting the values
                        commobj.setEntityIntValue(ref entity, "DesignationID", inputmodel.designationid, false);

                        commobj.setEntityStringValue(ref entity, "DesignationName", inputmodel.designationname, true, true);

                        commobj.setEntityStringValue(ref entity, "DesignationMailAlias", inputmodel.designationmailalias, true, true);

                        commobj.setEntityBooleanValue(ref entity, "Inactive", false, false);


                        //SETTING THE COMMON ENTITY PROPERTIES FOR LOGGING PURPOSE
                        commobj.setCommonEntityProperties(ref entity, (inputmodel as BaseModel), null, isEditMode);

                        List<Entity> listinsert = new List<Entity>();

                        listinsert.Add(entity);

                        using (GoogleDataStoreInputInfo info = new GoogleDataStoreInputInfo())
                        {
                            if (isEditMode)
                            {
                                IReadOnlyList<Key> listCol = await commobj.Common_UpdateDataIntoDataStore_Async(inputmodel, listinsert, datastoreDb, info, this);

                                if (listCol != null && listCol.Count > 0)
                                {
                                    inputmodel.designationsgdsuid = commobj.GetKeyValueInEntityString(listCol[0]);
                                }

                            }
                            else
                            {
                                IReadOnlyList<Key> listCol = await commobj.Common_InsertDataIntoDataStore_Async(inputmodel, listinsert, datastoreDb, info, this);

                                if (listCol != null && listCol.Count > 0)
                                {
                                    inputmodel.designationsgdsuid = commobj.GetKeyValueInEntityString(listCol[0]);
                                }
                            }
                        }
                    }
                }
            }
            finally
            {

            }
            return response;
        }
        #endregion 

        #region "     DESIGNATIONS DETAILS LIST          "
        /// <summary>
        /// THIS METHOD IS USEFUL IN GETTING   APPSERVERS DETAILS LIST      
        /// </summary>
        /// <returns></returns>
        public async Task<DesignationsInfoModel> GetDesignationsList(DesignationsInfoModel inputmodel)
        {
            DesignationsInfoModel responsemodel = null;
            DatastoreDb datastoredb = null;
            string KindName = string.Empty;

            try
            {
                //ehrcommondatastoremodel.emrwebexceptiontracelogmodel.AddToExecutionLog("EHRGoogleDataStore.BusinessAccess", "PracticeInfoConfigBusinessAccess", "AppServersList", "AppServersList Start", ExecutionLogType.Detail);

                using (CommonBusinessAccess commonbusinessaccess = new CommonBusinessAccess())
                {
                    //creating the data store db connection instance
                    datastoredb = commonbusinessaccess.BuildRequiredPropertiesForGoogleDataStore();

                    //getting the kind name
                    KindName = commonbusinessaccess.GetKindNameBasedOnPracticeID(OASDataStoreKind.DesignationsInfo, inputmodel.orgmodel.OrganizationID);

                    Query query = new Query(KindName)
                    {
                        Filter = Filter.Equal("Inactive", false)
                    };


                    //RUNNING THE QUERY IN DB AND GETTING THE RESULTING ENTITIES LIST
                    List<Entity> OutputEntity = datastoredb.RunQuery(query).Entities.ToList();

                    responsemodel = new DesignationsInfoModel();

                    responsemodel.designationsinfomodel = new DesignationsInfoModel();

                    responsemodel.designationsinfomodellist = new List<DesignationsInfoModel>();



                    //LOOPING ON ALL THE RESULTS AND FORMING THE REQUIRED LIST OBJECTS
                    foreach (Entity newentity in OutputEntity)
                    {
                        DesignationsInfoModel modelObj = new DesignationsInfoModel();


                        #region "   GETTING THE ENTITY VALUES GENERATED USING TOOL       "

                        modelObj.designationsgdsuid = commonbusinessaccess.GetKeyValueInEntityString(newentity);

                        modelObj.designationid = commonbusinessaccess.GetInt32ValueFromEntity(newentity, "DesignationID");

                        modelObj.designationname = commonbusinessaccess.GetStringValueFromEntity(newentity, "DesignationName");

                        modelObj.designationmailalias = commonbusinessaccess.GetStringValueFromEntity(newentity, "DesignationMailAlias");

                        modelObj.isinactive = commonbusinessaccess.GetBooleanValueFromEntity(newentity, "Inactive");

                        #endregion

                        responsemodel.designationsinfomodellist.Add(modelObj);
                    }



                    ////filtering the list
                    //if (ehrcommondatastoremodel.EHRAppServersInfoContainerObj != null &&
                    //    ehrcommondatastoremodel.EHRAppServersInfoContainerObj.EHRAppServersInfoObj != null)
                    //{

                    //    if (!string.IsNullOrEmpty(ehrcommondatastoremodel.EHRAppServersInfoContainerObj.EHRAppServersInfoObj.EMRApplicationServerName))
                    //        responsemodel.EHRAppServersInfoContainerObj.EHRAppServersInfoList = responsemodel.EHRAppServersInfoContainerObj.EHRAppServersInfoList.Where(item => item.EMRApplicationServerName.ToLower().Contains(ehrcommondatastoremodel.EHRAppServersInfoContainerObj.EHRAppServersInfoObj.EMRApplicationServerName.ToLower())).ToList();

                    //    if (!string.IsNullOrEmpty(ehrcommondatastoremodel.EHRAppServersInfoContainerObj.EHRAppServersInfoObj.EMRApplicationServerMacAddress))
                    //        responsemodel.EHRAppServersInfoContainerObj.EHRAppServersInfoList = responsemodel.EHRAppServersInfoContainerObj.EHRAppServersInfoList.Where(item => item.EMRApplicationServerMacAddress.ToLower().Contains(ehrcommondatastoremodel.EHRAppServersInfoContainerObj.EHRAppServersInfoObj.EMRApplicationServerMacAddress.ToLower())).ToList();


                    //}


                    //sorting the items
                    //responsemodel.employeeInfolist = responsemodel.employeeInfolist.Where(item => item.WindowsUserName.ToLower().Contains(ehrcommondatastoremodel.practiceswindowusernamesinfomodelObj.practiceswindowusernamesinfoobjectmodel.WindowsUserName.ToLower())).ToList();

                }

                //ehrcommondatastoremodel.emrwebexceptiontracelogmodel.AddToExecutionLog("EHRGoogleDataStore.BusinessAccess", "PracticeInfoConfigBusinessAccess", "AppServersList", "AppServersList End", ExecutionLogType.Detail);

            }
            finally
            {

            }

            return responsemodel;
        }

        #endregion

        #region "    DELETE DESIGNATIONS INFO          "
        /// <summary>
        /// THIS METHOD IS USEFUL IN DELETING THE EMPLOYEE
        /// </summary>
        /// <param name="loginModel"></param>
        /// <returns></returns>
        public async Task<ResponseModel> DeleteDesignations(DesignationsInfoModel inputmodel)
        {
            ResponseModel response = null;
            DatastoreDb datastoreDb = null;
            string kindName = string.Empty;
            KeyFactory keyFactory = null;


            try
            {
                using (CommonBusinessAccess commobj = new CommonBusinessAccess())
                {
                    //create data store db instance
                    datastoreDb = commobj.BuildRequiredPropertiesForGoogleDataStore();

                    //get the kind name
                    kindName = commobj.GetKindNameBasedOnPracticeID(OASDataStoreKind.DesignationsInfo, inputmodel.orgmodel.OrganizationID);

                    //creating the key factory instance to generate new key for kind entitty
                    keyFactory = datastoreDb.CreateKeyFactory(kindName);

                    if (!string.IsNullOrEmpty(inputmodel.designationsgdsuid))
                    {

                        Key key = keyFactory.CreateKey(Convert.ToInt64(inputmodel.designationsgdsuid));

                        //looking or searching with key in kind
                        Entity entity = await datastoreDb.LookupAsync(key);

                        if (entity != null)
                        {
                            //setting the values
                            commobj.setEntityBooleanValue(ref entity, "Inactive", true, false);

                            List<Entity> listinsert = new List<Entity>();

                            listinsert.Add(entity);

                            using (GoogleDataStoreInputInfo info = new GoogleDataStoreInputInfo())
                            {
                                commobj.Common_UpdateDataIntoDataStore(inputmodel, listinsert, datastoreDb, info, this);
                            }
                        }
                    }
                }
            }
            finally
            {

            }
            return response;
        }
        #endregion




        #region " ************ DISPOSING USED OBJECTS BLOCK********************* "
        // Dispose() calls Dispose(true)
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {

            }
        }
        #endregion
    }
}
