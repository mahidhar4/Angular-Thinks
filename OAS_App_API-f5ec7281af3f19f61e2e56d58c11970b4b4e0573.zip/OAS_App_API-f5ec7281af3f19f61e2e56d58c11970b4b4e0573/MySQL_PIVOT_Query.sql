

/*   AND ((body.fieldid = 6503589044289536 and body.filedValue LIKE '%h%')
                  OR (body.fieldid = 65035890442895367 and body.filedValue LIKE '%h%'))*/


		select * from 1_oas_metadata.tbl_form_5697016667570176_metadata_body;
      
        
        
        
        select
			*
        from
        (
			select 
				head.recordid,
				body.recorddataid,
				field.formid, 
                body.fieldid,
				max(if(body.fieldid = 6503589044289536 , body.filedValue, NULL)) as `c_6503589044289536`,
                max(if(body.fieldid = 6503589044289536 , body.filedValue, NULL)) as `c_65035890442895362`,
                body.datastatus as bodystats,
                head.datastatus
			from
				1_oas_metadata.tbl_form_5697016667570176_metadata_header head
			inner join
				1_oas_metadata.tbl_form_5697016667570176_metadata_body  body on body.recordid = head.recordid
																			 and body.datastatus = 0
			inner join
				oas_master.tbl_master_fields field on body.fieldid = field.fieldid
													and field.datastatus = 0			
			where
				head.datastatus = 0
			group by
				body.recorddataid
		 )X
		
            
            


						